"use client";

import dynamic from "next/dynamic";

/* The CARIO shell renders 3D content — load it client-side only
   to avoid SSR issues with three.js / WebGL. */
const CarioShell = dynamic(
  () => import("@/components/cario/CarioShell").then((m) => m.CarioShell),
  { ssr: false }
);

export default function Page() {
  return <CarioShell />;
}
