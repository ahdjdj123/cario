"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  HERO_VEHICLE_ID,
  getVehicle,
  randomVehicle,
  type Vehicle,
} from "@/lib/vehicles";
import { DEFAULT_ATMOSPHERE, type AtmospherePresetId } from "@/lib/vehicles/atmosphere";

/**
 * CARIO application state.
 * The whole experience lives on a single route. Navigation is modelled
 * as a stack of "views" with smooth transitions orchestrated by the shell.
 */

export type CarioView =
  | "intro"
  | "home"
  | "explore"
  | "random"
  | "identify"
  | "experience"
  | "compare"
  | "favorites"
  | "stats";

export type CarioCameraMode =
  | "exterior"
  | "interior"
  | "engine";

export interface CarioSettings {
  /** Visual quality of the 3D scene */
  renderQuality: "performance" | "balanced" | "cinematic";
  /** Whether the cinematic intro plays on launch */
  playIntro: boolean;
  /** Auto-rotate the hero car when idle */
  autoRotate: boolean;
  /** Show the fine grain overlay */
  grain: boolean;
  /** Reduce motion for accessibility */
  reduceMotion: boolean;
  /** Show extra telemetry (weight, drivetrain) */
  verboseSpecs: boolean;
}

export interface CarioState {
  /* --- Navigation --- */
  view: CarioView;
  /** Previous view — used for elegant "back" behaviour */
  previousView: CarioView | null;
  /** A short stack so CONTINUE / back behave predictably */
  history: CarioView[];

  /* --- Vehicles --- */
  selectedVehicleId: string;
  /** The last vehicle the user explored, for CONTINUE */
  lastVehicleId: string | null;
  /** Recently viewed vehicle IDs (most recent first, max 6) */
  recentIds: string[];
  /** Currently active paint colour id (per vehicle, keyed by id) */
  activeColorId: Record<string, string>;
  /** Vehicle IDs selected for side-by-side comparison (max 3) */
  compareIds: string[];
  /** Bookmarked/favorited vehicle IDs (the user's personal garage) */
  favoriteIds: string[];

  /* --- Car Experience sub-state --- */
  cameraMode: CarioCameraMode;
  /** Active atmosphere preset (environment switcher) */
  atmosphereId: AtmospherePresetId;

  /* --- Identify mini-game --- */
  identifyScore: number;
  identifyBestScore: number;
  identifyTotalRuns: number;

  /* --- Settings --- */
  settings: CarioSettings;

  /* --- Intro --- */
  introCompleted: boolean;

  /* --- Actions --- */
  setView: (view: CarioView) => void;
  goBack: () => void;
  selectVehicle: (id: string) => void;
  setColor: (vehicleId: string, colorId: string) => void;
  setCameraMode: (mode: CarioCameraMode) => void;
  setAtmosphere: (id: AtmospherePresetId) => void;
  completeIntro: () => void;
  continueLast: () => void;
  rollRandom: () => Vehicle;
  recordIdentifyResult: (score: number) => void;
  updateSettings: (patch: Partial<CarioSettings>) => void;
  /** Toggle a vehicle in the comparison set (max 3) */
  toggleCompare: (id: string) => void;
  /** Clear the comparison set */
  clearCompare: () => void;
  /** Toggle a vehicle in the favorites/personal garage */
  toggleFavorite: (id: string) => void;
}

const DEFAULT_SETTINGS: CarioSettings = {
  renderQuality: "balanced",
  playIntro: true,
  autoRotate: true,
  grain: true,
  reduceMotion: false,
  verboseSpecs: false,
};

export const useCario = create<CarioState>()(
  persist(
    (set, get) => ({
      view: "intro",
      previousView: null,
      history: [],

      selectedVehicleId: HERO_VEHICLE_ID,
      lastVehicleId: null,
      recentIds: [],
      activeColorId: {},
      compareIds: [],
      favoriteIds: [],

      cameraMode: "exterior",
      atmosphereId: DEFAULT_ATMOSPHERE,

      identifyScore: 0,
      identifyBestScore: 0,
      identifyTotalRuns: 0,

      settings: DEFAULT_SETTINGS,
      introCompleted: false,

      setView: (view) =>
        set((s) => {
          if (view === s.view) return {};
          return {
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
            view,
          };
        }),

      goBack: () =>
        set((s) => {
          const history = [...s.history];
          const prev = history.pop();
          if (!prev) return { view: "home", history, previousView: null };
          return { view: prev, history, previousView: s.view };
        }),

      selectVehicle: (id) =>
        set((s) => {
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [id, ...s.recentIds.filter((x) => x !== id)].slice(0, 6);
          return {
            selectedVehicleId: id,
            lastVehicleId: id,
            recentIds,
            cameraMode: "exterior",
            view: "experience",
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
          };
        }),

      setColor: (vehicleId, colorId) =>
        set((s) => ({
          activeColorId: { ...s.activeColorId, [vehicleId]: colorId },
        })),

      setCameraMode: (mode) => set({ cameraMode: mode }),

      setAtmosphere: (id) => set({ atmosphereId: id }),

      completeIntro: () => set({ introCompleted: true, view: "home" }),

      continueLast: () =>
        set((s) => {
          const id = s.lastVehicleId ?? s.selectedVehicleId;
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [id, ...s.recentIds.filter((x) => x !== id)].slice(0, 6);
          return {
            selectedVehicleId: id,
            recentIds,
            cameraMode: "exterior",
            view: "experience",
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
          };
        }),

      rollRandom: () => {
        const v = randomVehicle(get().selectedVehicleId);
        set((s) => {
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [v.id, ...s.recentIds.filter((x) => x !== v.id)].slice(0, 6);
          return {
            selectedVehicleId: v.id,
            lastVehicleId: v.id,
            recentIds,
            cameraMode: "exterior",
          };
        });
        return v;
      },

      recordIdentifyResult: (score) =>
        set((s) => ({
          identifyScore: score,
          identifyBestScore: Math.max(s.identifyBestScore, score),
          identifyTotalRuns: s.identifyTotalRuns + 1,
        })),

      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),

      toggleCompare: (id) =>
        set((s) => {
          if (s.compareIds.includes(id)) {
            // Remove if already in the set
            return { compareIds: s.compareIds.filter((x) => x !== id) };
          }
          // Add if room (max 3)
          if (s.compareIds.length >= 3) return {};
          return { compareIds: [...s.compareIds, id] };
        }),

      clearCompare: () => set({ compareIds: [] }),

      toggleFavorite: (id) =>
        set((s) => {
          if (s.favoriteIds.includes(id)) {
            return { favoriteIds: s.favoriteIds.filter((x) => x !== id) };
          }
          return { favoriteIds: [...s.favoriteIds, id] };
        }),
    }),
    {
      name: "cario-state-v1",
      // Only persist user-meaningful fields, not the transient view/intro state
      partialize: (s) => ({
        lastVehicleId: s.lastVehicleId,
        recentIds: s.recentIds,
        activeColorId: s.activeColorId,
        atmosphereId: s.atmosphereId,
        compareIds: s.compareIds,
        favoriteIds: s.favoriteIds,
        identifyBestScore: s.identifyBestScore,
        identifyTotalRuns: s.identifyTotalRuns,
        settings: s.settings,
      }),
    }
  )
);

/* --- Convenience selectors / hooks --- */

export function useActiveColor(vehicle: Vehicle) {
  return useCario((s) => {
    const id = s.activeColorId[vehicle.id];
    if (id) {
      const c = vehicle.colors.find((c) => c.id === id);
      if (c) return c;
    }
    return vehicle.colors[0];
  });
}

export function useSelectedVehicle(): Vehicle {
  return useCario((s) => getVehicle(s.selectedVehicleId)!);
}
