"use client";

import { useEffect } from "react";
import { useCario } from "@/lib/cario/store";

/* ============================================================
   useKeyboardShortcuts — global keyboard navigation
   ------------------------------------------------------------
   Enhances the premium feel with precise keyboard control:

   Home view:
     1 / E → Explore
     2 / C → Continue
     3 / R → Random
     4 / I → Identify

   Anywhere:
     Esc / Backspace → Back (to previous view or home)
     S → Open Settings (future)

   Car Experience:
     E → Exterior
     I → Interior
     G → Engine
     O → cOlor
     A → Atmosphere

   Shortcuts are disabled while the user is typing in an input.
   ============================================================ */

export function useKeyboardShortcuts() {
  const setView = useCario((s) => s.setView);
  const goBack = useCario((s) => s.goBack);
  const continueLast = useCario((s) => s.continueLast);
  const view = useCario((s) => s.view);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Don't intercept while typing in inputs
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable ||
          target.tagName === "SELECT")
      ) {
        return;
      }

      // Esc / Backspace → back
      if (e.key === "Escape" || e.key === "Backspace") {
        e.preventDefault();
        if (view === "intro") return;
        goBack();
        return;
      }

      const key = e.key.toLowerCase();

      if (view === "home") {
        if (key === "1" || key === "e") { e.preventDefault(); setView("explore"); }
        else if (key === "3" || key === "r") {
          e.preventDefault();
          useCario.getState().rollRandom();
          setView("random");
        }
        else if (key === "4" || key === "i") { e.preventDefault(); setView("identify"); }
        else if (key === "5") { e.preventDefault(); setView("compare"); }
        else if (key === "2" || key === "c") {
          e.preventDefault();
          const st = useCario.getState();
          if (st.lastVehicleId) continueLast();
        }
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [view, setView, goBack, continueLast]);
}
