/**
 * CARIO Vehicle Data Architecture
 * ------------------------------------------------------------
 * Adding a new vehicle should primarily require adding a new
 * dataset object and asset references — not rebuilding the app.
 *
 * The UI consumes `Vehicle` data; it never hardcodes vehicle pages.
 *
 * Three-tier 3D asset strategy:
 *   LEVEL 1 — RAW 3D        : procedural lightweight geometry (this prototype)
 *   LEVEL 2 — BASIC / HIGH  : upgraded GLB models (drop-in)
 *   LEVEL 3 — PREMIUM 4K    : final high-fidelity GLB models (drop-in)
 *
 * Every vehicle points to an `assets` block. The renderer picks
 * the best available tier; LEVEL 1 always falls back to the
 * procedural RawCar so the experience never breaks.
 */

export type AssetTier = "raw" | "basic" | "premium";

/* ------------------------------------------------------------------ */
/* Atmosphere presets — studio environment switcher                    */
/* ------------------------------------------------------------------ */

export type AtmospherePresetId =
  | "studio"
  | "dawn"
  | "dusk"
  | "night"
  | "rain";

export interface AtmospherePreset {
  id: AtmospherePresetId;
  name: string;
  /** Short descriptor shown in the selector */
  hint: string;
  /** Drei Environment preset to use */
  envPreset: "studio" | "city" | "sunset" | "dawn" | "night" | "warehouse" | "park" | "lobby" | "apartment";
  /** Backdrop variant key */
  backdrop: "studio" | "spotlight" | "deep" | "void";
  /** Key light color (hex) */
  keyColor: string;
  /** Key light intensity */
  keyIntensity: number;
  /** Fill light color */
  fillColor: string;
  /** Rim light color */
  rimColor: string;
  /** Ambient intensity */
  ambient: number;
  /** Tone mapping exposure */
  exposure: number;
  /** Floor color */
  floorColor: string;
  /** Floor metalness */
  floorMetalness: number;
  /** Floor roughness */
  floorRoughness: number;
  /** Optional fog color (matches backdrop) */
  fogColor?: string;
  /** Optional fog density (0 = no fog) */
  fogDensity?: number;
}

export interface VehicleColor {
  /** Stable id, e.g. "obsidian" */
  id: string;
  /** Display name shown in the compact selector */
  name: string;
  /** Hex paint color */
  hex: string;
  /** Paint finish */
  finish: "matte" | "satin" | "gloss" | "metallic";
  /** 0..1 metalness for the material */
  metalness?: number;
  /** 0..1 roughness for the material */
  roughness?: number;
  /** Optional clear-coat intensity */
  clearcoat?: number;
}

export interface VehicleAssetRef {
  /** Asset tier this reference targets */
  tier: AssetTier;
  /** URL to GLB for LEVEL 2 / LEVEL 3 (undefined for raw) */
  url?: string;
}

export interface VehicleAssets {
  exterior?: VehicleAssetRef[];
  interior?: VehicleAssetRef[];
  engine?: VehicleAssetRef[];
}

export interface VehicleGenerationEntry {
  /** Generation code e.g. "992" */
  code: string;
  /** Production years */
  years: string;
  /** One-line summary */
  note: string;
}

export interface VehicleSpec {
  horsepower: number;       // hp
  acceleration: number;     // 0-100 km/h in seconds
  topSpeed: number;         // km/h
  weight?: number;          // kg
  engine?: string;          // e.g. "4.0L Flat-6"
  drivetrain?: string;     // e.g. "RWD"
}

export type VehicleEra = "classic" | "modern" | "contemporary" | "future";
export type VehicleType = "coupe" | "supercar" | "hypercar" | "gt" | "roadster" | "suv";

/**
 * Body-style descriptor used by the LEVEL-1 RAW procedural model
 * to give each vehicle a distinct silhouette without bespoke assets.
 */
export interface RawBodyParams {
  /** Overall length multiplier */
  length: number;
  /** Body height (cabin floor to roof shoulder) */
  height: number;
  /** Cabin roof height */
  roof: number;
  /** Wheel radius */
  wheelRadius: number;
  /** Wheel width */
  wheelWidth: number;
  /** Rear wing presence 0..1 */
  wing: number;
  /** Front wedge angle (nose-down) in degrees, subtle */
  wedge: number;
  /** Nose length ratio (long-hood GT vs mid-engine supercar) */
  noseRatio: number;
  /** Cabin position ratio (0 = forward, 1 = rearward) */
  cabinRatio: number;
  /** Track width */
  track: number;
  /** Subtle character-line aggressiveness 0..1 */
  aggressiveness: number;
}

export interface Vehicle {
  /** Stable unique id */
  id: string;
  /** Manufacturer / marque */
  brand: string;
  /** Model name */
  model: string;
  /** Generation code (e.g. "992") */
  generation: string;
  /** Model year */
  year: number;
  /** Body type */
  type: VehicleType;
  /** Era classification */
  era: VehicleEra;
  /** Short tagline shown beneath the model name */
  tagline: string;

  spec: VehicleSpec;
  colors: VehicleColor[];

  /** LEVEL-1 procedural silhouette params */
  raw: RawBodyParams;

  /** Asset references for LEVEL 2 / LEVEL 3 (may be empty) */
  assets: VehicleAssets;

  /** Generational timeline */
  generationTimeline: VehicleGenerationEntry[];

  /** Short history blurb (kept minimal) */
  history: string;

  /** Reserved / future module flags */
  sound?: { available: boolean; note?: string };
  atmosphere?: { available: boolean; note?: string };
  track?: { available: boolean; note?: string };
}

/* ------------------------------------------------------------------ */
/* Identify mini-game question sets                                    */
/* ------------------------------------------------------------------ */

export interface IdentifyQuestion {
  id: string;
  /** Which detail we are cropping */
  detail: "taillight" | "grille" | "wheel" | "headlight" | "silhouette" | "interior";
  /** Cropped region hint used by the renderer (normalized 0..1 viewport) */
  crop: { x: number; y: number; zoom: number };
  /** Vehicle the cropped detail belongs to */
  answerVehicleId: string;
  /** Four candidate model names */
  options: string[];
  /** Index of the correct option */
  correctIndex: number;
}
