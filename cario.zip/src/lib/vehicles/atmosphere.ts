import type { AtmospherePreset, AtmospherePresetId } from "./types";

/* ============================================================
   Atmosphere presets — 5 cinematic studio environments
   ------------------------------------------------------------
   Each preset configures the 3D scene's lighting, environment
   map, backdrop, and floor material. Switching presets gives
   the car a completely different mood without swapping the
   3D model itself.
   ============================================================ */

export const ATMOSPHERE_PRESETS: AtmospherePreset[] = [
  {
    id: "studio",
    name: "Studio",
    hint: "Neutral showroom",
    envPreset: "studio",
    backdrop: "studio",
    keyColor: "#F3F3F1",
    keyIntensity: 1.9,
    fillColor: "#C9CBD0",
    rimColor: "#F3F3F1",
    ambient: 0.32,
    exposure: 0.95,
    floorColor: "#08090B",
    floorMetalness: 0.55,
    floorRoughness: 0.4,
  },
  {
    id: "dawn",
    name: "Dawn",
    hint: "Soft warm light",
    envPreset: "dawn",
    backdrop: "spotlight",
    keyColor: "#F3E8D4",
    keyIntensity: 1.6,
    fillColor: "#858990",
    rimColor: "#C9CBD0",
    ambient: 0.28,
    exposure: 1.0,
    floorColor: "#0B0D10",
    floorMetalness: 0.4,
    floorRoughness: 0.5,
    fogColor: "#0B0D10",
    fogDensity: 0.015,
  },
  {
    id: "dusk",
    name: "Dusk",
    hint: "Golden hour glow",
    envPreset: "sunset",
    backdrop: "deep",
    keyColor: "#E8C9A0",
    keyIntensity: 1.8,
    fillColor: "#5A4E54",
    rimColor: "#C9885A",
    ambient: 0.25,
    exposure: 1.05,
    floorColor: "#0A0B0D",
    floorMetalness: 0.6,
    floorRoughness: 0.35,
    fogColor: "#0A0B0D",
    fogDensity: 0.02,
  },
  {
    id: "night",
    name: "Night",
    hint: "Cinematic low key",
    envPreset: "night",
    backdrop: "void",
    keyColor: "#5A6A8A",
    keyIntensity: 1.2,
    fillColor: "#2A2E34",
    rimColor: "#8AA0C0",
    ambient: 0.15,
    exposure: 0.85,
    floorColor: "#050608",
    floorMetalness: 0.7,
    floorRoughness: 0.3,
    fogColor: "#050608",
    fogDensity: 0.025,
  },
  {
    id: "rain",
    name: "Rain",
    hint: "Wet reflective floor",
    envPreset: "warehouse",
    backdrop: "deep",
    keyColor: "#C9CBD0",
    keyIntensity: 1.4,
    fillColor: "#858990",
    rimColor: "#F3F3F1",
    ambient: 0.22,
    exposure: 0.9,
    floorColor: "#060708",
    floorMetalness: 0.85,
    floorRoughness: 0.12,
    fogColor: "#060708",
    fogDensity: 0.03,
  },
];

export const DEFAULT_ATMOSPHERE: AtmospherePresetId = "studio";

export function getAtmosphere(id: AtmospherePresetId): AtmospherePreset {
  return ATMOSPHERE_PRESETS.find((p) => p.id === id) ?? ATMOSPHERE_PRESETS[0];
}
