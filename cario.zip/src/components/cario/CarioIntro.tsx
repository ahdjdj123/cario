"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CarViewer3D } from "@/components/cario/three/CarViewer3D";
import { BrandMark } from "@/components/cario/ui-parts/BrandMark";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { useCario } from "@/lib/cario/store";
import { getHeroVehicle } from "@/lib/vehicles";

/* ============================================================
   CarioIntro — short cinematic first-launch sequence
   ------------------------------------------------------------
   1. Dark screen
   2. Studio environment fades in
   3. Car silhouette appears
   4. Soft lighting reveals the car
   5. CARIO wordmark appears
   6. Interface fades in
   7. Arrives at Home / Garage
   ------------------------------------------------------------
   Honors the `playIntro` setting. If disabled, completes instantly.
   ============================================================ */

export function CarioIntro() {
  const completeIntro = useCario((s) => s.completeIntro);
  const playIntro = useCario((s) => s.settings.playIntro);
  const reduceMotion = useCario((s) => s.settings.reduceMotion);
  const [skipped, setSkipped] = useState(false);
  const hero = getHeroVehicle();
  const color = hero.colors[0];

  useEffect(() => {
    if (!playIntro || reduceMotion) {
      const t = setTimeout(() => completeIntro(), 200);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      if (!skipped) completeIntro();
    }, 5400);
    return () => clearTimeout(t);
  }, [playIntro, reduceMotion, completeIntro, skipped]);

  const skip = () => {
    setSkipped(true);
    completeIntro();
  };

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Darkened 3D hero behind the reveal */}
      <div className="absolute inset-0">
        <CarViewer3D
          vehicle={hero}
          color={color}
          cameraPosition={[5.2, 1.4, 5.4]}
          cameraTarget={[0, 0.45, 0]}
          autoRotate={false}
          enableZoom={false}
          enablePan={false}
          quality="balanced"
        />
      </div>

      {/* Stage scrim — keyframed from black → reveal */}
      <motion.div
        className="pointer-events-none absolute inset-0 bg-[#050608]"
        initial={{ opacity: 1 }}
        animate={{ opacity: [1, 1, 0.85, 0.5, 0.18, 0.05, 0] }}
        transition={{
          duration: 5.2,
          times: [0, 0.12, 0.32, 0.5, 0.66, 0.85, 1],
          ease: [0.22, 1, 0.36, 1],
        }}
      />
      <Backdrop variant="void" grain={false} />

      {/* Wordmark */}
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <motion.div
          initial={{ opacity: 0, letterSpacing: "0.9em", filter: "blur(6px)" }}
          animate={{
            opacity: [0, 0, 0, 0.35, 1, 1, 0.9],
            letterSpacing: ["0.9em", "0.9em", "0.9em", "0.6em", "0.46em", "0.46em", "0.46em"],
            filter: ["blur(6px)", "blur(6px)", "blur(6px)", "blur(2px)", "blur(0px)", "blur(0px)", "blur(0px)"],
          }}
          transition={{
            duration: 5.2,
            times: [0, 0.12, 0.5, 0.62, 0.72, 0.85, 1],
            ease: [0.22, 1, 0.36, 1],
          }}
          className="font-display text-3xl font-light text-cario-white sm:text-4xl"
          style={{ textIndent: "0.46em" }}
        >
          CARIO
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: [0, 0, 0, 0, 0.5, 0.7, 0], y: 6 }}
          transition={{ duration: 5.2, times: [0, 0.5, 0.6, 0.7, 0.78, 0.9, 1] }}
          className="mt-4 font-mono text-[10px] uppercase tracking-mega text-cario-soft-gray"
        >
          Interactive Automotive Exploration
        </motion.div>
      </div>

      {/* Bottom progress line + skip */}
      <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-3 px-6 pb-6">
        <div className="h-px w-40 overflow-hidden bg-white/10">
          <motion.div
            className="h-full bg-cario-light-gray"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 5.0, ease: "linear" }}
          />
        </div>
        <motion.button
          type="button"
          onClick={skip}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70 transition-colors hover:text-cario-light-gray"
        >
          Skip intro →
        </motion.button>
      </div>
    </motion.div>
  );
}
