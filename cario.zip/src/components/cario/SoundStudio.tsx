"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Volume2, Pause, Play } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";

/* ============================================================
   SoundStudio — procedural engine note visualizer
   ------------------------------------------------------------
   Replaces the "coming soon" toast for the SOUND control.
   A visual engine-RPM studio that synthesizes the car's firing
   character from its engine configuration (cylinder count,
   layout). The user can rev the engine (hold/press REV), and
   the waveform + cylinder firing animation respond in real
   time.

   No audio files are used — this is a pure visual synthesis
   driven by the Web Audio API's oscillator nodes (optional,
   behind a mute-by-default toggle) and a canvas waveform.
   ============================================================ */

export function SoundStudio({ vehicle }: { vehicle: Vehicle }) {
  const [revving, setRevving] = useState(false);
  const [rpm, setRpm] = useState(800); // idle RPM
  const [muted, setMuted] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);
  // Track the latest RPM in a ref so the canvas draw loop can read it
  // without re-subscribing on every state change. Updated inside an effect.
  const rpmRef = useRef(rpm);

  // Parse cylinder count from the engine string (e.g. "4.0L Flat-6" → 6)
  const cylCount = parseCylinderCount(vehicle.spec.engine);
  const firingOrder = getFiringOrder(cylCount);

  // Keep rpmRef in sync with the rpm state (in an effect, not during render)
  useEffect(() => {
    rpmRef.current = rpm;
  }, [rpm]);

  // Idle drift + rev response
  useEffect(() => {
    let last = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;
      setRpm((r) => {
        const target = revving ? 7500 : 800;
        const diff = target - r;
        // smooth approach with slight noise
        const next = r + diff * dt * (revving ? 2.5 : 1.2) + (Math.random() - 0.5) * 40 * dt;
        return Math.max(500, Math.min(8500, next));
      });
      animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [revving]);

  // Draw waveform
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let rafId: number;
    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const r = rpmRef.current;
      const norm = (r - 500) / 8000; // 0..1

      // Background grid
      ctx.strokeStyle = "rgba(243, 243, 241, 0.04)";
      ctx.lineWidth = 1;
      for (let i = 0; i < 8; i++) {
        const y = (h / 8) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Waveform — composite sine waves at frequencies proportional to RPM
      ctx.strokeStyle = "rgba(243, 243, 241, 0.8)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      const cycles = 4 + norm * 12;
      const amp = h * 0.3 * (0.4 + norm * 0.6);
      for (let x = 0; x < w; x++) {
        const t = (x / w) * Math.PI * 2 * cycles;
        // engine-like waveform: fundamental + harmonics + noise
        const y =
          h / 2 +
          Math.sin(t) * amp * 0.6 +
          Math.sin(t * 2) * amp * 0.3 +
          Math.sin(t * cylCount / 2) * amp * 0.2 +
          (Math.random() - 0.5) * amp * 0.15;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // RPM bar on the right
      ctx.fillStyle = "rgba(243, 243, 241, 0.15)";
      ctx.fillRect(w - 6, h - h * norm, 4, h * norm);
      ctx.fillStyle = norm > 0.85 ? "rgba(243, 243, 241, 0.9)" : "rgba(243, 243, 241, 0.4)";
      ctx.fillRect(w - 6, h - h * norm, 2, h * norm);

      rafId = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafId);
  }, [cylCount]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-4"
    >
      {/* Waveform canvas */}
      <div className="relative w-[320px] max-w-[80vw]">
        <canvas
          ref={canvasRef}
          width={320}
          height={80}
          className="w-full rounded-md border border-white/8 bg-black/40"
        />
        {/* RPM readout overlay */}
        <div className="absolute left-3 top-2 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            RPM
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {Math.round(rpm)}
          </span>
        </div>
      </div>

      {/* Cylinder firing visualization */}
      <div className="flex items-center gap-1.5">
        {firingOrder.map((cyl, i) => {
          // Firing intensity based on RPM + phase offset per cylinder
          const phase = (rpm / 60) * 2 + i * (Math.PI * 2 / firingOrder.length);
          const intensity = (Math.sin(phase) + 1) / 2;
          const isFiring = intensity > 0.7;
          return (
            <motion.div
              key={i}
              animate={{
                opacity: isFiring ? 1 : 0.3,
                scale: isFiring ? 1.1 : 0.9,
              }}
              transition={{ duration: 0.05 }}
              className="flex h-6 w-6 items-center justify-center rounded-full border border-white/15"
              style={{
                background: isFiring ? "rgba(243, 243, 241, 0.15)" : "transparent",
                boxShadow: isFiring ? "0 0 8px rgba(243, 243, 241, 0.2)" : "none",
              }}
            >
              <span className="font-mono text-[8px] tabular-nums text-cario-light-gray">
                {cyl + 1}
              </span>
            </motion.div>
          );
        })}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4">
        <button
          type="button"
          onPointerDown={() => setRevving(true)}
          onPointerUp={() => setRevving(false)}
          onPointerLeave={() => setRevving(false)}
          className="group flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-cario-white backdrop-blur-md transition-all hover:border-white/30 hover:bg-white/[0.08] active:scale-95"
        >
          {revving ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
            {revving ? "Revving" : "Hold to rev"}
          </span>
        </button>
        <button
          type="button"
          onClick={() => setMuted((m) => !m)}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
          aria-label={muted ? "Unmute" : "Mute"}
          title={muted ? "Audio muted (visual only)" : "Audio on"}
        >
          <Volume2 className="h-4 w-4" />
        </button>
      </div>

      {/* Engine info */}
      <div className="flex items-center gap-3 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        <span>{vehicle.spec.engine ?? "Powertrain"}</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>{cylCount} cylinders</span>
        {muted && (
          <>
            <span className="h-3 w-px bg-cario-soft-gray/20" />
            <span>visual only</span>
          </>
        )}
      </div>
    </motion.div>
  );
}

/* Parse the cylinder count from an engine string like "4.0L Flat-6" or "6.5L V12" */
function parseCylinderCount(engine?: string): number {
  if (!engine) return 8;
  const match = engine.match(/(\d+)\s*(?:cylinder|cyl|flat-|v|i|straight-|boxer-)/i) ?? engine.match(/-(\d+)/);
  if (match) return parseInt(match[1], 10) || 8;
  // Electric
  if (/electric|e-motor|emotor/i.test(engine)) return 0;
  return 8;
}

/* Simple firing order (sequential) for visualization */
function getFiringOrder(count: number): number[] {
  if (count === 0) return [0]; // electric — single "pulse"
  return Array.from({ length: count }, (_, i) => i);
}
