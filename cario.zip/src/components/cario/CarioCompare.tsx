"use client";

import { AnimatePresence, motion } from "framer-motion";
import { X, Plus, ArrowLeftRight } from "lucide-react";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn, ViewHeader } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import { VEHICLES, getVehicle, type Vehicle } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioCompare — side-by-side spec comparison
   ------------------------------------------------------------
   A premium monochrome spec sheet comparing up to 3 vehicles
   side-by-side. Each column shows the vehicle's name, brand/year,
   and a full spec breakdown (power, 0-100, top speed, weight,
   engine, drivetrain). The best value in each row is highlighted
   with a subtle accent.

   Users add cars via the chip row at the bottom. The comparison
   set is stored in the Zustand store (compareIds, max 3).
   ============================================================ */

export function CarioCompare() {
  const goBack = useCario((s) => s.goBack);
  const compareIds = useCario((s) => s.compareIds);
  const toggleCompare = useCario((s) => s.toggleCompare);
  const clearCompare = useCario((s) => s.clearCompare);
  const selectVehicle = useCario((s) => s.selectVehicle);
  const grain = useCario((s) => s.settings.grain);

  const selected: Vehicle[] = compareIds
    .map((id) => getVehicle(id))
    .filter((v): v is Vehicle => !!v);

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" grain={grain} />

      <div className="cario-scroll absolute inset-0 overflow-y-auto">
        <div className="mx-auto min-h-full max-w-6xl px-6 py-8 sm:px-10 sm:py-10">
          {/* Header */}
          <div className="flex flex-col gap-5">
            <div className="pointer-events-auto">
              <CornerReturn label="Back" onClick={() => goBack()} />
            </div>
            <ViewHeader
              eyebrow="CARIO / 05"
              title="Compare"
              subtitle="Side-by-side specifications. Select up to three."
            />
          </div>

          {/* Comparison grid */}
          {selected.length > 0 ? (
            <ComparisonGrid
              vehicles={selected}
              onRemove={toggleCompare}
              onEnter={(id) => selectVehicle(id)}
            />
          ) : (
            <EmptyState />
          )}

          {/* Car selector */}
          <div className="mt-10">
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                Collection · {selected.length}/3 selected
              </span>
              {selected.length > 0 && (
                <button
                  type="button"
                  onClick={clearCompare}
                  className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray transition-colors hover:text-cario-light-gray"
                >
                  Clear all
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {VEHICLES.map((v) => {
                const active = compareIds.includes(v.id);
                const full = selected.length >= 3 && !active;
                return (
                  <button
                    key={v.id}
                    type="button"
                    disabled={full}
                    onClick={() => toggleCompare(v.id)}
                    className={cn(
                      "group flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] transition-all duration-300",
                      active
                        ? "border-white/30 bg-white/10 text-cario-white"
                        : full
                        ? "border-white/5 text-cario-soft-gray/30 cursor-not-allowed"
                        : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
                    )}
                  >
                    {active && <X className="h-3 w-3" />}
                    {!active && !full && <Plus className="h-3 w-3" />}
                    <span>{v.brand} {v.model}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* --- Empty state --- */
function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="mt-16 flex flex-col items-center justify-center gap-4"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/[0.02]">
        <ArrowLeftRight className="h-6 w-6 text-cario-soft-gray" />
      </div>
      <div className="flex flex-col items-center gap-1.5 text-center">
        <span className="font-display text-sm font-medium text-cario-light-gray">
          No vehicles selected
        </span>
        <span className="max-w-xs text-[12px] leading-relaxed text-cario-soft-gray">
          Pick two or three cars from the collection below to see their
          specifications side-by-side.
        </span>
      </div>
    </motion.div>
  );
}

/* --- Comparison grid --- */
function ComparisonGrid({
  vehicles,
  onRemove,
  onEnter,
}: {
  vehicles: Vehicle[];
  onRemove: (id: string) => void;
  onEnter: (id: string) => void;
}) {
  // Spec rows — each row shows the label + values for each vehicle
  const rows: {
    label: string;
    key: keyof Vehicle["spec"] | "brandYear" | "type" | "era";
    format: (v: Vehicle) => string;
    best: "high" | "low" | "none";
    unit?: string;
  }[] = [
    {
      label: "Power",
      key: "horsepower",
      format: (v) => String(v.spec.horsepower),
      best: "high",
      unit: "HP",
    },
    {
      label: "0–100 km/h",
      key: "acceleration",
      format: (v) => String(v.spec.acceleration),
      best: "low",
      unit: "s",
    },
    {
      label: "Top speed",
      key: "topSpeed",
      format: (v) => String(v.spec.topSpeed),
      best: "high",
      unit: "km/h",
    },
    {
      label: "Weight",
      key: "weight",
      format: (v) => (v.spec.weight ? String(v.spec.weight) : "—"),
      best: "low",
      unit: "kg",
    },
    {
      label: "Power-to-weight",
      key: "horsepower",
      format: (v) =>
        v.spec.weight ? (v.spec.horsepower / v.spec.weight * 1000).toFixed(0) : "—",
      best: "high",
      unit: "HP/t",
    },
    {
      label: "Engine",
      key: "engine",
      format: (v) => v.spec.engine ?? "—",
      best: "none",
    },
    {
      label: "Drivetrain",
      key: "drivetrain",
      format: (v) => v.spec.drivetrain ?? "—",
      best: "none",
    },
    {
      label: "Era",
      key: "era",
      format: (v) => v.era.charAt(0).toUpperCase() + v.era.slice(1),
      best: "none",
    },
  ];

  // Compute the best value for each numeric row
  const bestValues: Record<string, number | null> = {};
  for (const row of rows) {
    if (row.best === "none") continue;
    const values = vehicles
      .map((v) => parseFloat(row.format(v)))
      .filter((n) => !isNaN(n));
    if (values.length === 0) {
      bestValues[row.label] = null;
      continue;
    }
    bestValues[row.label] =
      row.best === "high" ? Math.max(...values) : Math.min(...values);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.15 }}
      className="mt-8"
    >
      {/* Column headers — vehicle names */}
      <div
        className="grid gap-3 border-b border-white/8 pb-4"
        style={{ gridTemplateColumns: `120px repeat(${vehicles.length}, 1fr)` }}
      >
        <div />
        {vehicles.map((v) => (
          <div key={v.id} className="flex flex-col gap-1.5">
            <div className="flex items-start justify-between gap-2">
              <div className="flex flex-col">
                <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                  {v.brand} · {v.generation} · {v.year}
                </span>
                <span className="font-display text-base font-medium tracking-tight-2 text-cario-white">
                  {v.model}
                </span>
              </div>
              <button
                type="button"
                onClick={() => onRemove(v.id)}
                className="flex h-6 w-6 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                aria-label="Remove from comparison"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            <button
              type="button"
              onClick={() => onEnter(v.id)}
              className="self-start font-mono text-[9px] uppercase tracking-label text-cario-soft-gray transition-colors hover:text-cario-white"
            >
              Enter experience →
            </button>
          </div>
        ))}
      </div>

      {/* Spec rows */}
      <div className="flex flex-col">
        {rows.map((row, ri) => (
          <motion.div
            key={row.label}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.2 + ri * 0.04 }}
            className={cn(
              "grid gap-3 border-b border-white/5 py-3.5",
              "grid-cols-[120px_repeat(var(--cols),1fr)]"
            )}
            style={{ ["--cols" as string]: vehicles.length }}
          >
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
              {row.label}
            </span>
            {vehicles.map((v) => {
              const value = row.format(v);
              const numVal = parseFloat(value);
              const isBest =
                row.best !== "none" &&
                bestValues[row.label] !== null &&
                !isNaN(numVal) &&
                numVal === bestValues[row.label];
              return (
                <div key={v.id} className="flex items-center gap-1.5">
                  <div
                    className={cn(
                      "flex items-baseline gap-1 rounded-md px-2 py-0.5 transition-all",
                      isBest && "bg-white/10 ring-1 ring-white/20"
                    )}
                  >
                    <span
                      className={cn(
                        "font-display text-lg font-light tabular-nums transition-colors",
                        isBest
                          ? "text-cario-white font-normal"
                          : "text-cario-light-gray"
                      )}
                    >
                      {value}
                    </span>
                    {row.unit && (
                      <span
                        className={cn(
                          "font-mono text-[10px] uppercase tracking-label",
                          isBest ? "text-cario-white/80" : "text-cario-soft-gray"
                        )}
                      >
                        {row.unit}
                      </span>
                    )}
                  </div>
                  {isBest && (
                    <span className="font-mono text-[8px] uppercase tracking-label text-cario-white/90">
                      ▲
                    </span>
                  )}
                </div>
              );
            })}
          </motion.div>
        ))}
      </div>

      {/* Tagline row */}
      <div className="mt-4 grid gap-3" style={{ gridTemplateColumns: `120px repeat(${vehicles.length}, 1fr)` }}>
        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
          Tagline
        </span>
        {vehicles.map((v) => (
          <p key={v.id} className="text-[12px] italic leading-relaxed text-cario-soft-gray">
            {v.tagline}
          </p>
        ))}
      </div>
    </motion.div>
  );
}
