"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";

/* ============================================================
   TrackStudio — minimal track-day telemetry visualization
   ------------------------------------------------------------
   Replaces the final "coming soon" toast for the TRACK control.
   A stylized top-down circuit with the car represented as a
   dot that laps the track. The speed/RPM/position update in
   real time based on the car's performance specs.

   No 3D models — this is a pure 2D canvas visualization that
   gives the feeling of track telemetry without heavy assets.
   ============================================================ */

export function TrackStudio({ vehicle }: { vehicle: Vehicle }) {
  const [playing, setPlaying] = useState(false);
  const [lap, setLap] = useState(1);
  const [speed, setSpeed] = useState(0);
  const [bestLap, setBestLap] = useState<number | null>(null);
  const [currentLapTime, setCurrentLapTime] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);
  const lapStartRef = useRef(0);
  const progressRef = useRef(0); // 0..1 around the track
  const playingRef = useRef(playing);

  // Keep playingRef in sync with state (in an effect, not during render)
  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  // Compute a lap time estimate from the car's specs
  // (faster cars = shorter laps; pure heuristic for the prototype)
  const estimatedLapTime = estimateLapTime(vehicle);

  // Animation loop
  useEffect(() => {
    let last = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;

      if (playingRef.current) {
        // Advance progress around the track
        const lapFraction = dt / estimatedLapTime;
        progressRef.current += lapFraction;
        if (progressRef.current >= 1) {
          // Lap completed
          const lapTime = now - lapStartRef.current;
          if (bestLap === null || lapTime < bestLap) {
            setBestLap(lapTime);
          }
          setLap((l) => l + 1);
          progressRef.current = progressRef.current - 1;
          lapStartRef.current = now;
          setCurrentLapTime(0);
        } else {
          setCurrentLapTime(now - lapStartRef.current);
        }
        // Speed varies along the track (slower on corners)
        const phase = progressRef.current * Math.PI * 2;
        const speedFactor = 0.5 + 0.5 * Math.abs(Math.sin(phase));
        setSpeed(vehicle.spec.topSpeed * speedFactor);
      } else {
        setSpeed(0);
      }

      drawTrack(canvasRef.current, progressRef.current, vehicle);
      animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [vehicle, estimatedLapTime, bestLap]);

  const handlePlay = () => {
    if (!playing) {
      lapStartRef.current = performance.now();
      setCurrentLapTime(0);
    }
    setPlaying((p) => !p);
  };

  const handleReset = () => {
    setPlaying(false);
    setLap(1);
    setSpeed(0);
    setCurrentLapTime(0);
    setBestLap(null);
    progressRef.current = 0;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-4"
    >
      {/* Track canvas */}
      <div className="relative w-[320px] max-w-[80vw]">
        <canvas
          ref={canvasRef}
          width={320}
          height={160}
          className="w-full rounded-md border border-white/8 bg-black/40"
        />
        {/* Lap counter overlay */}
        <div className="absolute left-3 top-2 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Lap
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {lap}
          </span>
        </div>
        {/* Speed overlay */}
        <div className="absolute right-3 top-2 flex flex-col items-end gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Speed
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {Math.round(speed)}
            <span className="ml-0.5 font-mono text-[8px] text-cario-soft-gray">km/h</span>
          </span>
        </div>
        {/* Current lap time */}
        <div className="absolute bottom-2 left-3 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Time
          </span>
          <span className="font-display text-xs font-light tabular-nums text-cario-light-gray">
            {formatTime(currentLapTime)}
          </span>
        </div>
        {/* Best lap */}
        {bestLap !== null && (
          <div className="absolute bottom-2 right-3 flex flex-col items-end gap-0.5">
            <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
              Best
            </span>
            <span className="font-display text-xs font-light tabular-nums text-cario-light-gray">
              {formatTime(bestLap)}
            </span>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={handlePlay}
          className="group flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-cario-white backdrop-blur-md transition-all hover:border-white/30 hover:bg-white/[0.08] active:scale-95"
        >
          {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
            {playing ? "Pause" : "Start lap"}
          </span>
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
          aria-label="Reset"
          title="Reset telemetry"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>

      {/* Track info */}
      <div className="flex items-center gap-3 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        <span>Circuit · CARIO Test Loop</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>Est. {estimatedLapTime.toFixed(1)}s</span>
      </div>
    </motion.div>
  );
}

/* --- Draw the track + car dot --- */
function drawTrack(
  canvas: HTMLCanvasElement | null,
  progress: number,
  vehicle: Vehicle
) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  // Track path — a stylized oval with a chicane
  const cx = w / 2;
  const cy = h / 2;
  const rx = w * 0.38;
  const ry = h * 0.32;

  // Draw track outline (dark)
  ctx.strokeStyle = "rgba(243, 243, 241, 0.08)";
  ctx.lineWidth = 22;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Track center line (dashed)
  ctx.strokeStyle = "rgba(243, 243, 241, 0.12)";
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 6]);
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // Start/finish line
  const startX = cx + rx;
  const startY = cy;
  ctx.strokeStyle = "rgba(243, 243, 241, 0.3)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(startX, startY - 10);
  ctx.lineTo(startX, startY + 10);
  ctx.stroke();

  // Car position — dot traveling around the ellipse
  const angle = progress * Math.PI * 2;
  const carX = cx + Math.cos(angle) * rx;
  const carY = cy + Math.sin(angle) * ry;

  // Trail behind the car
  const trailSteps = 30;
  for (let i = 0; i < trailSteps; i++) {
    const p = progress - (i / trailSteps) * 0.15;
    const a = p * Math.PI * 2;
    const tx = cx + Math.cos(a) * rx;
    const ty = cy + Math.sin(a) * ry;
    const alpha = (1 - i / trailSteps) * 0.4;
    ctx.fillStyle = `rgba(243, 243, 241, ${alpha})`;
    ctx.beginPath();
    ctx.arc(tx, ty, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Car dot — bright with glow
  const grad = ctx.createRadialGradient(carX, carY, 0, carX, carY, 12);
  grad.addColorStop(0, "rgba(243, 243, 241, 0.9)");
  grad.addColorStop(0.4, "rgba(243, 243, 241, 0.3)");
  grad.addColorStop(1, "rgba(243, 243, 241, 0)");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(carX, carY, 12, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#F3F3F1";
  ctx.beginPath();
  ctx.arc(carX, carY, 3.5, 0, Math.PI * 2);
  ctx.fill();
}

/* --- Estimate a lap time from the car's specs --- */
function estimateLapTime(vehicle: Vehicle): number {
  // Heuristic: faster cars (higher power, lower 0-100) get shorter laps
  // Base: 90s, minus power factor, plus weight factor
  const powerFactor = vehicle.spec.horsepower / 100;
  const accelFactor = vehicle.spec.acceleration * 3;
  const base = 95 - powerFactor + accelFactor;
  return Math.max(55, Math.min(120, base));
}

/* --- Format milliseconds as M:SS.mmm --- */
function formatTime(ms: number): string {
  if (ms <= 0) return "0:00.000";
  const totalSec = ms / 1000;
  const min = Math.floor(totalSec / 60);
  const sec = Math.floor(totalSec % 60);
  const milli = Math.floor((totalSec % 1) * 1000);
  return `${min}:${String(sec).padStart(2, "0")}.${String(milli).padStart(3, "0")}`;
}
