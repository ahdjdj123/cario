"use client";

import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Keyboard, X } from "lucide-react";

/* ============================================================
   ShortcutsHelp — keyboard shortcuts overlay
   ------------------------------------------------------------
   A small overlay triggered by the "?" key (or a button) that
   shows all available keyboard shortcuts. Sits at z-50 so it
   floats above everything.
   ============================================================ */

const SHORTCUTS: { key: string; label: string; view?: string }[] = [
  { key: "Esc", label: "Back / return" },
  { key: "1", label: "Explore", view: "Home" },
  { key: "2", label: "Continue", view: "Home" },
  { key: "3", label: "Random", view: "Home" },
  { key: "4", label: "Identify", view: "Home" },
  { key: "5", label: "Compare", view: "Home" },
  { key: "?", label: "Toggle this help" },
];

export function ShortcutsHelp() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) {
        return;
      }
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open]);

  return (
    <>
      {/* Trigger button — small, bottom-right, only on non-intro views */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="pointer-events-auto absolute bottom-3 left-4 z-40 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-black/30 text-cario-soft-gray backdrop-blur-md transition-colors hover:border-white/20 hover:text-cario-white"
        aria-label="Keyboard shortcuts"
        title="Keyboard shortcuts (?)"
      >
        <Keyboard className="h-3.5 w-3.5" />
      </button>

      <AnimatePresence>
        {open && (
          <>
            {/* Scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[2px]"
            />
            {/* Panel */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="fixed left-1/2 top-1/2 z-50 w-[340px] max-w-[88vw] -translate-x-1/2 -translate-y-1/2 cario-surface-strong rounded-lg"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
                <div className="flex items-center gap-2">
                  <Keyboard className="h-4 w-4 text-cario-soft-gray" />
                  <span className="font-display text-sm font-medium tracking-wider-2 uppercase text-cario-white">
                    Shortcuts
                  </span>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                  aria-label="Close"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Shortcuts list */}
              <div className="flex flex-col gap-1 px-5 py-4">
                {SHORTCUTS.map((s, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between py-1.5"
                  >
                    <span className="text-[12px] text-cario-light-gray">
                      {s.label}
                    </span>
                    <div className="flex items-center gap-2">
                      {s.view && (
                        <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                          {s.view}
                        </span>
                      )}
                      <kbd className="flex h-6 min-w-6 items-center justify-center rounded border border-white/15 bg-white/5 px-1.5 font-mono text-[10px] text-cario-white">
                        {s.key}
                      </kbd>
                    </div>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="border-t border-white/8 px-5 py-3">
                <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                  Press ? to toggle · Esc to close
                </span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
