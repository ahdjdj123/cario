"use client";

import { useEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { CarViewer3D } from "@/components/cario/three/CarViewer3D";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import { getVehicle } from "@/lib/vehicles";

/* ============================================================
   CarioRandom — cinematic random-car reveal
   ------------------------------------------------------------
   Title: RANDOM CAR · "Let CARIO choose."
   A mysterious vehicle emerges from shadow. DISCOVER reveals the
   selected car; SURPRISE ME AGAIN rolls another. The effect feels
   like a cinematic reveal — Rembrandt chiaroscuro, never a slot
   machine.
   ============================================================ */

type Phase = "mystery" | "revealing" | "revealed";

export function CarioRandom() {
  const goBack = useCario((s) => s.goBack);
  const selectedId = useCario((s) => s.selectedVehicleId);
  const rollRandom = useCario((s) => s.rollRandom);
  const selectVehicle = useCario((s) => s.selectVehicle);
  const grain = useCario((s) => s.settings.grain);

  const [phase, setPhase] = useState<Phase>("mystery");
  // Reset to mystery whenever the selected vehicle changes.
  // We use useEffect (not a render-phase update) because the
  // render-phase pattern was interfering with the reveal timer's
  // setPhase("revealed") call in React 19's concurrent rendering.
  const prevSelectedIdRef = useRef(selectedId);
  useEffect(() => {
    if (selectedId !== prevSelectedIdRef.current) {
      prevSelectedIdRef.current = selectedId;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPhase("mystery");
    }
  }, [selectedId]);

  // Reveal transition — driven by a requestAnimationFrame loop with a
  // setTimeout fallback. Both call advanceToRevealed which is idempotent.
  const revealStartRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);
  const revealTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      if (revealTimerRef.current) clearTimeout(revealTimerRef.current);
      rafRef.current = null;
      revealTimerRef.current = null;
    };
  }, []);

  const advanceToRevealed = () => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (revealTimerRef.current) {
      clearTimeout(revealTimerRef.current);
      revealTimerRef.current = null;
    }
    // Use flushSync to force a synchronous state update — needed because
    // React 19's concurrent rendering can defer/batch state updates from
    // RAF/setTimeout callbacks, causing the phase to never advance.
    flushSync(() => {
      setPhase("revealed");
    });
  };

  const beginRafReveal = () => {
    revealStartRef.current = performance.now();
    const tick = () => {
      if (performance.now() - revealStartRef.current >= 1300) {
        advanceToRevealed();
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    revealTimerRef.current = setTimeout(advanceToRevealed, 1800);
  };

  const vehicle = getVehicle(selectedId)!;
  const color = vehicle.colors[0];

  const discover = () => {
    setPhase("revealing");
    beginRafReveal();
  };

  const surpriseAgain = () => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (revealTimerRef.current) {
      clearTimeout(revealTimerRef.current);
      revealTimerRef.current = null;
    }
    setPhase("mystery");
    rollRandom();
  };

  const scrimOpacity =
    phase === "mystery" ? 0.82 : phase === "revealing" ? 0.4 : 0;

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="void" grain={grain} />

      {/* The car — emerging from shadow */}
      <div className="absolute inset-0">
        <CarViewer3D
          vehicle={vehicle}
          color={color}
          cameraPosition={[4.8, 1.3, 5.2]}
          cameraTarget={[0, 0.4, 0]}
          autoRotate={phase !== "mystery"}
          enableZoom={phase === "revealed"}
          revealOpacity={phase === "mystery" ? 0.35 : 1}
          polarRange={[0.3, Math.PI / 2 - 0.04]}
          quality="balanced"
        />
      </div>

      {/* Reveal scrim — Rembrandt shadow + soft blur during mystery */}
      <motion.div
        className="pointer-events-none absolute inset-0 bg-[#050608]"
        animate={{ opacity: scrimOpacity }}
        transition={{ duration: phase === "revealing" ? 1.2 : 0.6, ease: [0.22, 1, 0.36, 1] }}
        style={{
          backdropFilter: phase === "mystery" ? "blur(8px)" : "blur(0px)",
          WebkitBackdropFilter: phase === "mystery" ? "blur(8px)" : "blur(0px)",
        }}
      />

      {/* Top-left: back */}
      <div className="absolute left-6 top-6 z-20 sm:left-10 sm:top-8">
        <CornerReturn label="Back" onClick={() => goBack()} />
      </div>

      {/* Left typography */}
      <div className="absolute left-6 top-1/2 z-20 -translate-y-1/2 sm:left-10 sm:max-w-sm">
        <motion.span
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray"
        >
          CARIO / 03
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="mt-2 font-display text-3xl font-light tracking-tight-2 text-cario-white sm:text-4xl"
        >
          Random Car
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="mt-2 text-sm text-cario-soft-gray"
        >
          Let CARIO choose.
        </motion.p>

        {/* Reveal name/year */}
        <AnimatePresence>
          {phase === "revealed" && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="mt-8 flex flex-col gap-2"
            >
              <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray/70">
                {vehicle.brand} · {vehicle.generation} · {vehicle.year}
              </span>
              <span className="font-display text-2xl font-medium tracking-tight-2 text-cario-white">
                {vehicle.model}
              </span>
              <span className="max-w-[18rem] text-[12px] italic leading-relaxed text-cario-soft-gray">
                {vehicle.tagline}
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom controls */}
      <div className="absolute inset-x-0 bottom-0 z-20 flex flex-col items-center gap-4 pb-8 sm:pb-10">
        <AnimatePresence mode="wait">
          {phase === "mystery" && (
            <motion.div
              key="mystery"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center gap-4"
            >
              <PrimaryButton onClick={discover} label="Discover" index="01" />
              <GhostButton onClick={surpriseAgain} label="Surprise me again" />
            </motion.div>
          )}
          {phase === "revealing" && (
            <motion.div
              key="revealing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="h-px w-32 overflow-hidden bg-white/10">
                <motion.div
                  className="h-full bg-cario-light-gray"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                />
              </div>
              <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                Revealing
              </span>
            </motion.div>
          )}
          {phase === "revealed" && (
            <motion.div
              key="revealed"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center gap-4"
            >
              <PrimaryButton
                onClick={() => selectVehicle(vehicle.id)}
                label="Enter Experience"
                index="02"
              />
              <GhostButton onClick={surpriseAgain} label="Surprise me again" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

function PrimaryButton({
  onClick,
  label,
  index,
}: {
  onClick: () => void;
  label: string;
  index: string;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ y: -2 }}
      whileTap={{ y: 0 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className="group relative flex items-center gap-4 rounded-full border border-white/15 bg-white/[0.04] px-8 py-3.5 text-cario-white backdrop-blur-md transition-colors hover:border-white/30 hover:bg-white/[0.08]"
    >
      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
        {index}
      </span>
      <span className="font-display text-sm font-medium uppercase tracking-wider-2">
        {label}
      </span>
      <span className="text-cario-soft-gray transition-transform group-hover:translate-x-1">→</span>
    </motion.button>
  );
}

function GhostButton({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ y: -1 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray transition-colors hover:text-cario-light-gray"
    >
      {label}
    </motion.button>
  );
}
