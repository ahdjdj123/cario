"use client";

import { motion } from "framer-motion";
import { useCario, useActiveColor } from "@/lib/cario/store";
import type { Vehicle, VehicleColor } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   ColorStudio — compact exterior paint selector
   ------------------------------------------------------------
   Per the brief: keep it compact, never a giant color-picker.
   A horizontal row of swatches with the active color name +
   finish beneath. Selecting updates the 3D material instantly
   via the store's activeColorId.
   ============================================================ */

export function ColorStudio({ vehicle }: { vehicle: Vehicle }) {
  const active = useActiveColor(vehicle);
  const setColor = useCario((s) => s.setColor);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-3"
    >
      {/* Swatches */}
      <div className="flex items-center gap-3">
        {vehicle.colors.map((c) => (
          <Swatch
            key={c.id}
            color={c}
            active={c.id === active.id}
            onClick={() => setColor(vehicle.id, c.id)}
          />
        ))}
      </div>

      {/* Active color name + finish */}
      <div className="flex flex-col items-center gap-0.5">
        <span className="font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
          {active.name}
        </span>
        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
          {active.finish} finish
        </span>
      </div>
    </motion.div>
  );
}

function Swatch({
  color,
  active,
  onClick,
}: {
  color: VehicleColor;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={color.name}
      className={cn(
        "group relative h-9 w-9 rounded-full transition-transform duration-300 hover:scale-105",
        active && "scale-110"
      )}
    >
      {/* Outer ring on active */}
      <span
        className={cn(
          "absolute -inset-1.5 rounded-full border transition-opacity duration-300",
          active ? "border-white/40 opacity-100" : "border-transparent opacity-0"
        )}
      />
      {/* Swatch */}
      <span
        className="block h-full w-full rounded-full border border-white/10 shadow-inner"
        style={{
          background: `radial-gradient(circle at 30% 25%, ${lighten(color.hex, 0.18)} 0%, ${color.hex} 55%, ${darken(color.hex, 0.25)} 100%)`,
        }}
      />
      {/* Sheen */}
      <span
        className="pointer-events-none absolute inset-0 rounded-full opacity-60"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.25) 0%, transparent 40%)",
        }}
      />
    </button>
  );
}

function lighten(hex: string, amt: number) {
  return mix(hex, "#ffffff", amt);
}
function darken(hex: string, amt: number) {
  return mix(hex, "#000000", amt);
}
function mix(a: string, b: string, t: number) {
  const pa = parse(a);
  const pb = parse(b);
  const r = Math.round(pa[0] + (pb[0] - pa[0]) * t);
  const g = Math.round(pa[1] + (pb[1] - pa[1]) * t);
  const bl = Math.round(pa[2] + (pb[2] - pa[2]) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}
function parse(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [
    parseInt(h.substring(0, 2), 16),
    parseInt(h.substring(2, 4), 16),
    parseInt(h.substring(4, 6), 16),
  ];
}
