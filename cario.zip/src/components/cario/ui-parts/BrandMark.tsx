"use client";

import { cn } from "@/lib/utils";

/* CARIO brand wordmark — restrained, wide-tracked, light weight. */
export function BrandMark({
  className,
  size = "md",
  as = "div",
}: {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  as?: "div" | "h1" | "h2" | "span";
}) {
  const sizes: Record<string, string> = {
    sm: "text-[13px] tracking-[0.42em]",
    md: "text-base tracking-[0.42em]",
    lg: "text-xl tracking-[0.44em] sm:text-2xl",
    xl: "text-2xl tracking-[0.46em] sm:text-3xl",
  };
  const Tag = as as React.ElementType;
  return (
    <Tag
      className={cn(
        "font-display font-light text-cario-white",
        sizes[size],
        className
      )}
      style={{ textIndent: "0.42em" }}
    >
      CARIO
    </Tag>
  );
}

/* Small uppercase label with a leading tick mark. */
export function MicroLabel({
  children,
  className,
  tick = true,
}: {
  children: React.ReactNode;
  className?: string;
  tick?: boolean;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-[10px] uppercase tracking-label text-cario-soft-gray",
        className
      )}
    >
      {tick && <span className="inline-block h-px w-3 bg-cario-soft-gray/50" />}
      {children}
    </span>
  );
}
