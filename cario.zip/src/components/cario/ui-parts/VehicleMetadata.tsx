"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Vehicle } from "@/lib/vehicles";

/* ============================================================
   VehicleMetadata — minimal, restrained spec display
   ------------------------------------------------------------
   Shows horsepower / 0-100 / top-speed (and optionally weight +
   drivetrain when verbose). Never a dashboard — just three or
   five figures, set tight, with small labels.
   ============================================================ */

export function VehicleMetadata({
  vehicle,
  verbose = false,
  align = "left",
  className,
}: {
  vehicle: Vehicle;
  verbose?: boolean;
  align?: "left" | "center" | "right";
  className?: string;
}) {
  const items = [
    { label: "Power", value: `${vehicle.spec.horsepower}`, unit: "HP" },
    { label: "0–100", value: `${vehicle.spec.acceleration}`, unit: "s" },
    { label: "Top", value: `${vehicle.spec.topSpeed}`, unit: "km/h" },
  ];
  if (verbose && vehicle.spec.weight) {
    items.push({ label: "Weight", value: `${vehicle.spec.weight}`, unit: "kg" });
  }
  if (verbose && vehicle.spec.drivetrain) {
    items.push({ label: "Drive", value: vehicle.spec.drivetrain, unit: "" });
  }

  const alignCls =
    align === "center"
      ? "items-center text-center"
      : align === "right"
      ? "items-end text-right ml-auto"
      : "items-start text-left";

  return (
    <div className={cn("flex flex-col gap-4", alignCls, className)}>
      {/* Model name */}
      <div className={cn("flex flex-col gap-1", alignCls)}>
        <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
          {vehicle.brand} · {vehicle.generation} · {vehicle.year}
        </span>
        <h2 className="font-display text-xl font-medium tracking-tight-2 text-cario-white sm:text-2xl">
          {vehicle.model}
        </h2>
      </div>

      {/* Spec row */}
      <div className={cn("flex flex-wrap gap-x-6 gap-y-3", alignCls)}>
        {items.map((it, i) => (
          <motion.div
            key={it.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col gap-0.5"
          >
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
              {it.label}
            </span>
            <span className="flex items-baseline gap-1">
              <span className="font-display text-lg font-light tabular-nums text-cario-white">
                {it.value}
              </span>
              {it.unit && (
                <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                  {it.unit}
                </span>
              )}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   VehicleTag — tiny brand · generation chip
   ============================================================ */

export function VehicleTag({ vehicle }: { vehicle: Vehicle }) {
  return (
    <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
      <span>{vehicle.brand}</span>
      <span className="h-3 w-px bg-cario-soft-gray/30" />
      <span>{vehicle.generation}</span>
      <span className="h-3 w-px bg-cario-soft-gray/30" />
      <span>{vehicle.year}</span>
    </div>
  );
}
