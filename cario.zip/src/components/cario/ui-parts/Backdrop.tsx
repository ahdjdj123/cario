"use client";

import { cn } from "@/lib/utils";

/* ============================================================
   Backdrop — the shared cinematic studio background
   ------------------------------------------------------------
   A near-black radial gradient + subtle floor sheen + optional
   grain overlay. Sits behind every screen. The 3D canvas renders
   transparent on top of it.
   ============================================================ */

export function Backdrop({
  grain = true,
  variant = "studio",
  className,
}: {
  grain?: boolean;
  variant?: "studio" | "deep" | "spotlight" | "void";
  className?: string;
}) {
  const gradient =
    variant === "deep"
      ? "radial-gradient(ellipse at 50% 38%, #111316 0%, #08090B 55%, #050608 100%)"
      : variant === "spotlight"
      ? "radial-gradient(ellipse 60% 50% at 50% 42%, #181A1E 0%, #0B0D10 45%, #08090B 78%, #050608 100%)"
      : variant === "void"
      ? "radial-gradient(ellipse at 50% 50%, #0A0B0D 0%, #050608 70%, #020203 100%)"
      : "radial-gradient(ellipse 70% 60% at 50% 40%, #111316 0%, #08090B 60%, #050608 100%)";

  return (
    <div className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      {/* Base gradient */}
      <div className="absolute inset-0" style={{ background: gradient }} />
      {/* Floor sheen — a soft horizontal band near the bottom */}
      <div
        className="absolute inset-x-0 bottom-0 h-1/3"
        style={{
          background:
            "linear-gradient(to top, rgba(133,137,144,0.06), transparent)",
        }}
      />
      {/* Top vignette */}
      <div
        className="absolute inset-x-0 top-0 h-1/3"
        style={{
          background:
            "linear-gradient(to bottom, rgba(5,6,8,0.6), transparent)",
        }}
      />
      {/* Grain */}
      {grain && (
        <div
          className="absolute inset-0 opacity-[0.05] mix-blend-overlay"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
          }}
        />
      )}
      {/* Outer vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 45%, rgba(5,6,8,0.55) 100%)",
        }}
      />
    </div>
  );
}
