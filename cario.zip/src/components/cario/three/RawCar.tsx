"use client";

import { forwardRef, useMemo } from "react";
import * as THREE from "three";
import type { RawBodyParams, VehicleColor } from "@/lib/vehicles/types";

/* ============================================================
   LEVEL 1 — RAW 3D procedural vehicle
   ------------------------------------------------------------
   A single forwardRef group that renders a low-slung sports car
   silhouette from the `RawBodyParams` descriptor. Each vehicle
   in the dataset gets a distinct shape (long-hood GT vs mid-engine
   supercar vs wedge hypercar) without requiring bespoke GLB assets.

   The paint material is driven by the active `VehicleColor` so
   the Color Studio can swap finishes instantly. This is the
   Level-1 foundation that Level-2 / Level-3 GLB models can later
   replace by simply dropping a URL into `assets.exterior` —
   the rest of the app stays the same.
   ============================================================ */

export interface RawCarProps {
  body: RawBodyParams;
  color: VehicleColor;
  hideLights?: boolean;
  silhouette?: boolean;
  opacity?: number;
}

/* Height multipliers — give the RAW silhouette realistic car
   proportions instead of a flat slab (sports cars h/l ≈ 0.2). */
const HB_SCALE = 1.55;
const HC_SCALE = 1.7;

/* Lower body profile: hood → cowl → beltline (under greenhouse) →
   rear deck → tail → underbody. The greenhouse is a separate
   raked glass prism sitting on the beltline. */
function buildProfile(raw: RawBodyParams): THREE.Shape {
  const L = raw.length * 4.0;
  const Hb = raw.height * HB_SCALE;
  const nose = raw.noseRatio;
  const cab = raw.cabinRatio;
  const wedge = raw.wedge;

  const front = L / 2;
  const rear = -L / 2;
  const clearance = 0.12;

  const wsBaseX = front - nose * (L * 0.5) - 0.25;   // windshield base
  const rake = 0.62;
  const roofFrontX = wsBaseX - rake;                  // top of windshield
  const roofLen = 0.95 + cab * 0.35;
  const roofRearX = roofFrontX - roofLen;             // top of rear window
  const deckX = roofRearX - 0.4;                      // base of rear window
  const noseDrop = Math.tan((wedge * Math.PI) / 180) * (L * 0.5);
  const hoodFrontY = Math.max(Hb * 0.55, Hb * 0.66 - noseDrop);

  const s = new THREE.Shape();
  s.moveTo(front - 0.08, clearance);
  // Front splitter up to bumper
  s.lineTo(front - 0.08, Hb * 0.4);
  s.lineTo(front - 0.04, Hb * 0.5);
  // Hood front lip
  s.lineTo(front - 0.02, hoodFrontY * 0.92);
  // Hood gentle rise toward cowl
  s.lineTo(wsBaseX + 0.22, Hb * 0.64);
  s.lineTo(wsBaseX, Hb * 0.72);
  // Beltline runs under the greenhouse at shoulder height
  s.lineTo(deckX, Hb * 0.72);
  // Rear deck sloping to tail
  s.lineTo(rear + 0.1, Hb * 0.66);
  // Tail down
  s.lineTo(rear + 0.07, Hb * 0.42);
  s.lineTo(rear + 0.07, clearance);
  // Underbody back to front
  s.lineTo(front - 0.08, clearance);
  return s;
}

function buildBodyGeometry(raw: RawBodyParams) {
  const shape = buildProfile(raw);
  const W = raw.track * 1.95;
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: W,
    bevelEnabled: true,
    bevelThickness: 0.06,
    bevelSize: 0.07,
    bevelSegments: 3,
    curveSegments: 6,
  });
  geo.translate(0, 0, -W / 2);
  geo.computeVertexNormals();
  return geo;
}

/* Greenhouse glass — a raked prism: windshield + roof + rear window.
   Built as an extruded trapezoid (side profile) so the windshield
   and rear glass have proper rake instead of 90° block edges. */
function buildGreenhouseGeometry(raw: RawBodyParams) {
  const L = raw.length * 4.0;
  const Hb = raw.height * HB_SCALE;
  const Hc = raw.roof * HC_SCALE;
  const nose = raw.noseRatio;
  const cab = raw.cabinRatio;

  const front = L / 2;
  const wsBaseX = front - nose * (L * 0.5) - 0.25;
  const rake = 0.62;
  const roofFrontX = wsBaseX - rake;
  const roofLen = 0.95 + cab * 0.35;
  const roofRearX = roofFrontX - roofLen;
  const deckX = roofRearX - 0.4;

  const s = new THREE.Shape();
  // Beltline (bottom) — left to right
  s.moveTo(deckX, Hb * 0.72);
  s.lineTo(wsBaseX, Hb * 0.72);
  // Windshield rake up to roof
  s.lineTo(roofFrontX, Hb + Hc);
  // Roof
  s.lineTo(roofRearX, Hb + Hc);
  // Rear window rake down to deck
  s.lineTo(deckX, Hb * 0.72);

  const W = raw.track * 1.95;
  const geo = new THREE.ExtrudeGeometry(s, {
    depth: W * 0.82,
    bevelEnabled: true,
    bevelThickness: 0.02,
    bevelSize: 0.03,
    bevelSegments: 2,
    curveSegments: 4,
  });
  geo.translate(0, 0, -(W * 0.82) / 2);
  geo.computeVertexNormals();
  return geo;
}

function Wheel({
  position,
  radius,
  width,
}: {
  position: [number, number, number];
  radius: number;
  width: number;
}) {
  // Materials — built once per Wheel instance via useMemo
  const tire = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#0A0B0D", metalness: 0.25, roughness: 0.78 }),
    []
  );
  const rim = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#C9CBD0", metalness: 0.95, roughness: 0.24 }),
    []
  );
  const rimDark = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#1A1C1F", metalness: 0.7, roughness: 0.45 }),
    []
  );
  const disc = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#3A3D42", metalness: 0.85, roughness: 0.35 }),
    []
  );
  const caliper = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#858990", metalness: 0.6, roughness: 0.4, emissive: "#3A3D42", emissiveIntensity: 0.15 }),
    []
  );
  return (
    <group position={position} rotation={[Math.PI / 2, 0, 0]}>
      {/* Tire — main carcass */}
      <mesh material={tire} castShadow>
        <cylinderGeometry args={[radius, radius, width, 36]} />
      </mesh>
      {/* Tire tread band (slightly larger, gives a shoulder) */}
      <mesh material={tire}>
        <torusGeometry args={[radius * 0.96, radius * 0.07, 10, 36]} />
      </mesh>
      <mesh material={tire} rotation={[Math.PI, 0, 0]}>
        <torusGeometry args={[radius * 0.96, radius * 0.07, 10, 36]} />
      </mesh>

      {/* Brake disc (rotor) — sits inside the wheel, slightly inset */}
      <mesh material={disc} position={[0, width * 0.32, 0]}>
        <cylinderGeometry args={[radius * 0.74, radius * 0.74, 0.018, 32]} />
      </mesh>
      {/* Brake disc inner face (the other side) */}
      <mesh material={disc} position={[0, -width * 0.32, 0]} rotation={[Math.PI, 0, 0]}>
        <cylinderGeometry args={[radius * 0.74, radius * 0.74, 0.018, 32]} />
      </mesh>
      {/* Brake caliper — a small block on the outer edge of the disc */}
      <mesh material={caliper} position={[0, width * 0.32, radius * 0.55]}>
        <boxGeometry args={[0.04, 0.06, radius * 0.22]} />
      </mesh>
      <mesh material={caliper} position={[0, -width * 0.32, radius * 0.55]}>
        <boxGeometry args={[0.04, 0.06, radius * 0.22]} />
      </mesh>

      {/* Rim barrel — the rim hoop between tire and spokes */}
      <mesh material={rim} position={[0, width * 0.34, 0]}>
        <cylinderGeometry args={[radius * 0.7, radius * 0.7, 0.02, 30]} />
      </mesh>
      <mesh material={rim} position={[0, -width * 0.34, 0]} rotation={[Math.PI, 0, 0]}>
        <cylinderGeometry args={[radius * 0.7, radius * 0.7, 0.02, 30]} />
      </mesh>

      {/* Rim face — outer lip */}
      <mesh material={rim} position={[0, width / 2 + 0.005, 0]}>
        <torusGeometry args={[radius * 0.66, 0.018, 10, 32]} />
      </mesh>
      <mesh material={rim} position={[0, -width / 2 - 0.005, 0]} rotation={[Math.PI, 0, 0]}>
        <torusGeometry args={[radius * 0.66, 0.018, 10, 32]} />
      </mesh>

      {/* Center cap */}
      <mesh material={rim} position={[0, width / 2 + 0.018, 0]}>
        <cylinderGeometry args={[radius * 0.18, radius * 0.18, 0.025, 18]} />
      </mesh>
      <mesh material={rimDark} position={[0, width / 2 + 0.022, 0]}>
        <cylinderGeometry args={[radius * 0.1, radius * 0.1, 0.022, 18]} />
      </mesh>

      {/* Multi-spoke rim — Y-spoke design (10 spokes, double-armed) */}
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => {
        const angle = (i * Math.PI * 2) / 10;
        return (
          <group key={i} rotation={[0, 0, angle]}>
            {/* Main spoke */}
            <mesh material={rim} position={[0, width / 2 + 0.012, radius * 0.42]}>
              <boxGeometry args={[radius * 0.07, 0.022, radius * 0.62]} />
            </mesh>
            {/* Y-branch (only on alternate spokes for a Y pattern) */}
            {i % 2 === 0 && (
              <>
                <mesh
                  material={rim}
                  position={[radius * 0.04, width / 2 + 0.012, radius * 0.5]}
                  rotation={[0, 0.4, 0]}
                >
                  <boxGeometry args={[radius * 0.05, 0.02, radius * 0.4]} />
                </mesh>
                <mesh
                  material={rim}
                  position={[-radius * 0.04, width / 2 + 0.012, radius * 0.5]}
                  rotation={[0, -0.4, 0]}
                >
                  <boxGeometry args={[radius * 0.05, 0.02, radius * 0.4]} />
                </mesh>
              </>
            )}
          </group>
        );
      })}
    </group>
  );
}

function Wing({ raw, trimMat }: { raw: RawBodyParams; trimMat: THREE.Material }) {
  const L = raw.length * 4.0;
  const W = raw.track * 1.95;
  const size = raw.wing;
  if (size <= 0) return null;
  const Hb = raw.height * HB_SCALE;
  const Hc = raw.roof * HC_SCALE;
  const wingY = Hb + Hc + 0.04 + size * 0.16;
  const wingX = -L / 2 + 0.22;
  const wingW = W * (0.5 + size * 0.28);
  return (
    <group>
      <mesh position={[wingX + 0.14, wingY - 0.2, 0]} material={trimMat} castShadow>
        <boxGeometry args={[0.03, 0.4, 0.03]} />
      </mesh>
      <mesh position={[wingX + 0.14, wingY - 0.2, wingW / 2 - 0.06]} material={trimMat} castShadow>
        <boxGeometry args={[0.03, 0.4, 0.03]} />
      </mesh>
      <mesh position={[wingX + 0.14, wingY - 0.2, -wingW / 2 + 0.06]} material={trimMat} castShadow>
        <boxGeometry args={[0.03, 0.4, 0.03]} />
      </mesh>
      <mesh position={[wingX, wingY, 0]} material={trimMat} castShadow>
        <boxGeometry args={[0.26, 0.035, wingW]} />
      </mesh>
    </group>
  );
}

export const RawCar = forwardRef<THREE.Group, RawCarProps>(function RawCar(
  { body, color, hideLights = false, silhouette = false, opacity = 1 },
  ref
) {
  const bodyGeo = useMemo(() => buildBodyGeometry(body), [body]);
  const greenhouseGeo = useMemo(() => buildGreenhouseGeometry(body), [body]);
  const W = body.track * 1.95;
  const L = body.length * 4.0;
  const Hb = body.height * HB_SCALE;
  const Hc = body.roof * HC_SCALE;

  const paintMat = useMemo(() => {
    // Use MeshPhysicalMaterial so we get a clearcoat — gives premium
    // lacquer reflections on top of the metallic base coat.
    const m = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color.hex),
      metalness: color.metalness ?? 0.9,
      roughness: color.roughness ?? 0.25,
      envMapIntensity: silhouette ? 0.4 : 1.5,
      clearcoat: color.clearcoat ?? 0.8,
      clearcoatRoughness: 0.12,
      clearcoatMap: null as unknown as THREE.Texture | null,
      transparent: opacity < 1,
      opacity,
    });
    return m;
  }, [color, opacity, silhouette]);

  const glassMat = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: silhouette ? "#0A0B0D" : "#0C0E12",
        metalness: 0.4,
        roughness: 0.05,
        envMapIntensity: 2.4,
        transparent: true,
        opacity: silhouette ? 1 : 0.78,
        transmission: silhouette ? 0 : 0.18,
        ior: 1.45,
        clearcoat: 1,
        clearcoatRoughness: 0.04,
      }),
    [silhouette]
  );

  const trimMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#0A0B0D", metalness: 0.5, roughness: 0.6 }),
    []
  );

  const lightMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: silhouette ? "#0A0B0D" : "#F3F3F1",
        emissive: silhouette ? "#000000" : "#C9CBD0",
        emissiveIntensity: 0.6,
        metalness: 0.1,
        roughness: 0.3,
      }),
    [silhouette]
  );

  const tailMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: silhouette ? "#0A0B0D" : "#1A0606",
        emissive: silhouette ? "#000000" : "#6A1818",
        emissiveIntensity: 0.45,
        metalness: 0.2,
        roughness: 0.5,
      }),
    [silhouette]
  );

  // Wheel stations
  const frontAxleX = L / 2 - body.noseRatio * L * 0.62 - 0.3;
  const rearAxleX = -L / 2 + 0.66;
  const wheelY = body.wheelRadius;
  const wheelZ = W / 2 - 0.04;
  const wheelR = body.wheelRadius;
  const wheelW = body.wheelWidth;

  return (
    <group ref={ref} dispose={null}>
      {/* Solid lower car body — hood, beltline, rear deck, tail */}
      <mesh geometry={bodyGeo} material={paintMat} castShadow receiveShadow />

      {/* Greenhouse glass — raked windshield + roof + rear window prism */}
      <mesh geometry={greenhouseGeo} material={glassMat} castShadow />

      {/* Side window insets — dark glazing on the greenhouse sides */}
      {!silhouette && (
        <>
          <SideWindowGlass body={body} side={1} />
          <SideWindowGlass body={body} side={-1} />
        </>
      )}

      {/* Front splitter */}
      <mesh position={[L / 2 - 0.05, 0.1, 0]} material={trimMat} castShadow>
        <boxGeometry args={[0.07, 0.05, W - 0.12]} />
      </mesh>
      {/* Rear diffuser */}
      <mesh position={[-L / 2 + 0.06, 0.1, 0]} material={trimMat} castShadow>
        <boxGeometry args={[0.1, 0.07, W - 0.14]} />
      </mesh>
      {/* Side skirts */}
      <mesh position={[0, 0.16, W / 2 - 0.02]} material={trimMat} castShadow>
        <boxGeometry args={[L * 0.64, 0.05, 0.025]} />
      </mesh>
      <mesh position={[0, 0.16, -W / 2 + 0.02]} material={trimMat} castShadow>
        <boxGeometry args={[L * 0.64, 0.05, 0.025]} />
      </mesh>

      {/* Wheels */}
      <Wheel position={[frontAxleX, wheelY, wheelZ]} radius={wheelR} width={wheelW} />
      <Wheel position={[frontAxleX, wheelY, -wheelZ]} radius={wheelR} width={wheelW} />
      <Wheel position={[rearAxleX, wheelY, wheelZ]} radius={wheelR} width={wheelW} />
      <Wheel position={[rearAxleX, wheelY, -wheelZ]} radius={wheelR} width={wheelW} />

      {/* Wing */}
      <Wing raw={body} trimMat={trimMat} />

      {/* Side mirrors */}
      {!silhouette && (
        <>
          <mesh position={[L / 2 - 1.0, Hb * 0.85, W / 2 + 0.05]} castShadow>
            <boxGeometry args={[0.05, 0.05, 0.1]} />
            <meshStandardMaterial color="#0E0F11" metalness={0.6} roughness={0.4} />
          </mesh>
          <mesh position={[L / 2 - 1.0, Hb * 0.85, -W / 2 - 0.05]} castShadow>
            <boxGeometry args={[0.05, 0.05, 0.1]} />
            <meshStandardMaterial color="#0E0F11" metalness={0.6} roughness={0.4} />
          </mesh>
        </>
      )}

      {/* Headlights — recessed lenses with glass + emissive + housing */}
      {!hideLights && (
        <>
          {/* Right headlight (z+) */}
          <group position={[L / 2 - 0.08, Hb * 0.58, W * 0.32]}>
            {/* housing */}
            <mesh material={trimMat} castShadow>
              <boxGeometry args={[0.06, 0.09, 0.26]} />
            </mesh>
            {/* lens */}
            <mesh position={[0.03, 0, 0]} material={lightMat}>
              <boxGeometry args={[0.02, 0.06, 0.22]} />
            </mesh>
            {/* inner emissive projector */}
            <mesh position={[-0.005, 0, 0]}>
              <cylinderGeometry args={[0.04, 0.04, 0.05, 18]} rotation={[0, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#0A0B0D" emissive="#C9CBD0" emissiveIntensity={0.7} metalness={0.2} roughness={0.4} />
            </mesh>
          </group>
          {/* Left headlight (z-) */}
          <group position={[L / 2 - 0.08, Hb * 0.58, -W * 0.32]}>
            <mesh material={trimMat} castShadow>
              <boxGeometry args={[0.06, 0.09, 0.26]} />
            </mesh>
            <mesh position={[0.03, 0, 0]} material={lightMat}>
              <boxGeometry args={[0.02, 0.06, 0.22]} />
            </mesh>
            <mesh position={[-0.005, 0, 0]}>
              <cylinderGeometry args={[0.04, 0.04, 0.05, 18]} rotation={[0, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#0A0B0D" emissive="#C9CBD0" emissiveIntensity={0.7} metalness={0.2} roughness={0.4} />
            </mesh>
          </group>
        </>
      )}

      {/* Taillight strip — slim LED bar with glass cover */}
      {!hideLights && (
        <group position={[-L / 2 + 0.08, Hb * 0.6, 0]}>
          {/* housing */}
          <mesh material={trimMat}>
            <boxGeometry args={[0.04, 0.07, W * 0.72]} />
          </mesh>
          {/* emissive LED bar */}
          <mesh position={[0.025, 0, 0]} material={tailMat}>
            <boxGeometry args={[0.015, 0.05, W * 0.7]} />
          </mesh>
        </group>
      )}

      {/* Side intakes — for mid-engine supercars (high aggressiveness) */}
      {!silhouette && body.aggressiveness > 0.7 && (
        <>
          {/* Right side intake */}
          <mesh
            position={[body.length * 4.0 * -0.1, Hb * 0.55, W / 2 - 0.02]}
            material={trimMat}
            castShadow
          >
            <boxGeometry args={[0.4, 0.12, 0.04]} />
          </mesh>
          <mesh
            position={[body.length * 4.0 * -0.1, Hb * 0.55, -W / 2 + 0.02]}
            material={trimMat}
            castShadow
          >
            <boxGeometry args={[0.4, 0.12, 0.04]} />
          </mesh>
          {/* intake blade (horizontal fin) */}
          <mesh
            position={[body.length * 4.0 * -0.1, Hb * 0.6, W / 2 + 0.04]}
            rotation={[0, 0, 0.2]}
          >
            <boxGeometry args={[0.36, 0.02, 0.08]} />
            <meshStandardMaterial color="#1A1C1F" metalness={0.7} roughness={0.4} />
          </mesh>
          <mesh
            position={[body.length * 4.0 * -0.1, Hb * 0.6, -W / 2 - 0.04]}
            rotation={[0, 0, 0.2]}
          >
            <boxGeometry args={[0.36, 0.02, 0.08]} />
            <meshStandardMaterial color="#1A1C1F" metalness={0.7} roughness={0.4} />
          </mesh>
        </>
      )}

      {/* Character line — a subtle horizontal crease along the body side */}
      {!silhouette && (
        <>
          <mesh
            position={[0, Hb * 0.5, W / 2 + 0.001]}
            material={trimMat}
          >
            <boxGeometry args={[L * 0.7, 0.012, 0.004]} />
          </mesh>
          <mesh
            position={[0, Hb * 0.5, -W / 2 - 0.001]}
            material={trimMat}
          >
            <boxGeometry args={[L * 0.7, 0.012, 0.004]} />
          </mesh>
        </>
      )}

      {/* Wheel arch rings (subtle) */}
      {[
        [frontAxleX, wheelZ],
        [frontAxleX, -wheelZ],
        [rearAxleX, wheelZ],
        [rearAxleX, -wheelZ],
      ].map(([x, z], i) => (
        <mesh key={i} position={[x, wheelY, z]} material={trimMat}>
          <torusGeometry args={[wheelR * 1.12, 0.03, 8, 22, Math.PI]} />
        </mesh>
      ))}
    </group>
  );
});

/* Side window inset — a dark, slightly recessed glass plane fitted
   onto the greenhouse side, giving the cabin a glazed read without
   breaking the raked silhouette. */
function SideWindowGlass({ body, side }: { body: RawBodyParams; side: 1 | -1 }) {
  const L = body.length * 4.0;
  const Hb = body.height * HB_SCALE;
  const Hc = body.roof * HC_SCALE;
  const W = body.track * 1.95;
  const nose = body.noseRatio;
  const cab = body.cabinRatio;

  const wsBaseX = L / 2 - nose * (L * 0.5) - 0.25;
  const rake = 0.62;
  const roofFrontX = wsBaseX - rake;
  const roofLen = 0.95 + cab * 0.35;
  const roofRearX = roofFrontX - roofLen;
  // The side window follows the greenhouse trapezoid; approximate with
  // a thin dark plane sitting just outside the glass extrusion.
  const centerX = (wsBaseX + roofRearX) / 2 + 0.05;
  const width = roofLen + 0.25;
  const yMid = Hb + Hc * 0.5;
  const z = side * (W * 0.82) / 2 + side * 0.004;
  return (
    <mesh position={[centerX, yMid, z]} rotation={[0, 0, side * 0.02]}>
      <boxGeometry args={[width, Hc * 0.78, 0.014]} />
      <meshStandardMaterial color="#050608" metalness={0.1} roughness={0.12} />
    </mesh>
  );
}

