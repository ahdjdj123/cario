"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Html,
  OrbitControls,
} from "@react-three/drei";
import * as THREE from "three";
import { RawCar } from "./RawCar";
import type { Vehicle, VehicleColor } from "@/lib/vehicles/types";

/* ============================================================
   Garage — premium home environment
   ------------------------------------------------------------
   A cinematic automotive studio. The selected (hero) car sits on
   a rotating circular podium in the center. Only the hero car is
   rendered — no background cars — so there is never any visual
   overlap or intersection. The user can orbit/zoom the hero.
   ============================================================ */

export interface GarageProps {
  hero: Vehicle;
  heroColor: VehicleColor;
  autoRotate?: boolean;
  quality?: "performance" | "balanced" | "cinematic";
  className?: string;
}

export function Garage({
  hero,
  heroColor,
  autoRotate = true,
  quality = "balanced",
  className,
}: GarageProps) {
  const dpr: [number, number] =
    quality === "performance"
      ? [1, 1.2]
      : quality === "cinematic"
      ? [1, 2]
      : [1, 1.6];

  return (
    <div className={className} style={{ width: "100%", height: "100%" }}>
      <Canvas
        shadows
        dpr={dpr}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: quality === "cinematic" ? 1.1 : 0.95,
        }}
        camera={{ position: [4.4, 1.5, 5.4], fov: 30, near: 0.1, far: 100 }}
      >
        <Suspense fallback={<Loader />}>
          <GarageLighting quality={quality} />
          <HeroPodium hero={hero} heroColor={heroColor} autoRotate={autoRotate} />
          <GarageArchitecture />
          <ContactShadows
            position={[0, 0.001, 0]}
            opacity={0.55}
            scale={28}
            blur={2.6}
            far={6}
            resolution={quality === "performance" ? 256 : 512}
            color="#000000"
          />
          <Environment preset={quality === "cinematic" ? "studio" : "city"} />
          <OrbitControls
            target={[0, 0.5, 0]}
            enablePan={false}
            enableZoom={true}
            minDistance={3.4}
            maxDistance={9}
            minPolarAngle={0.32}
            maxPolarAngle={Math.PI / 2 - 0.04}
            enableDamping
            dampingFactor={0.08}
            rotateSpeed={0.7}
            zoomSpeed={0.7}
            makeDefault
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

/* --- Premium studio lighting --- */
function GarageLighting({
  quality,
}: {
  quality: "performance" | "balanced" | "cinematic";
}) {
  const keyIntensity = quality === "cinematic" ? 2.4 : 1.9;
  return (
    <>
      <ambientLight intensity={0.32} />
      {/* Key — front-top */}
      <directionalLight
        position={[5, 8, 4]}
        intensity={keyIntensity}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-near={0.5}
        shadow-camera-far={30}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
        shadow-bias={-0.0005}
      />
      {/* Fill — opposite side */}
      <directionalLight position={[-6, 4, -3]} intensity={0.6} color="#C9CBD0" />
      {/* Rim — back-top for separation */}
      <directionalLight position={[0, 6, -8]} intensity={1.2} color="#F3F3F1" />
      {/* Underglow — soft fill from the floor */}
      <pointLight position={[0, -1, 0]} intensity={0.3} color="#858990" distance={8} />
      {/* Overhead pendant lights — long ceiling panel reflections on the floor */}
      {[-3, 0, 3].map((x) => (
        <rectAreaLight
          key={x}
          position={[x, 5.5, 0]}
          width={2.4}
          height={1.0}
          rotation={[-Math.PI / 2, 0, 0]}
          intensity={0.7}
          color="#F3F3F1"
        />
      ))}
    </>
  );
}

/* --- The rotating podium with the hero car --- */
function HeroPodium({
  hero,
  heroColor,
  autoRotate,
}: {
  hero: Vehicle;
  heroColor: VehicleColor;
  autoRotate: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current && autoRotate) {
      ref.current.rotation.y += dt * 0.16;
    }
  });

  return (
    <group>
      {/* Podium disc — circular, slightly raised, with an emissive ring */}
      <mesh position={[0, 0.02, 0]} receiveShadow>
        <cylinderGeometry args={[1.7, 1.75, 0.04, 64]} />
        <meshStandardMaterial color="#111316" metalness={0.5} roughness={0.4} envMapIntensity={0.6} />
      </mesh>
      {/* Podium top — slightly lighter inset */}
      <mesh position={[0, 0.045, 0]} receiveShadow>
        <cylinderGeometry args={[1.62, 1.62, 0.012, 64]} />
        <meshStandardMaterial color="#181A1E" metalness={0.4} roughness={0.45} envMapIntensity={0.7} />
      </mesh>
      {/* Emissive accent ring */}
      <mesh position={[0, 0.05, 0]}>
        <torusGeometry args={[1.68, 0.012, 8, 64]} />
        <meshStandardMaterial color="#F3F3F1" emissive="#858990" emissiveIntensity={0.45} metalness={0.3} roughness={0.3} />
      </mesh>
      {/* Inner second ring for depth */}
      <mesh position={[0, 0.05, 0]}>
        <torusGeometry args={[1.5, 0.006, 8, 64]} />
        <meshStandardMaterial color="#F3F3F1" emissive="#3A3D42" emissiveIntensity={0.25} metalness={0.4} roughness={0.4} />
      </mesh>

      {/* Hero car on the podium */}
      <group ref={ref} position={[0, 0.05, 0]} rotation={[0, -0.4, 0]}>
        <RawCar body={hero.raw} color={heroColor} />
      </group>
    </group>
  );
}

/* --- Architectural elements: floor, ceiling lines, columns --- */
function GarageArchitecture() {
  return (
    <group>
      {/* Floor — large polished dark surface */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#08090B" metalness={0.55} roughness={0.4} envMapIntensity={0.5} />
      </mesh>
      {/* Subtle floor inset grid lines — a few long thin boxes to suggest a tiled floor */}
      {[-8, -4, 0, 4, 8].map((x) => (
        <mesh key={`gx-${x}`} position={[x, 0.002, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[0.02, 30]} />
          <meshStandardMaterial color="#181A1E" metalness={0.3} roughness={0.7} />
        </mesh>
      ))}
      {[-8, -4, 0, 4, 8].map((z) => (
        <mesh key={`gz-${z}`} position={[0, 0.002, z]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[30, 0.02]} />
          <meshStandardMaterial color="#181A1E" metalness={0.3} roughness={0.7} />
        </mesh>
      ))}
      {/* Back wall — subtle vertical surface to ground the composition */}
      <mesh position={[0, 4, -10]} receiveShadow>
        <boxGeometry args={[28, 8, 0.1]} />
        <meshStandardMaterial color="#0B0D10" metalness={0.3} roughness={0.8} />
      </mesh>
      {/* Back wall accent strip — a horizontal light line */}
      <mesh position={[0, 5.6, -9.95]}>
        <boxGeometry args={[24, 0.04, 0.04]} />
        <meshStandardMaterial color="#F3F3F1" emissive="#858990" emissiveIntensity={0.5} metalness={0.3} roughness={0.3} />
      </mesh>
      {/* Side columns — give the garage architectural enclosure */}
      {[-9, 9].map((x) => (
        <mesh key={`col-${x}`} position={[x, 3, -7]} castShadow>
          <boxGeometry args={[0.6, 6, 0.6]} />
          <meshStandardMaterial color="#0B0D10" metalness={0.2} roughness={0.85} />
        </mesh>
      ))}
      {[-9, 9].map((x) => (
        <mesh key={`col2-${x}`} position={[x, 3, 7]} castShadow>
          <boxGeometry args={[0.6, 6, 0.6]} />
          <meshStandardMaterial color="#0B0D10" metalness={0.2} roughness={0.85} />
        </mesh>
      ))}
    </group>
  );
}

function Loader() {
  return (
    <Html center>
      <div className="flex flex-col items-center gap-3 text-cario-soft-gray">
        <div className="h-1 w-12 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/2 animate-pulse bg-white/40" />
        </div>
        <span className="text-[10px] tracking-label uppercase">Loading garage</span>
      </div>
    </Html>
  );
}
