"use client";

import { Suspense, useRef, useState, type ReactNode } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Environment, Html, OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import { RawCar } from "./RawCar";
import type { Vehicle } from "@/lib/vehicles/types";

/* ============================================================
   Showroom — Explore screen
   ------------------------------------------------------------
   Several lightweight 3D vehicles positioned across a large
   dark digital showroom with depth. The user orbits the whole
   space; clicking a car opens its Car Experience.
   ============================================================ */

export interface ShowroomProps {
  vehicles: Vehicle[];
  activeColorFor: (v: Vehicle) => Vehicle["colors"][number];
  onSelect: (id: string) => void;
  selectedId?: string | null;
  className?: string;
}

export function Showroom({
  vehicles,
  activeColorFor,
  onSelect,
  selectedId,
  className,
}: ShowroomProps) {
  return (
    <div className={className} style={{ width: "100%", height: "100%" }}>
      <Canvas
        shadows
        dpr={[1, 1.6]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 0.95,
        }}
        camera={{ position: [0, 2.5, 14], fov: 40, near: 0.1, far: 100 }}
      >
        <Suspense fallback={<Loader />}>
          <ambientLight intensity={0.3} />
          <directionalLight
            position={[6, 9, 4]}
            intensity={1.7}
            castShadow
            shadow-mapSize-width={1024}
            shadow-mapSize-height={1024}
            shadow-camera-near={0.5}
            shadow-camera-far={40}
            shadow-camera-left={-16}
            shadow-camera-right={16}
            shadow-camera-top={16}
            shadow-camera-bottom={-16}
            shadow-bias={-0.0005}
          />
          <directionalLight position={[-8, 5, -4]} intensity={0.5} color="#C9CBD0" />
          <directionalLight position={[0, 6, -10]} intensity={1.0} color="#F3F3F1" />

          {/* Overhead "box" lighting — long ceiling panel reflections on the floor */}
          {[-4, 4].map((z) => (
            <rectAreaLight
              key={z}
              position={[0, 6, z]}
              width={12}
              height={2}
              rotation={[-Math.PI / 2, 0, 0]}
              intensity={0.6}
              color="#F3F3F1"
            />
          ))}

          {/* The lineup */}
          <Lineup
            vehicles={vehicles}
            activeColorFor={activeColorFor}
            onSelect={onSelect}
            selectedId={selectedId}
          />

          <ShowroomFloor />
          <ContactShadows
            position={[0, 0.001, 0]}
            opacity={0.5}
            scale={40}
            blur={2.6}
            far={6}
            resolution={512}
            color="#000000"
          />
          <Environment preset="city" />
          <OrbitControls
            target={[0, 0.4, 0]}
            enablePan={false}
            enableZoom={true}
            minDistance={8}
            maxDistance={30}
            minPolarAngle={0.35}
            maxPolarAngle={Math.PI / 2 - 0.08}
            enableDamping
            dampingFactor={0.08}
            rotateSpeed={0.6}
            makeDefault
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

function Lineup({
  vehicles,
  activeColorFor,
  onSelect,
  selectedId,
}: {
  vehicles: Vehicle[];
  activeColorFor: (v: Vehicle) => Vehicle["colors"][number];
  onSelect: (id: string) => void;
  selectedId?: string | null;
}) {
  // Arrange in a gentle arc — depth of field via position, not postprocessing
  // Spacing is 5.0 to prevent overlap (car bodies are ~4 units long)
  const n = vehicles.length;
  const spacing = 5.0;
  const startX = -((n - 1) * spacing) / 2;

  return (
    <group>
      {vehicles.map((v, i) => {
        const x = startX + i * spacing;
        // Slight arc — cars further from center are pushed back a touch
        const z = Math.abs(i - (n - 1) / 2) * 0.15;
        const isSel = selectedId === v.id;
        return (
          <ShowroomCar
            key={v.id}
            vehicle={v}
            color={activeColorFor(v)}
            position={[x, 0, z]}
            selected={isSel}
            onSelect={() => onSelect(v.id)}
          />
        );
      })}
    </group>
  );
}

function ShowroomCar({
  vehicle,
  color,
  position,
  selected,
  onSelect,
}: {
  vehicle: Vehicle;
  color: Vehicle["colors"][number];
  position: [number, number, number];
  selected: boolean;
  onSelect: () => void;
}) {
  const ref = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);
  useFrame((_, dt) => {
    if (!ref.current) return;
    // subtle idle — only when not hovered/selected
    if (!hovered && !selected) {
      ref.current.rotation.y += dt * 0.06;
    }
  });
  return (
    <group
      position={position}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
        document.body.style.cursor = "pointer";
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        setHovered(false);
        document.body.style.cursor = "auto";
      }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
    >
      <group ref={ref} rotation={[0, -0.4, 0]}>
        <RawCar body={vehicle.raw} color={color} />
      </group>
      {/* Floating plinth label */}
      <Html position={[0, -0.05, 0]} center distanceFactor={11} occlude={false}>
        <div
          className={`pointer-events-none select-none whitespace-nowrap text-center transition-opacity duration-500 ${
            selected || hovered ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="text-[10px] tracking-label uppercase text-cario-soft-gray">
            {vehicle.brand}
          </div>
          <div className="mt-0.5 text-[13px] font-medium tracking-tight-2 text-cario-white">
            {vehicle.model}
          </div>
        </div>
      </Html>
    </group>
  );
}

function ShowroomFloor() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[80, 80]} />
      <meshStandardMaterial color="#08090B" metalness={0.5} roughness={0.45} envMapIntensity={0.4} />
    </mesh>
  );
}

function Loader() {
  return (
    <Html center>
      <div className="flex flex-col items-center gap-3 text-cario-soft-gray">
        <div className="h-1 w-12 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/2 animate-pulse bg-white/40" />
        </div>
        <span className="text-[10px] tracking-label uppercase">Loading showroom</span>
      </div>
    </Html>
  );
}

/* ============================================================
   InteriorScene — LEVEL-1 placeholder cockpit exploration
   ------------------------------------------------------------
   A basic interior cutaway made from primitives. Lets the user
   feel that selecting INTERIOR changes the point of exploration.
   Designed to be replaced by a LEVEL-2/3 interior GLB later.
   ============================================================ */

export function InteriorScene({ vehicle }: { vehicle: Vehicle }) {
  return (
    <div style={{ width: "100%", height: "100%" }}>
      <Canvas
        shadows
        dpr={[1, 1.6]}
        gl={{
          antialias: true,
          alpha: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.35,
        }}
        camera={{ position: [1.4, 0.95, 0.9], fov: 42, near: 0.05, far: 50 }}
      >
        <Suspense fallback={<Loader />}>
          {/* Bright, even interior lighting so the cockpit reads clearly */}
          <ambientLight intensity={0.9} />
          {/* Key — from above-front (through the windshield) */}
          <directionalLight position={[0.3, 1.8, 1.0]} intensity={2.8} color="#F3F3F1" castShadow
            shadow-mapSize-width={1024} shadow-mapSize-height={1024}
            shadow-camera-near={0.1} shadow-camera-far={12}
            shadow-camera-left={-3} shadow-camera-right={3}
            shadow-camera-top={3} shadow-camera-bottom={-3} shadow-bias={-0.0005}
          />
          {/* Fill — from the side */}
          <directionalLight position={[-1.6, 1.0, -0.4]} intensity={1.2} color="#C9CBD0" />
          {/* Back fill — from behind the seats */}
          <directionalLight position={[0.4, 1.2, -2.6]} intensity={0.8} color="#858990" />
          {/* Underdash glow */}
          <pointLight position={[0, 0.45, -1.2]} intensity={0.7} color="#858990" distance={2.5} />
          <Cockpit vehicle={vehicle} />
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, -1]}>
            <planeGeometry args={[8, 8]} />
            <meshStandardMaterial color="#0A0B0D" metalness={0.3} roughness={0.7} />
          </mesh>
          <Environment preset="city" />
          <OrbitControls
            target={[0, 0.5, -1.0]}
            enablePan={false}
            enableZoom={true}
            minDistance={0.5}
            maxDistance={3.5}
            minPolarAngle={0.4}
            maxPolarAngle={Math.PI / 2 - 0.05}
            enableDamping
            dampingFactor={0.08}
            makeDefault
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

function Cockpit({ vehicle }: { vehicle: Vehicle }) {
  // Use a clearly visible, neutral interior palette so the cockpit
  // is always recognizable regardless of the exterior paint colour.
  // Components are sized so a 3/4 elevated front camera frames:
  //   wheel (foreground) → dash → center screen → seats (background)
  return (
    <group position={[0, 0, -1]}>
      {/* Dashboard — medium charcoal, spans the full width */}
      <mesh position={[0, 0.55, 0]} castShadow>
        <boxGeometry args={[2.1, 0.18, 0.55]} />
        <meshStandardMaterial color="#2A2D31" metalness={0.3} roughness={0.65} />
      </mesh>
      {/* Dash top — lighter accent strip on top of the dashboard */}
      <mesh position={[0, 0.66, -0.18]} castShadow>
        <boxGeometry args={[2.0, 0.04, 0.18]} />
        <meshStandardMaterial color="#1A1C1F" metalness={0.4} roughness={0.6} />
      </mesh>

      {/* Instrument binnacle — raised hood behind the wheel */}
      <mesh position={[0, 0.7, 0.06]} rotation={[-0.3, 0, 0]} castShadow>
        <boxGeometry args={[0.55, 0.16, 0.22]} />
        <meshStandardMaterial color="#1A1C1F" metalness={0.4} roughness={0.5} />
      </mesh>

      {/* TFT instrument cluster — bright emissive screen behind the wheel */}
      <mesh position={[0, 0.72, 0.18]} rotation={[-0.3, 0, 0]}>
        <boxGeometry args={[0.5, 0.12, 0.012]} />
        <meshStandardMaterial
          color="#0A0E12"
          emissive="#2A3A4A"
          emissiveIntensity={0.7}
          metalness={0.1}
          roughness={0.2}
        />
      </mesh>
      {/* Two emissive rings + screens inside the cluster (gauges) */}
      <mesh position={[-0.13, 0.73, 0.21]} rotation={[-0.3, 0, 0]}>
        <torusGeometry args={[0.05, 0.008, 12, 28]} />
        <meshStandardMaterial color="#C9CBD0" emissive="#858990" emissiveIntensity={0.5} metalness={0.9} roughness={0.25} />
      </mesh>
      <mesh position={[0.13, 0.73, 0.21]} rotation={[-0.3, 0, 0]}>
        <torusGeometry args={[0.05, 0.008, 12, 28]} />
        <meshStandardMaterial color="#C9CBD0" emissive="#858990" emissiveIntensity={0.5} metalness={0.9} roughness={0.25} />
      </mesh>

      {/* Center infotainment screen — bright, slightly tilted */}
      <mesh position={[0.0, 0.6, 0.16]} rotation={[0.3, 0, 0]}>
        <boxGeometry args={[0.55, 0.26, 0.012]} />
        <meshStandardMaterial
          color="#050608"
          emissive="#1A2230"
          emissiveIntensity={0.55}
          metalness={0.1}
          roughness={0.2}
        />
      </mesh>
      {/* Infotainment bezel */}
      <mesh position={[0.0, 0.6, 0.155]} rotation={[0.3, 0, 0]}>
        <boxGeometry args={[0.6, 0.31, 0.012]} />
        <meshStandardMaterial color="#1A1C1F" metalness={0.5} roughness={0.4} />
      </mesh>

      {/* Climate vent strip — three small circular vents across the dash */}
      {[-0.7, 0, 0.7].map((x) => (
        <group key={`vent-${x}`} position={[x, 0.62, 0.18]}>
          <mesh>
            <torusGeometry args={[0.024, 0.006, 8, 16]} />
            <meshStandardMaterial color="#C9CBD0" metalness={0.85} roughness={0.3} />
          </mesh>
          <mesh position={[0, 0, 0.005]}>
            <circleGeometry args={[0.022, 16]} />
            <meshStandardMaterial color="#0A0B0D" metalness={0.2} roughness={0.6} />
          </mesh>
        </group>
      ))}

      {/* Steering wheel — enlarged, positioned IN FRONT of the dashboard
          (between the driver and the dash, like a real car) so it's
          always visible from any camera angle. Dark rim + silver spokes
          + brand-painted hub. */}
      <group position={[0, 0.5, 0.35]} rotation={[-0.25, 0, 0]}>
        {/* rim */}
        <mesh>
          <torusGeometry args={[0.19, 0.022, 14, 48]} />
          <meshStandardMaterial color="#0A0B0D" metalness={0.4} roughness={0.4} />
        </mesh>
        {/* rim inner grip highlight */}
        <mesh position={[0, 0, 0.005]}>
          <torusGeometry args={[0.19, 0.014, 10, 40]} />
          <meshStandardMaterial color="#1A1C1F" metalness={0.5} roughness={0.35} />
        </mesh>
        {/* three spokes */}
        {[0, 1, 2].map((i) => (
          <group key={`spoke-${i}`} rotation={[0, 0, (i * Math.PI * 2) / 3 - Math.PI / 6]}>
            <mesh position={[0, -0.1, 0]}>
              <boxGeometry args={[0.03, 0.18, 0.025]} />
              <meshStandardMaterial color="#C9CBD0" metalness={0.85} roughness={0.3} />
            </mesh>
          </group>
        ))}
        {/* center hub — brand-painted */}
        <mesh position={[0, 0, 0.015]}>
          <cylinderGeometry args={[0.07, 0.07, 0.025, 24]} />
          <meshStandardMaterial color={vehicle.colors[0].hex} metalness={0.5} roughness={0.45} />
        </mesh>
        {/* hub center cap */}
        <mesh position={[0, 0, 0.028]}>
          <cylinderGeometry args={[0.04, 0.04, 0.02, 18]} />
          <meshStandardMaterial color="#0A0B0D" metalness={0.4} roughness={0.4} />
        </mesh>
      </group>

      {/* Seats — light grey bucket silhouettes for visibility */}
      {[-0.45, 0.45].map((x) => (
        <group key={x} position={[x, 0.25, -0.6]}>
          {/* cushion */}
          <mesh castShadow>
            <boxGeometry args={[0.52, 0.1, 0.5]} />
            <meshStandardMaterial color="#6A6E74" metalness={0.1} roughness={0.75} />
          </mesh>
          {/* backrest — taller for visibility */}
          <mesh position={[0, 0.4, -0.22]} castShadow>
            <boxGeometry args={[0.52, 0.65, 0.08]} />
            <meshStandardMaterial color="#6A6E74" metalness={0.1} roughness={0.75} />
          </mesh>
          {/* side bolsters — darker for contrast */}
          <mesh position={[-0.24, 0.4, -0.18]} castShadow>
            <boxGeometry args={[0.08, 0.58, 0.32]} />
            <meshStandardMaterial color="#4A4E54" metalness={0.1} roughness={0.75} />
          </mesh>
          <mesh position={[0.24, 0.4, -0.18]} castShadow>
            <boxGeometry args={[0.08, 0.58, 0.32]} />
            <meshStandardMaterial color="#4A4E54" metalness={0.1} roughness={0.75} />
          </mesh>
          {/* headrest */}
          <mesh position={[0, 0.78, -0.2]} castShadow>
            <boxGeometry args={[0.28, 0.18, 0.1]} />
            <meshStandardMaterial color="#6A6E74" metalness={0.1} roughness={0.75} />
          </mesh>
          {/* racing harness slot (visual detail) */}
          <mesh position={[0, 0.6, -0.18]}>
            <boxGeometry args={[0.04, 0.08, 0.02]} />
            <meshStandardMaterial color="#0A0B0D" metalness={0.3} roughness={0.5} />
          </mesh>
        </group>
      ))}

      {/* Center console — runs between the seats */}
      <mesh position={[0, 0.4, -0.4]} castShadow>
        <boxGeometry args={[0.22, 0.16, 0.8]} />
        <meshStandardMaterial color="#1A1C1F" metalness={0.4} roughness={0.5} />
      </mesh>
      {/* Console trim — silver accent strip */}
      <mesh position={[0, 0.46, -0.4]}>
        <boxGeometry args={[0.06, 0.02, 0.7]} />
        <meshStandardMaterial color="#C9CBD0" metalness={0.85} roughness={0.3} />
      </mesh>

      {/* Shift lever */}
      <mesh position={[0, 0.5, -0.3]} castShadow>
        <cylinderGeometry args={[0.022, 0.022, 0.22, 14]} />
        <meshStandardMaterial color="#C9CBD0" metalness={0.85} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.62, -0.3]}>
        <sphereGeometry args={[0.035, 18, 18]} />
        <meshStandardMaterial color="#0A0B0D" metalness={0.4} roughness={0.4} />
      </mesh>

      {/* Start button — subtle red glow */}
      <mesh position={[0.12, 0.5, -0.15]}>
        <cylinderGeometry args={[0.022, 0.022, 0.012, 18]} rotation={[0, 0, 0]} />
        <meshStandardMaterial color="#C9CBD0" metalness={0.6} roughness={0.3} emissive="#5A1818" emissiveIntensity={0.8} />
      </mesh>

      {/* Door panels — give the cabin enclosure */}
      {[-1, 1].map((side) => (
        <group key={side} position={[side * 0.95, 0.45, -0.55]}>
          <mesh castShadow>
            <boxGeometry args={[0.06, 0.55, 1.0]} />
            <meshStandardMaterial color="#1A1C1F" metalness={0.3} roughness={0.7} />
          </mesh>
          {/* door pull handle */}
          <mesh position={[side * -0.04, 0.05, 0]}>
            <boxGeometry args={[0.04, 0.04, 0.18]} />
            <meshStandardMaterial color="#C9CBD0" metalness={0.8} roughness={0.3} />
          </mesh>
          {/* door speaker grille */}
          <mesh position={[side * -0.04, -0.15, 0]}>
            <cylinderGeometry args={[0.06, 0.06, 0.02, 24]} rotation={[0, 0, Math.PI / 2]} />
            <meshStandardMaterial color="#0A0B0D" metalness={0.2} roughness={0.6} />
          </mesh>
        </group>
      ))}

      {/* A-pillars + windshield header — gives a clear "interior" framing */}
      {[-1, 1].map((side) => (
        <mesh
          key={`pillar-${side}`}
          position={[side * 0.85, 0.95, 0.45]}
          rotation={[0.35, 0, side * 0.15]}
          castShadow
        >
          <boxGeometry args={[0.06, 0.7, 0.05]} />
          <meshStandardMaterial color="#0A0B0D" metalness={0.4} roughness={0.5} />
        </mesh>
      ))}
      {/* Windshield header bar */}
      <mesh position={[0, 1.05, 0.4]} rotation={[0.35, 0, 0]} castShadow>
        <boxGeometry args={[1.8, 0.05, 0.05]} />
        <meshStandardMaterial color="#0A0B0D" metalness={0.4} roughness={0.5} />
      </mesh>
      {/* Windshield glass — tinted, semi-transparent, raked */}
      <mesh position={[0, 0.75, 0.42]} rotation={[0.35, 0, 0]}>
        <boxGeometry args={[1.7, 0.55, 0.01]} />
        <meshPhysicalMaterial
          color="#0A0E12"
          metalness={0.2}
          roughness={0.05}
          transparent
          opacity={0.32}
          envMapIntensity={1.5}
          transmission={0.4}
          ior={1.45}
        />
      </mesh>

      {/* Rear-view mirror */}
      <mesh position={[0, 0.92, 0.32]} castShadow>
        <boxGeometry args={[0.18, 0.04, 0.06]} />
        <meshStandardMaterial color="#0A0B0D" metalness={0.5} roughness={0.4} />
      </mesh>

      {/* Pedals hint — three small pedals below the dash */}
      {[-0.1, 0, 0.1].map((x, i) => (
        <mesh key={`pedal-${x}`} position={[x, 0.18, 0.32]} castShadow>
          <boxGeometry args={[0.04, 0.06, 0.04]} />
          <meshStandardMaterial color="#C9CBD0" metalness={0.85} roughness={0.3} />
        </mesh>
      ))}
    </group>
  );
}

/* ============================================================
   EngineScene — LEVEL-1 placeholder engine cutaway
   ------------------------------------------------------------
   A basic engine block + ancillaries made from primitives.
   Designed to be replaced by a LEVEL-2/3 engine GLB later.
   ============================================================ */

export function EngineScene({ vehicle }: { vehicle: Vehicle }) {
  return (
    <div style={{ width: "100%", height: "100%" }}>
      <Canvas
        shadows
        dpr={[1, 1.6]}
        gl={{
          antialias: true,
          alpha: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 0.95,
        }}
        camera={{ position: [2.6, 1.8, 2.6], fov: 34, near: 0.1, far: 50 }}
      >
        <Suspense fallback={<Loader />}>
          <ambientLight intensity={0.3} />
          <directionalLight position={[4, 6, 3]} intensity={1.6} castShadow
            shadow-mapSize-width={1024} shadow-mapSize-height={1024}
            shadow-camera-near={0.5} shadow-camera-far={20}
            shadow-camera-left={-6} shadow-camera-right={6}
            shadow-camera-top={6} shadow-camera-bottom={-6} shadow-bias={-0.0005}
          />
          <directionalLight position={[-4, 3, -3]} intensity={0.5} color="#C9CBD0" />
          <EngineBlock vehicle={vehicle} />
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.55, 0]}>
            <planeGeometry args={[10, 10]} />
            <meshStandardMaterial color="#08090B" metalness={0.4} roughness={0.6} />
          </mesh>
          <Environment preset="city" />
          <OrbitControls
            target={[0, 0.2, 0]}
            enablePan={false}
            enableZoom={true}
            minDistance={2.5}
            maxDistance={6}
            minPolarAngle={0.3}
            maxPolarAngle={Math.PI / 2 - 0.05}
            enableDamping
            dampingFactor={0.08}
            makeDefault
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

function EngineBlock({ vehicle }: { vehicle: Vehicle }) {
  // Choose cylinder count heuristic from engine string
  const isV12 = /V12/i.test(vehicle.spec.engine ?? "");
  const isFlat6 = /Flat-6/i.test(vehicle.spec.engine ?? "");
  const isV8 = /V8/i.test(vehicle.spec.engine ?? "");
  const banks = isV12 ? 6 : isFlat6 ? 3 : isV8 ? 4 : 4;
  const vAngle = isFlat6 ? Math.PI / 1.4 : Math.PI / 4.2;

  const blockMat = (
    <meshStandardMaterial color="#1A1C1F" metalness={0.7} roughness={0.45} />
  );
  const headMat = (
    <meshStandardMaterial color="#23262A" metalness={0.6} roughness={0.5} />
  );
  const coverMat = (
    <meshStandardMaterial color={vehicle.colors[0].hex} metalness={0.5} roughness={0.4} />
  );

  return (
    <group position={[0, 0.2, 0]}>
      {/* Crankcase */}
      <mesh position={[0, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[2.4, 0.5, 0.9]} />
        {blockMat}
      </mesh>
      {/* Two cylinder banks */}
      {[-1, 1].map((side) => (
        <group key={side} position={[0, 0.32, side * 0.18]} rotation={[side * vAngle, 0, 0]}>
          {/* bank head */}
          <mesh position={[0, 0.28, 0]} castShadow>
            <boxGeometry args={[2.2, 0.16, 0.42]} />
            {headMat}
          </mesh>
          {/* cylinders */}
          {Array.from({ length: banks }).map((_, i) => {
            const x = -1.0 + (i * 2.0) / (banks - 1 || 1);
            return (
              <group key={i} position={[x, 0.42, 0]}>
                <mesh castShadow>
                  <cylinderGeometry args={[0.11, 0.11, 0.3, 18]} />
                  {headMat}
                </mesh>
                {/* cam cover */}
                <mesh position={[0, 0.2, 0]} castShadow>
                  <boxGeometry args={[0.22, 0.06, 0.4]} />
                  {coverMat}
                </mesh>
              </group>
            );
          })}
        </group>
      ))}
      {/* Intake plenum */}
      <mesh position={[0, 0.85, 0]} castShadow>
        <boxGeometry args={[1.1, 0.18, 0.34]} />
        {coverMat}
      </mesh>
      {/* Exhaust headers (left/right) */}
      {[-1, 1].map((side) => (
        <mesh key={side} position={[0, 0.2, side * 0.5]} rotation={[0, 0, side * 0.4]}>
          <torusGeometry args={[0.7, 0.05, 8, 24, Math.PI]} />
          <meshStandardMaterial color="#2A2D31" metalness={0.8} roughness={0.35} />
        </mesh>
      ))}
      {/* Transmission bell housing */}
      <mesh position={[-1.45, 0.05, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.45, 0.45, 0.4, 24]} />
        {blockMat}
      </mesh>
      {/* Mount */}
      <mesh position={[0, -0.4, 0]}>
        <boxGeometry args={[1.6, 0.06, 0.7]} />
        <meshStandardMaterial color="#0A0B0D" metalness={0.2} roughness={0.8} />
      </mesh>
    </group>
  );
}
