"use client";

import { Suspense, useRef, type ReactNode } from "react";
import { Canvas, useFrame, type ThreeElements } from "@react-three/fiber";
import { OrbitControls, ContactShadows, Environment, Html } from "@react-three/drei";
import * as THREE from "three";
import { RawCar } from "./RawCar";
import type { AtmospherePreset, Vehicle, VehicleColor } from "@/lib/vehicles/types";

/* ============================================================
   CarViewer3D
   ------------------------------------------------------------
   The reusable canvas that renders a single vehicle in a
   cinematic studio environment. Used by Home, Random, and the
   Car Experience. The Level-1 RawCar is rendered by default;
   when a Level-2 / Level-3 GLB is provided in `vehicle.assets`
   the renderer will swap to it (TODO hook — see comments).
   ============================================================ */

export interface CarViewer3DProps {
  vehicle: Vehicle;
  color: VehicleColor;
  /** Camera initial position */
  cameraPosition?: [number, number, number];
  /** Camera target */
  cameraTarget?: [number, number, number];
  autoRotate?: boolean;
  enableZoom?: boolean;
  enablePan?: boolean;
  /** Min/max polar angle to keep the camera above the floor */
  polarRange?: [number, number];
  /** Reveal-from-shadow opacity (0..1) for cinematic fades */
  revealOpacity?: number;
  hideLights?: boolean;
  silhouette?: boolean;
  /** Visual quality preset */
  quality?: "performance" | "balanced" | "cinematic";
  /** Atmosphere preset — overrides default studio lighting/floor/env */
  atmosphere?: AtmospherePreset;
  className?: string;
}

export function CarViewer3D({
  vehicle,
  color,
  cameraPosition = [4.2, 1.5, 5.0],
  cameraTarget = [0, 0.45, 0],
  autoRotate = true,
  enableZoom = true,
  enablePan = false,
  polarRange = [0.25, Math.PI / 2 - 0.05],
  revealOpacity = 1,
  hideLights = false,
  silhouette = false,
  quality = "balanced",
  atmosphere,
  className,
}: CarViewer3DProps) {
  const dpr: [number, number] =
    quality === "performance" ? [1, 1.2] : quality === "cinematic" ? [1, 2] : [1, 1.6];

  const exposure = atmosphere?.exposure ?? (quality === "cinematic" ? 1.05 : 0.95);

  return (
    <div className={className} style={{ width: "100%", height: "100%" }}>
      <Canvas
        shadows
        dpr={dpr}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: exposure,
        }}
        camera={{ position: cameraPosition, fov: 32, near: 0.1, far: 100 }}
      >
        <Suspense fallback={<Loader />}>
          <SceneLighting quality={quality} atmosphere={atmosphere} />
          <CarGroup
            vehicle={vehicle}
            color={color}
            autoRotate={autoRotate}
            revealOpacity={revealOpacity}
            hideLights={hideLights}
            silhouette={silhouette}
          />
          <SceneFloor atmosphere={atmosphere} />
          <ContactShadows
            position={[0, 0.001, 0]}
            opacity={0.55}
            scale={18}
            blur={2.4}
            far={4}
            resolution={quality === "performance" ? 256 : 512}
            color="#000000"
          />
          <Environment preset={atmosphere?.envPreset ?? (quality === "cinematic" ? "studio" : "city")} />
          {atmosphere?.fogColor && atmosphere.fogDensity ? (
            <Fog color={atmosphere.fogColor} density={atmosphere.fogDensity} />
          ) : null}
          <OrbitControls
            target={cameraTarget}
            enablePan={enablePan}
            enableZoom={enableZoom}
            minPolarAngle={polarRange[0]}
            maxPolarAngle={polarRange[1]}
            minDistance={3.2}
            maxDistance={9}
            enableDamping
            dampingFactor={0.08}
            rotateSpeed={0.7}
            zoomSpeed={0.7}
            makeDefault
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

/* --- Car group with optional auto-rotation --- */
function CarGroup({
  vehicle,
  color,
  autoRotate,
  revealOpacity,
  hideLights,
  silhouette,
}: {
  vehicle: Vehicle;
  color: VehicleColor;
  autoRotate: boolean;
  revealOpacity: number;
  hideLights: boolean;
  silhouette: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current && autoRotate) {
      ref.current.rotation.y += dt * 0.18;
    }
  });
  return (
    <group ref={ref} position={[0, 0, 0]} rotation={[0, -0.35, 0]}>
      <RawCar
        body={vehicle.raw}
        color={color}
        opacity={revealOpacity}
        hideLights={hideLights}
        silhouette={silhouette}
      />
    </group>
  );
}

/* --- Fog helper (declarative — attaches to scene.fog) --- */
function Fog({ color, density }: { color: string; density: number }) {
  return <fogExp2 attach="fog" args={[new THREE.Color(color), density]} />;
}

/* --- Scene lighting — supports atmosphere override --- */
function SceneLighting({
  quality,
  atmosphere,
}: {
  quality: "performance" | "balanced" | "cinematic";
  atmosphere?: AtmospherePreset;
}) {
  const keyIntensity = atmosphere?.keyIntensity ?? (quality === "cinematic" ? 2.2 : 1.8);
  const ambient = atmosphere?.ambient ?? 0.28;
  const keyColor = atmosphere?.keyColor ?? "#F3F3F1";
  const fillColor = atmosphere?.fillColor ?? "#C9CBD0";
  const rimColor = atmosphere?.rimColor ?? "#F3F3F1";
  return (
    <>
      <ambientLight intensity={ambient} />
      {/* Key — front-top */}
      <directionalLight
        position={[5, 8, 4]}
        intensity={keyIntensity}
        color={keyColor}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-near={0.5}
        shadow-camera-far={30}
        shadow-camera-left={-8}
        shadow-camera-right={8}
        shadow-camera-top={8}
        shadow-camera-bottom={-8}
        shadow-bias={-0.0005}
      />
      {/* Fill — opposite side, soft */}
      <directionalLight position={[-6, 4, -3]} intensity={0.55} color={fillColor} />
      {/* Rim — back-top for separation */}
      <directionalLight position={[0, 6, -8]} intensity={1.1} color={rimColor} />
      {/* Subtle underglow */}
      <pointLight position={[0, -1, 0]} intensity={0.3} color="#858990" distance={6} />
    </>
  );
}

/* --- Scene floor — supports atmosphere override --- */
function SceneFloor({ atmosphere }: { atmosphere?: AtmospherePreset }) {
  const color = atmosphere?.floorColor ?? "#08090B";
  const metalness = atmosphere?.floorMetalness ?? 0.4;
  const roughness = atmosphere?.floorRoughness ?? 0.55;
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[60, 60]} />
      <meshStandardMaterial
        color={color}
        metalness={metalness}
        roughness={roughness}
        envMapIntensity={0.4}
      />
    </mesh>
  );
}

function Loader() {
  return (
    <Html center>
      <div className="flex flex-col items-center gap-3 text-cario-soft-gray">
        <div className="h-1 w-12 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/2 animate-pulse bg-white/40" />
        </div>
        <span className="text-[10px] tracking-label uppercase">Loading vehicle</span>
      </div>
    </Html>
  );
}

/* ============================================================
   Static standalone RawCar (no canvas) — exported for the
   showroom where multiple cars share one canvas.
   ============================================================ */

export function RawCarInstance({
  vehicle,
  color,
  ...props
}: {
  vehicle: Vehicle;
  color: VehicleColor;
} & Omit<ThreeElements["group"], "ref">) {
  return <RawCar body={vehicle.raw} color={color} {...(props as object)} />;
}
