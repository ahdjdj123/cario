"use client";

import { motion } from "framer-motion";
import { Garage } from "@/components/cario/three/Garage";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { BrandMark } from "@/components/cario/ui-parts/BrandMark";
import { PrimaryActions } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import { getHeroVehicle, getVehicle, type Vehicle } from "@/lib/vehicles";

/* ============================================================
   CarioHome — the garage
   ------------------------------------------------------------
   The most important screen. A dark cinematic garage environment
   with the hero car on a rotating podium in the center, plus
   several other cars from the collection parked in the
   background. The vehicle occupies ~75-85% of visual attention.
   Above/below: CARIO + model name + minimal metadata. At the
   bottom: four compact primary actions (EXPLORE / CONTINUE /
   RANDOM / IDENTIFY). Settings is a small secondary icon in the
   top-right, rendered by the shell.
   ============================================================ */

export function CarioHome() {
  const setView = useCario((s) => s.setView);
  const continueLast = useCario((s) => s.continueLast);
  const rollRandom = useCario((s) => s.rollRandom);
  const selectVehicle = useCario((s) => s.selectVehicle);
  const lastVehicleId = useCario((s) => s.lastVehicleId);
  const recentIds = useCario((s) => s.recentIds);
  const favoriteCount = useCario((s) => s.favoriteIds.length);
  const autoRotate = useCario((s) => s.settings.autoRotate);
  const grain = useCario((s) => s.settings.grain);
  const hero = getHeroVehicle();
  const color = hero.colors[0];

  // Recently viewed cars (exclude the hero, max 5)
  const recentCars = recentIds
    .filter((id) => id !== hero.id)
    .slice(0, 5)
    .map((id) => getVehicle(id))
    .filter((v): v is Vehicle => !!v);

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="studio" grain={grain} />

      {/* The garage — hero on rotating podium */}
      <div className="absolute inset-0">
        <Garage
          hero={hero}
          heroColor={color}
          autoRotate={autoRotate}
          quality="balanced"
        />
      </div>

      {/* Edge fade — blends the 3D canvas bottom with the UI controls */}
      <div className="cario-edge-fade-bottom" />

      {/* Top bar — brand mark + car identity */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between px-6 py-6 sm:px-10 sm:py-8">
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col gap-1"
        >
          <BrandMark size="md" />
          <span className="mt-1 font-mono text-[9px] uppercase tracking-mega text-cario-soft-gray/60">
            Interactive Automotive Exploration
          </span>
        </motion.div>

        {/* Car identity (right) + Recently viewed */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="hidden flex-col items-end gap-1.5 sm:flex"
        >
          <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
            {hero.brand} · {hero.generation} · {hero.year}
          </span>
          <span className="font-display text-base font-medium tracking-tight-2 text-cario-white">
            {hero.model}
          </span>
          <span className="text-[11px] italic text-cario-soft-gray">{hero.tagline}</span>

          {/* Recently viewed quick-access row */}
          {recentCars.length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="mt-4 flex flex-col items-end gap-2"
            >
              <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                Recently viewed
              </span>
              <div className="flex items-center gap-1.5">
                {recentCars.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => selectVehicle(v.id)}
                    className="group flex items-center gap-1.5 rounded-full border border-white/8 bg-black/30 px-2.5 py-1 backdrop-blur-md transition-all hover:border-white/20 hover:bg-white/[0.06]"
                    title={`${v.brand} ${v.model}`}
                  >
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ background: v.colors[0].hex, opacity: 0.8 }}
                    />
                    <span className="text-[9px] uppercase tracking-label text-cario-soft-gray transition-colors group-hover:text-cario-light-gray">
                      {v.model.length > 12 ? v.model.slice(0, 10) + "…" : v.model}
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Center-left minimal metadata block — with legibility scrim */}
      <div className="pointer-events-none absolute bottom-28 left-0 z-10 sm:bottom-32">
        {/* Soft gradient scrim so metadata reads over the car */}
        <div
          className="pointer-events-none absolute -inset-y-4 -left-0 right-[40%] sm:right-[55%]"
          style={{
            background:
              "linear-gradient(to right, rgba(5,6,8,0.78) 0%, rgba(5,6,8,0.45) 55%, transparent 100%)",
          }}
        />
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="relative flex flex-col gap-3 pl-6 sm:pl-10"
        >
          <div className="flex items-baseline gap-3">
            <span className="font-display text-5xl font-extralight tracking-tight-3 text-cario-white sm:text-6xl">
              {hero.spec.horsepower}
            </span>
            <span className="font-mono text-[11px] uppercase tracking-label text-cario-soft-gray">
              HP
            </span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex flex-col gap-0.5">
              <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
                0–100
              </span>
              <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
                {hero.spec.acceleration}s
              </span>
            </div>
            <span className="h-6 w-px bg-white/10" />
            <div className="flex flex-col gap-0.5">
              <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
                Top
              </span>
              <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
                {hero.spec.topSpeed} km/h
              </span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom controls — four compact primary actions */}
      <div className="absolute inset-x-0 bottom-0 z-10 flex flex-col items-center gap-4 px-6 pb-7 sm:pb-9">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <PrimaryActions
            actions={[
              {
                id: "explore",
                index: "01",
                label: "Explore",
                hint: "Discover the collection",
                onSelect: () => setView("explore"),
              },
              {
                id: "continue",
                index: "02",
                label: "Continue",
                hint: lastVehicleId ? "Return to last car" : "No last session",
                onSelect: () => continueLast(),
                disabled: !lastVehicleId,
              },
              {
                id: "random",
                index: "03",
                label: "Random",
                hint: "Let CARIO choose",
                onSelect: () => {
                  rollRandom();
                  setView("random");
                },
              },
              {
                id: "identify",
                index: "04",
                label: "Identify",
                hint: "Recognition mini game",
                onSelect: () => setView("identify"),
              },
            ]}
          />
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex items-center gap-3 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/40"
        >
          <span>Drag to rotate · Scroll to zoom</span>
          <span className="h-3 w-px bg-cario-soft-gray/20" />
          <button
            type="button"
            onClick={() => setView("compare")}
            className="transition-colors hover:text-cario-light-gray"
          >
            Compare →
          </button>
          <span className="h-3 w-px bg-cario-soft-gray/20" />
          <button
            type="button"
            onClick={() => setView("favorites")}
            className="transition-colors hover:text-cario-light-gray"
          >
            My garage{favoriteCount > 0 ? ` (${favoriteCount})` : ""} →
          </button>
          <span className="h-3 w-px bg-cario-soft-gray/20" />
          <button
            type="button"
            onClick={() => setView("stats")}
            className="transition-colors hover:text-cario-light-gray"
          >
            Collection stats →
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}
