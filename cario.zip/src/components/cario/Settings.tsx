"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Settings as SettingsIcon, X } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useCario, type CarioSettings } from "@/lib/cario/store";
import { cn } from "@/lib/utils";

/* ============================================================
   Settings — small secondary slide-over panel
   ------------------------------------------------------------
   Triggered by a gear icon. Per the brief it is intentionally a
   small secondary control, never one of the four primary actions.
   ============================================================ */

export function SettingsTrigger({ className }: { className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <motion.button
        type="button"
        onClick={() => setOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.96 }}
        className={cn(
          "group flex h-9 w-9 items-center justify-center rounded-full",
          "border border-white/10 bg-black/30 text-cario-soft-gray backdrop-blur-md",
          "transition-colors hover:border-white/20 hover:text-cario-white",
          className
        )}
        aria-label="Settings"
      >
        <SettingsIcon className="h-4 w-4 transition-transform duration-700 group-hover:rotate-45" />
      </motion.button>
      <SettingsPanel open={open} onClose={() => setOpen(false)} />
    </>
  );
}

function SettingsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const settings = useCario((s) => s.settings);
  const update = useCario((s) => s.updateSettings);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Scrim */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px]"
          />
          {/* Panel */}
          <motion.aside
            initial={{ x: 360, opacity: 0.6 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 360, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            className="fixed right-0 top-0 z-50 flex h-full w-[340px] max-w-[88vw] flex-col cario-surface-strong"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/8 px-6 py-5">
              <div className="flex flex-col">
                <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                  CARIO / 06
                </span>
                <h2 className="mt-1 font-display text-sm font-medium tracking-wider-2 uppercase text-cario-white">
                  Settings
                </h2>
              </div>
              <button
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                aria-label="Close settings"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Body */}
            <div className="cario-scroll flex-1 overflow-y-auto px-6 py-6">
              <Section title="Visual Quality">
                <Segmented
                  value={settings.renderQuality}
                  options={[
                    { value: "performance", label: "Perf" },
                    { value: "balanced", label: "Balanced" },
                    { value: "cinematic", label: "Cinematic" },
                  ]}
                  onChange={(v) => update({ renderQuality: v as CarioSettings["renderQuality"] })}
                />
                <Hint>
                  Higher quality enables richer reflections at the cost of frame rate.
                </Hint>
              </Section>

              <Section title="Motion">
                <Toggle
                  label="Play intro on launch"
                  checked={settings.playIntro}
                  onChange={(v) => update({ playIntro: v })}
                />
                <Toggle
                  label="Auto-rotate hero car"
                  checked={settings.autoRotate}
                  onChange={(v) => update({ autoRotate: v })}
                />
                <Toggle
                  label="Reduce motion"
                  checked={settings.reduceMotion}
                  onChange={(v) => update({ reduceMotion: v })}
                />
              </Section>

              <Section title="Interface">
                <Toggle
                  label="Film grain overlay"
                  checked={settings.grain}
                  onChange={(v) => update({ grain: v })}
                />
                <Toggle
                  label="Verbose specifications"
                  checked={settings.verboseSpecs}
                  onChange={(v) => update({ verboseSpecs: v })}
                />
              </Section>

              <Section title="Asset Tier">
                <div className="flex items-center justify-between rounded-md border border-white/8 bg-white/[0.02] px-4 py-3">
                  <div className="flex flex-col">
                    <span className="text-[12px] text-cario-light-gray">Current render tier</span>
                    <span className="mt-0.5 text-[10px] uppercase tracking-label text-cario-soft-gray">
                      Level 1 · Raw procedural
                    </span>
                  </div>
                  <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                    RAW
                  </span>
                </div>
                <Hint>
                  Level-2 (high) and Level-3 (4K) assets will drop in without rebuilding the app.
                </Hint>
              </Section>

              <div className="mt-8 flex items-center justify-between border-t border-white/8 pt-5">
                <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                  CARIO Prototype · v0.1
                </span>
                <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                  Single-route build
                </span>
              </div>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-7">
      <h3 className="mb-3 font-mono text-[10px] uppercase tracking-label text-cario-soft-gray/80">
        {title}
      </h3>
      <div className="flex flex-col gap-3">{children}</div>
    </section>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-[13px] text-cario-light-gray">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

function Segmented<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-md border border-white/8 bg-white/[0.02] p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-[5px] px-2 py-1.5 text-[11px] uppercase tracking-label transition-colors",
            value === o.value
              ? "bg-white/10 text-cario-white"
              : "text-cario-soft-gray hover:text-cario-light-gray"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Hint({ children }: { children: React.ReactNode }) {
  return (
    <p className="mt-2 text-[11px] leading-relaxed text-cario-soft-gray/70">{children}</p>
  );
}
