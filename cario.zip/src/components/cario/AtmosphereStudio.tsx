"use client";

import { motion } from "framer-motion";
import { ATMOSPHERE_PRESETS } from "@/lib/vehicles/atmosphere";
import type { AtmospherePresetId } from "@/lib/vehicles/types";
import { useCario } from "@/lib/cario/store";
import { cn } from "@/lib/utils";

/* ============================================================
   AtmosphereStudio — environment switcher
   ------------------------------------------------------------
   Replaces the "coming soon" toast for the ATMOSPHERE control.
   A compact horizontal row of 5 environment presets (Studio /
   Dawn / Dusk / Night / Rain). Selecting one updates the 3D
   scene's lighting, environment map, floor material, and fog
   in real time via the store's atmosphereId.

   The vehicle remains the hero — the selector is minimal and
   floats at the bottom-center, mirroring the Color Studio's
   compact layout.
   ============================================================ */

export function AtmosphereStudio() {
  const atmosphereId = useCario((s) => s.atmosphereId);
  const setAtmosphere = useCario((s) => s.setAtmosphere);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-3"
    >
      {/* Preset chips */}
      <div className="flex items-center gap-2">
        {ATMOSPHERE_PRESETS.map((p) => (
          <PresetChip
            key={p.id}
            preset={p}
            active={p.id === atmosphereId}
            onClick={() => setAtmosphere(p.id as AtmospherePresetId)}
          />
        ))}
      </div>

      {/* Active preset name + hint */}
      <div className="flex flex-col items-center gap-0.5">
        <span className="font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
          {ATMOSPHERE_PRESETS.find((p) => p.id === atmosphereId)?.name ?? "Studio"}
        </span>
        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
          {ATMOSPHERE_PRESETS.find((p) => p.id === atmosphereId)?.hint ?? "Neutral showroom"}
        </span>
      </div>
    </motion.div>
  );
}

function PresetChip({
  preset,
  active,
  onClick,
}: {
  preset: { id: string; name: string; keyColor: string; ambient: number };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={preset.name}
      className={cn(
        "group relative flex h-9 items-center gap-2 rounded-full border px-4 transition-all duration-300",
        active
          ? "border-white/30 bg-white/10 text-cario-white"
          : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
      )}
    >
      {/* Swatch — a tiny gradient orb representing the lighting mood */}
      <span
        className="block h-4 w-4 rounded-full border border-white/10"
        style={{
          background: `radial-gradient(circle at 30% 25%, ${preset.keyColor} 0%, ${darken(preset.keyColor, 0.4)} 70%, #050608 100%)`,
          opacity: active ? 1 : 0.7,
        }}
      />
      <span className="text-[10px] uppercase tracking-label">{preset.name}</span>
      {/* Active indicator dot */}
      {active && (
        <motion.span
          layoutId="atmosphere-active"
          className="absolute -bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-cario-white"
        />
      )}
    </button>
  );
}

function darken(hex: string, amt: number) {
  const h = hex.replace("#", "");
  const r = Math.round(parseInt(h.substring(0, 2), 16) * (1 - amt));
  const g = Math.round(parseInt(h.substring(2, 4), 16) * (1 - amt));
  const b = Math.round(parseInt(h.substring(4, 6), 16) * (1 - amt));
  return `rgb(${r}, ${g}, ${b})`;
}
