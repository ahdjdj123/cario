"use client";

import { motion } from "framer-motion";
import { BarChart3 } from "lucide-react";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn, ViewHeader } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import { VEHICLES } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioStats — collection statistics dashboard
   ------------------------------------------------------------
   A premium monochrome dashboard showing aggregate statistics
   about the CARIO car collection: total cars, average power,
   brand breakdown, era distribution, power distribution chart,
   and top performers per category.
   ============================================================ */

export function CarioStats() {
  const goBack = useCario((s) => s.goBack);
  const grain = useCario((s) => s.settings.grain);

  // Aggregate stats
  const totalCars = VEHICLES.length;
  const avgPower = Math.round(VEHICLES.reduce((s, v) => s + v.spec.horsepower, 0) / totalCars);
  const avgAccel = (VEHICLES.reduce((s, v) => s + v.spec.acceleration, 0) / totalCars).toFixed(1);
  const avgTopSpeed = Math.round(VEHICLES.reduce((s, v) => s + v.spec.topSpeed, 0) / totalCars);
  const totalPower = VEHICLES.reduce((s, v) => s + v.spec.horsepower, 0);

  // Brand breakdown
  const brandCounts = VEHICLES.reduce((acc, v) => {
    acc[v.brand] = (acc[v.brand] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Era distribution
  const eraCounts = VEHICLES.reduce((acc, v) => {
    acc[v.era] = (acc[v.era] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Top performers
  const mostPowerful = [...VEHICLES].sort((a, b) => b.spec.horsepower - a.spec.horsepower)[0];
  const fastest = [...VEHICLES].sort((a, b) => b.spec.topSpeed - a.spec.topSpeed)[0];
  const quickest = [...VEHICLES].sort((a, b) => a.spec.acceleration - b.spec.acceleration)[0];
  const lightest = [...VEHICLES]
    .filter((v) => v.spec.weight)
    .sort((a, b) => (a.spec.weight ?? 0) - (b.spec.weight ?? 0))[0];

  // Power distribution (for bar chart)
  const maxPower = Math.max(...VEHICLES.map((v) => v.spec.horsepower));
  const sortedByPower = [...VEHICLES].sort((a, b) => b.spec.horsepower - a.spec.horsepower);

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" grain={grain} />

      <div className="cario-scroll absolute inset-0 overflow-y-auto">
        <div className="mx-auto min-h-full max-w-5xl px-6 py-8 sm:px-10 sm:py-10">
          {/* Header */}
          <div className="flex flex-col gap-5">
            <div className="pointer-events-auto">
              <CornerReturn label="Back" onClick={() => goBack()} />
            </div>
            <ViewHeader
              eyebrow="CARIO / 07"
              title="Collection"
              subtitle="Aggregate statistics across the CARIO fleet."
            />
          </div>

          {/* Summary cards */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4"
          >
            <SummaryCard label="Total Cars" value={`${totalCars}`} />
            <SummaryCard label="Total Power" value={`${totalPower.toLocaleString()}`} unit="HP" />
            <SummaryCard label="Avg Power" value={`${avgPower}`} unit="HP" />
            <SummaryCard label="Avg 0–100" value={`${avgAccel}`} unit="s" />
          </motion.div>

          {/* Power distribution bar chart */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="mt-6 rounded-lg border border-white/8 bg-white/[0.02] p-5"
          >
            <div className="mb-4 flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                Power Distribution
              </span>
              <BarChart3 className="h-3.5 w-3.5 text-cario-soft-gray/50" />
            </div>
            <div className="flex flex-col gap-2">
              {sortedByPower.map((v, i) => (
                <motion.div
                  key={v.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 + i * 0.03 }}
                  className="flex items-center gap-3"
                >
                  <span className="w-32 truncate text-[11px] text-cario-light-gray sm:w-40">
                    {v.brand} {v.model}
                  </span>
                  <div className="relative h-5 flex-1 overflow-hidden rounded-sm bg-white/[0.03]">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(v.spec.horsepower / maxPower) * 100}%` }}
                      transition={{ duration: 0.6, delay: 0.4 + i * 0.03, ease: [0.22, 1, 0.36, 1] }}
                      className={cn(
                        "absolute inset-y-0 left-0 rounded-sm",
                        i === 0 ? "bg-white/25" : "bg-white/10"
                      )}
                    />
                    <span className="absolute right-2 top-1/2 -translate-y-1/2 font-mono text-[9px] tabular-nums text-cario-light-gray">
                      {v.spec.horsepower} HP
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Brand + Era breakdown */}
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="rounded-lg border border-white/8 bg-white/[0.02] p-5"
            >
              <span className="mb-3 block font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                Brand Breakdown
              </span>
              <div className="flex flex-col gap-2">
                {Object.entries(brandCounts).map(([brand, count]) => (
                  <div key={brand} className="flex items-center gap-3">
                    <span className="w-24 text-[11px] text-cario-light-gray">{brand}</span>
                    <div className="relative h-4 flex-1 overflow-hidden rounded-sm bg-white/[0.03]">
                      <div
                        className="absolute inset-y-0 left-0 rounded-sm bg-white/10"
                        style={{ width: `${(count / totalCars) * 100}%` }}
                      />
                    </div>
                    <span className="font-mono text-[10px] tabular-nums text-cario-soft-gray">
                      {count}/{totalCars}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="rounded-lg border border-white/8 bg-white/[0.02] p-5"
            >
              <span className="mb-3 block font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                Era Distribution
              </span>
              <div className="flex flex-col gap-2">
                {Object.entries(eraCounts).map(([era, count]) => (
                  <div key={era} className="flex items-center gap-3">
                    <span className="w-24 text-[11px] capitalize text-cario-light-gray">{era}</span>
                    <div className="relative h-4 flex-1 overflow-hidden rounded-sm bg-white/[0.03]">
                      <div
                        className="absolute inset-y-0 left-0 rounded-sm bg-white/10"
                        style={{ width: `${(count / totalCars) * 100}%` }}
                      />
                    </div>
                    <span className="font-mono text-[10px] tabular-nums text-cario-soft-gray">
                      {count}/{totalCars}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Top performers */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="mt-6 rounded-lg border border-white/8 bg-white/[0.02] p-5"
          >
            <span className="mb-3 block font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
              Top Performers
            </span>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <TopPerformer label="Most Powerful" vehicle={mostPowerful} metric={`${mostPowerful.spec.horsepower} HP`} />
              <TopPerformer label="Fastest" vehicle={fastest} metric={`${fastest.spec.topSpeed} km/h`} />
              <TopPerformer label="Quickest" vehicle={quickest} metric={`${quickest.spec.acceleration}s 0-100`} />
              <TopPerformer label="Lightest" vehicle={lightest} metric={`${lightest.spec.weight} kg`} />
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

function SummaryCard({ label, value, unit }: { label: string; value: string; unit?: string }) {
  return (
    <div className="rounded-lg border border-white/8 bg-white/[0.02] p-4">
      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        {label}
      </span>
      <div className="mt-1.5 flex items-baseline gap-1">
        <span className="font-display text-2xl font-light tabular-nums text-cario-white">
          {value}
        </span>
        {unit && (
          <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
            {unit}
          </span>
        )}
      </div>
    </div>
  );
}

function TopPerformer({
  label,
  vehicle,
  metric,
}: {
  label: string;
  vehicle: { brand: string; model: string };
  metric: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
        {label}
      </span>
      <span className="font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
        {vehicle.model}
      </span>
      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        {vehicle.brand}
      </span>
      <span className="font-display text-sm font-light tabular-nums text-cario-light-gray">
        {metric}
      </span>
    </div>
  );
}
