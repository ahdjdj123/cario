"use client";

import { AnimatePresence } from "framer-motion";
import { useCario } from "@/lib/cario/store";
import { useKeyboardShortcuts } from "@/lib/cario/useKeyboardShortcuts";
import { CarioIntro } from "./CarioIntro";
import { CarioHome } from "./CarioHome";
import { CarioExplore } from "./CarioExplore";
import { CarioRandom } from "./CarioRandom";
import { CarioIdentify } from "./CarioIdentify";
import { CarioCarExperience } from "./CarioCarExperience";
import { CarioCompare } from "./CarioCompare";
import { CarioFavorites } from "./CarioFavorites";
import { CarioStats } from "./CarioStats";
import { ShortcutsHelp } from "./ShortcutsHelp";
import { SettingsTrigger } from "./Settings";

/* ============================================================
   CarioShell — the single application shell
   ------------------------------------------------------------
   The whole experience lives on one route. The shell switches
   between views using the Zustand store, with smooth crossfade
   transitions via AnimatePresence. A small Settings icon sits in
   the top-right corner on every screen except the intro.

   The shell uses a definite `h-screen` so every view's
   `h-full`/`inset-0` resolves to the full viewport — this is
   required for the 3D canvas (R3F ResizeObserver) and the
   bottom-anchored controls to position correctly.

   Global keyboard shortcuts (Esc/back, 1-4 for home actions)
   are registered here.
   ============================================================ */

export function CarioShell() {
  const view = useCario((s) => s.view);
  const selectedId = useCario((s) => s.selectedVehicleId);
  useKeyboardShortcuts();

  // Breadcrumb label for the current view
  const viewLabels: Record<string, string> = {
    home: "Garage",
    explore: "Explore",
    random: "Random",
    identify: "Identify",
    experience: "Experience",
    compare: "Compare",
    favorites: "My Garage",
    stats: "Collection",
  };
  const breadcrumb = view !== "intro" ? viewLabels[view] ?? view : "";

  return (
    <main className="relative h-screen w-full overflow-hidden bg-[#08090B]">
      <AnimatePresence mode="wait">
        {view === "intro" && <CarioIntro key="intro" />}
        {view === "home" && <CarioHome key="home" />}
        {view === "explore" && <CarioExplore key="explore" />}
        {view === "random" && <CarioRandom key="random" />}
        {view === "identify" && <CarioIdentify key="identify" />}
        {view === "experience" && <CarioCarExperience key="experience" />}
        {view === "compare" && <CarioCompare key="compare" />}
        {view === "favorites" && <CarioFavorites key="favorites" />}
        {view === "stats" && <CarioStats key="stats" />}
      </AnimatePresence>

      {/* Breadcrumb — top-center, very subtle */}
      {view !== "intro" && view !== "home" && (
        <div className="pointer-events-none absolute left-1/2 top-4 z-40 -translate-x-1/2 sm:top-6">
          <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/40">
            <span>CARIO</span>
            <span className="h-3 w-px bg-cario-soft-gray/20" />
            <span className="text-cario-soft-gray/70">{breadcrumb}</span>
            {view === "experience" && selectedId && (
              <>
                <span className="h-3 w-px bg-cario-soft-gray/20" />
                <span className="text-cario-light-gray/60">{selectedId.split("-").slice(0, 2).join(" ")}</span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Settings — small secondary icon, top-right */}
      {view !== "intro" && (
        <div className="pointer-events-auto absolute right-4 top-4 z-50 sm:right-6 sm:top-6">
          <SettingsTrigger />
        </div>
      )}

      {/* Keyboard hint — bottom-right, very subtle */}
      {view !== "intro" && (
        <div className="pointer-events-none absolute bottom-3 right-4 z-30 hidden sm:block">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/30">
            Esc · back
            {view === "home" && " · 1-5 navigate"}
            {" · ? help"}
          </span>
        </div>
      )}

      {/* Keyboard shortcuts help overlay (triggered by ?) */}
      {view !== "intro" && <ShortcutsHelp />}
    </main>
  );
}

