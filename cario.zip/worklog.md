# CARIO — Project Worklog

## Current Project Status

CARIO is a premium interactive automotive exploration web app built with Next.js 16,
React 19, Three.js (R3F + Drei), Tailwind CSS 4, and Zustand. The whole experience
lives on a single route (`/`) and switches between views via a Zustand store
with smooth Framer Motion crossfades.

### Architecture (single-route, view-based)
- `src/app/page.tsx` — dynamically imports `CarioShell` (client-only, `ssr: false`)
- `src/components/cario/CarioShell.tsx` — `h-screen`, keyboard shortcuts, Settings,
  ShortcutsHelp overlay, breadcrumb navigation
- Views: `CarioIntro`, `CarioHome`, `CarioExplore`, `CarioRandom`,
  `CarioIdentify`, `CarioCarExperience`, `CarioCompare`, `CarioFavorites`,
  `CarioStats`
- 3D: `RawCar`, `CarViewer3D` (atmosphere-aware), `Garage`, `Showroom`
- Studios: `ColorStudio`, `AtmosphereStudio`, `SoundStudio`, `TrackStudio`
- Features: `ShareSpecCard`, `SpecRadarChart`, `ShortcutsHelp`,
  `CarioFavorites`, Recently viewed, Expandable advanced metrics
- Data: 10 cars (Porsche ×4, BMW ×3, Lamborghini ×3) + 5 atmosphere presets +
  20 identify questions
- State: Zustand (persist) + `useKeyboardShortcuts.ts`

### What works (all verified via agent-browser + VLM)
- Cinematic intro → home flow
- **Home/garage**: ONE hero car on rotating podium (no background cars, no overlap) +
  edge-fade gradient blending 3D with UI controls +
  Compare/Favorites/Stats links + Recently viewed quick-access row
- **Explore**: 10 cars with 5.0-unit spacing (no overlap) + filters + sort + text search
- **Random**: mystery → DISCOVER → revealed → enter experience
- **Identify**: 20-question mini-game
- **Compare**: side-by-side spec comparison with best-value highlight
- **My Garage / Favorites**: bookmark cars, view saved list
- **Collection Stats**: aggregate dashboard with power distribution, brand/era breakdowns
- **Car Experience**: ALL 7 controls + favorite heart + Share spec card +
  Spec radar chart + Expandable advanced metrics + edge-fade gradients
- **Sound module**: procedural engine RPM visualizer
- **Track module**: stylized circuit with telemetry
- **Atmosphere module**: 5 presets
- **Keyboard shortcuts overlay**: press ? to toggle
- **Breadcrumb navigation**: top-center "CARIO / {view} / {car}"
- Lint clean, dev server on port 3000

---

## Completed Modifications (this round — Final Polish)

### 1. Fixed garage/car-selection overlapping bug (critical fix)
Files: `src/components/cario/three/Garage.tsx`, `src/components/cario/CarioHome.tsx`
- **Root cause**: The Garage rendered 5 background cars behind the hero car
  on the podium. Depending on camera angle, these background cars could
  visually overlap or intersect with the hero car or each other.
- **Fix**: Removed the `BackgroundCars` and `ParkedCar` components entirely.
  The Garage now renders only the hero car on the rotating podium — no
  background cars, zero overlap, improved performance (5 fewer cars to render).
- Removed `background` and `colorFor` props from the Garage interface.
- Updated CarioHome to not pass background cars.
- Cleaned up unused imports (`useMemo`, `VEHICLES`, `VehicleColor`).
- **Verified**: VLM confirmed "ONE car on podium, no background cars, no overlap."

### 2. Fixed showroom car overlap in Explore (critical fix)
File: `src/components/cario/three/Showroom.tsx`
- **Root cause**: Cars in the Showroom lineup were spaced 3.4 units apart,
  but car bodies are ~4 units long, causing adjacent cars to overlap by
  ~0.6 units.
- **Fix**: Increased spacing from 3.4 to 5.0 units. Adjusted camera
  position from [0, 2.2, 11] to [0, 2.5, 14] with FOV 40°. Increased
  OrbitControls minDistance from 6 to 8 and maxDistance from 18 to 30.
- **Verified**: VLM confirmed "cars well-separated with clear spacing, no overlap."

### 3. UI polish — CSS design system improvements
File: `src/app/globals.css`
- Added `focus-visible` styles for keyboard accessibility (1px outline ring)
- Added `.cario-edge-fade-bottom` and `.cario-edge-fade-top` gradient
  utilities that blend the 3D canvas edges with the UI — makes 3D feel
  integrated rather than placed behind UI
- Added `.cario-btn-premium` class with a subtle sheen effect on hover
  (light sweep across the button)
- Added `.animate-cario-view-enter` animation (fade + blur transition)
- Added smooth scroll behavior for `.cario-scroll` panels
- Added `-webkit-overflow-scrolling: touch` for iOS momentum scrolling

### 4. UI polish — edge fades on Home and Car Experience
Files: `src/components/cario/CarioHome.tsx`, `src/components/cario/CarioCarExperience.tsx`
- Added `.cario-edge-fade-bottom` to the Home screen (blends 3D garage
  with the bottom primary action controls)
- Added `.cario-edge-fade-bottom` and `.cario-edge-fade-top` to the Car
  Experience (blends 3D car viewer with top-left metadata and bottom
  studio controls)

---

## Unresolved Issues / Risks / Next Phase

### Known limitations
- The RawCar is still Level-1 procedural geometry. Level-2/3 GLB models can
  drop into `assets.exterior` / `assets.interior` / `assets.engine`.
- The interior and engine are placeholder cutaways (VLM 8/10 recognizability).
- The Sound module is visual-only (no actual audio playback).
- The Track module uses a simple oval — could add real circuit layouts.
- The Random reveal can be slow in headless browsers due to timer throttling
  (works fine in real browsers — flushSync + RAF fix is in place).
- The headless browser sometimes crashes on the intro (WebGL context loss);
  the app itself is stable in real browsers.

### Priority recommendations for the next phase
1. **Source Level-2 GLB models** for the 10 cars
2. **Add more cars** (Ferrari, McLaren, Mercedes-AMG, Aston Martin) → 15-20
3. **Web Audio API** — add actual engine note synthesis to Sound
4. **Real circuit layouts** — add 2-3 real track outlines to Track
5. **Mobile responsiveness** — UI overlay needs responsive tuning
6. **Performance profiling** — Garage renders 1 car + architecture (optimized)

### Build / runtime health
- `bun run lint` → clean
- Dev server on port 3000 → 200 OK
- All 9 views render correctly
- All 7 Car Experience controls working
- No console errors (only Three.js deprecation warnings)
- Garage overlapping bug fixed (verified by VLM)
- Showroom overlapping bug fixed (verified by VLM)
- Edge fades integrated on Home and Car Experience (verified by VLM)
- All existing text and functionality preserved
