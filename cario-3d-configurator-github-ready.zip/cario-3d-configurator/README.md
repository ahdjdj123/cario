# CARIO — 3D Automotive Configurator

CARIO is a premium, cinematic automotive exploration experience built as a single-route
Next.js application. Every car is presented as its own interactive world: a black-and-gold
showroom where you configure, race, photograph and compare a fleet of 15 performance cars
in real-time 3D.

## Features

- **Cinematic intro → showroom flow** — animated brand intro leading to a hero car on a
  rotating podium, with edge-fade gradients blending the 3D scene into the UI.
- **Explore** — browse the full fleet (15 vehicles: Porsche, BMW, Lamborghini, Ferrari,
  McLaren, Mercedes-AMG, Aston Martin) with filters, sorting and text search.
- **Car Experience** — per-car studio with exterior/interior/engine views and seven
  interactive controls: paint, wheels, atmosphere, sound, track, drag race and photo.
- **Color Studio** — 19 factory-grade paint colors with live 3D preview.
- **Wheel Studio** — rim selection with hero-shot preview modal.
- **Atmosphere Studio** — 5 lighting presets (studio, dawn, dusk, night, rain) backed by
  6 self-hosted HDR environment maps (no external CDN dependency).
- **Sound Studio** — procedural engine RPM visualizer.
- **Track Studio** — 4 stylized circuits with live telemetry.
- **Drag Race** — reaction-based racing with tire-wear modelling and an **Endurance mode**
  (best-of-5 series with per-round tire degradation and race pips).
- **Photo Studio** — capture the current 3D scene.
- **Compare** — side-by-side spec comparison with best-value highlighting.
- **Random** — mystery-car discovery flow.
- **Identify** — 20-question car-guessing mini-game.
- **Favorites & Collection Stats** — bookmark cars; aggregate dashboard with power
  distribution and brand/era breakdowns.
- **Achievements** — 20 unlockable achievements with a toast watcher.
- **Share Spec Card** — generates a downloadable SVG spec card for any build.
- **Keyboard shortcuts & Settings** — full keyboard navigation plus a settings panel
  (sound volume, motion preferences).
- All user state (favorites, achievements, race records, settings) persists in the
  browser via Zustand `persist` (localStorage).

## Tech Stack

| Layer      | Technology                                                        |
| ---------- | ----------------------------------------------------------------- |
| Framework  | Next.js 16 (App Router, standalone output), React 19, TypeScript 5 |
| 3D         | three.js, @react-three/fiber, @react-three/drei                    |
| Styling    | Tailwind CSS 4, shadcn/ui (New York), Radix UI, Lucide icons       |
| Animation  | Framer Motion                                                      |
| State      | Zustand (with `persist` middleware)                                |
| Data layer | Prisma ORM + SQLite (configured; current app state is client-side) |

## Requirements

- **Node.js 20.9+** or **Bun 1.2+**
- A browser with **WebGL support** (the entire experience is real-time 3D)

## Installation

```bash
# clone / extract the project, then:
bun install        # or: npm install
```

The `postinstall` hook runs `prisma generate` automatically.

Copy the environment example and create the (optional) database:

```bash
cp .env.example .env
bun run db:push   # or: npx prisma db push — creates db/custom.db
```

## Environment Variables

| Variable       | Required                | Description                                            |
| -------------- | ----------------------- | ------------------------------------------------------ |
| `DATABASE_URL` | No (for the current app) | Prisma SQLite URL. See `.env.example`. Note that relative `file:` paths resolve against the `prisma/` schema directory, hence `file:../db/custom.db`. |

The application itself persists all state client-side; no server-side database or
third-party API keys are needed to run any feature.

## Local Development

```bash
bun run dev       # starts Next.js on http://localhost:3000
```

Other useful scripts:

```bash
bun run lint        # ESLint
bun run typecheck   # tsc --noEmit
bun run db:push     # sync Prisma schema to the SQLite database
```

## Production Build

The project builds to a **standalone** output:

```bash
bun run build     # next build + copies static/public into .next/standalone
bun run start     # NODE_ENV=production node .next/standalone/server.js
```

`PORT` and `HOSTNAME` are read by the standalone server (`PORT=3000` by default).
The `build`/`start` scripts use POSIX shell syntax — build on Linux/macOS (or WSL).

## Deployment

- **Self-hosted / Docker**: run `bun run build`, then serve `.next/standalone/server.js`
  (the build script already copies `public/` and `.next/static` into the standalone
  folder). Any Node 20+ container works.
- **Vercel-style platforms**: the repo is a standard Next.js App Router project and
  deploys as-is. All app state is client-side, so no database add-on is required.
- The favicon and all HDRI environment maps are served from `public/` — no external
  asset CDNs are used at runtime.

## Project Structure

```
src/
├── app/                    # App Router: layout, single page route, /api health route
├── components/
│   ├── cario/              # CARIO views, studios and feature components
│   │   └── three/          # R3F scenes (CarViewer3D, Garage, Showroom, environment)
│   ├── ui/                 # shadcn/ui primitives
├── hooks/                  # shared React hooks
└── lib/
    ├── cario/              # Zustand store, achievements, circuits, shortcuts, driver data
    ├── vehicles/           # vehicle/paint/rim/atmosphere dataset (15 cars, typed)
    └── db.ts               # Prisma client singleton
public/
├── hdri/                   # 6 self-hosted 1k HDR environment maps
└── logo.svg
prisma/schema.prisma        # Prisma schema (SQLite)
```

## Known Limitations

- Vehicle bodies are **procedural Level-1 three.js models** (styled silhouettes with
  lighting detail), not licensed manufacturer 3D assets. The viewer is structured so
  real GLB models can be swapped in later.
- The Sound module is a **procedural RPM visualizer** — it does not play recorded
  engine audio.
- The Track module uses **stylized circuits** with telemetry overlays, not scanned
  real-world tracks.
- Prisma/SQLite is configured and ready, but the current feature set does not read or
  write server data; resetting browser storage resets your garage, achievements and
  race records.
- In headless/CI browser environments without WebGL, the 3D scene cannot render
  (the UI still loads).
