import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "CARIO — Interactive Automotive Exploration",
  description:
    "Every car is its own interactive world. CARIO is a premium, cinematic automotive exploration experience.",
  keywords: ["CARIO", "automotive", "3D", "configurator", "exploration"],
  authors: [{ name: "CARIO" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "CARIO — Interactive Automotive Exploration",
    description: "Every car is its own interactive world.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${inter.variable} ${jetbrains.variable} antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
