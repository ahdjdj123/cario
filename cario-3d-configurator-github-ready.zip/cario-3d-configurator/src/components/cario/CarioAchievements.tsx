"use client";

import { motion } from "framer-motion";
import { Lock } from "lucide-react";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn, ViewHeader } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import {
  ACHIEVEMENTS,
  TIER_LABEL,
  computeAchievementsCached,
  type AchievementTier,
  type ComputedAchievement,
} from "@/lib/cario/achievements";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioAchievements — the Milestones gallery (CARIO / 08)
   ------------------------------------------------------------
   A monochrome trophy room. Every achievement card shows its
   live progress (derived from the persisted store) and its
   unlock state. Unlocked cards lead the grid; a summary header
   shows the overall completion plus a per-tier breakdown.
   ============================================================ */

const TIER_ORDER: AchievementTier[] = ["legendary", "rare", "common"];

export function CarioAchievements() {
  const goBack = useCario((s) => s.goBack);
  const grain = useCario((s) => s.settings.grain);
  const computed = useCario(computeAchievementsCached);

  const total = computed.length;
  const unlockedCount = computed.filter((a) => a.unlocked).length;
  const completion = total > 0 ? unlockedCount / total : 0;

  // Unlocked first, then by tier weight (legendary → common)
  const ordered = [...computed].sort((a, b) => {
    if (a.unlocked !== b.unlocked) return a.unlocked ? -1 : 1;
    return TIER_ORDER.indexOf(a.def.tier) - TIER_ORDER.indexOf(b.def.tier);
  });

  const tierSummary = TIER_ORDER.map((tier) => ({
    tier,
    unlocked: computed.filter((a) => a.unlocked && a.def.tier === tier).length,
    total: ACHIEVEMENTS.filter((a) => a.tier === tier).length,
  }));

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" grain={grain} />

      <div className="cario-scroll absolute inset-0 overflow-y-auto">
        <div className="mx-auto min-h-full max-w-5xl px-6 py-8 sm:px-10 sm:py-10">
          {/* Header */}
          <div className="flex flex-col gap-5">
            <div className="pointer-events-auto">
              <CornerReturn label="Back" onClick={() => goBack()} />
            </div>
            <ViewHeader
              eyebrow="CARIO / 08"
              title="Milestones"
              subtitle={`${ACHIEVEMENTS.length} achievements written by how you explore.`}
            />
          </div>

          {/* Summary */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-8 rounded-lg border border-white/8 bg-white/[0.02] p-6"
          >
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="flex items-baseline gap-3">
                <span className="font-display text-5xl font-extralight tabular-nums tracking-tight-3 text-cario-white">
                  {unlockedCount}
                </span>
                <span className="font-mono text-sm uppercase tracking-label text-cario-soft-gray">
                  / {total} unlocked
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
                {tierSummary.map(({ tier, unlocked, total: t }) => (
                  <span
                    key={tier}
                    className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray"
                  >
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        unlocked > 0 ? "bg-cario-white/80" : "bg-white/15"
                      )}
                    />
                    {TIER_LABEL[tier]} {unlocked}/{t}
                  </span>
                ))}
              </div>
            </div>
            {/* Completion bar */}
            <div className="mt-5 h-px w-full bg-white/8">
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: completion }}
                transition={{ duration: 1.1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="h-px origin-left bg-cario-white/70"
                style={{ width: "100%" }}
              />
            </div>
          </motion.div>

          {/* Achievement grid */}
          <div className="mt-8 grid grid-cols-1 gap-3 pb-10 sm:grid-cols-2 lg:grid-cols-3">
            {ordered.map((a, i) => (
              <AchievementCard key={a.def.id} achievement={a} index={i} />
            ))}
          </div>

          <p className="pb-8 text-center font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/30">
            Progress is stored locally · drag races are won in Compare
          </p>
        </div>
      </div>
    </motion.div>
  );
}

/* --- Card --- */
function AchievementCard({
  achievement: a,
  index,
}: {
  achievement: ComputedAchievement;
  index: number;
}) {
  const Icon = a.def.icon;
  const isLegend = a.def.tier === "legendary";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.25 + Math.min(index * 0.045, 0.5) }}
      className={cn(
        "group relative flex flex-col gap-3 rounded-lg border p-4 transition-colors duration-300",
        a.unlocked
          ? "border-white/15 bg-white/[0.04] hover:border-white/25"
          : "border-white/5 bg-transparent hover:border-white/10"
      )}
    >
      {/* Header row */}
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-colors",
            a.unlocked
              ? "border-white/25 bg-white/10 text-cario-white"
              : "border-white/8 bg-white/[0.02] text-cario-soft-gray/40"
          )}
        >
          {a.unlocked ? (
            <Icon className="h-4 w-4" />
          ) : (
            <Lock className="h-3.5 w-3.5" />
          )}
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <div className="flex items-center justify-between gap-2">
            <span
              className={cn(
                "truncate font-display text-[13px] font-medium tracking-tight-2",
                a.unlocked ? "text-cario-white" : "text-cario-soft-gray"
              )}
            >
              {a.def.title}
            </span>
            {a.unlocked ? (
              <span className="shrink-0 font-mono text-[8px] uppercase tracking-label text-cario-white/80">
                ✓ Unlocked
              </span>
            ) : (
              <span className="shrink-0 font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                {TIER_LABEL[a.def.tier]}
              </span>
            )}
          </div>
          <p className="line-clamp-2 text-[11px] leading-relaxed text-cario-soft-gray">
            {a.def.description}
          </p>
        </div>
      </div>

      {/* Progress */}
      <div className="mt-auto flex items-center gap-3">
        <div className="h-px flex-1 bg-white/8">
          <div
            className={cn(
              "h-px transition-all duration-700",
              a.unlocked ? "bg-cario-white/80" : "bg-cario-soft-gray/40"
            )}
            style={{ width: `${Math.round(a.progress * 100)}%` }}
          />
        </div>
        <span
          className={cn(
            "font-mono text-[9px] tabular-nums uppercase tracking-label",
            a.unlocked ? "text-cario-light-gray" : "text-cario-soft-gray/50"
          )}
        >
          {a.label}
        </span>
      </div>

      {/* Legendary unlock glow */}
      {a.unlocked && isLegend && (
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-lg"
          style={{
            boxShadow:
              "inset 0 0 24px rgba(255,255,255,0.06), 0 0 18px rgba(255,255,255,0.04)",
          }}
        />
      )}
    </motion.div>
  );
}
