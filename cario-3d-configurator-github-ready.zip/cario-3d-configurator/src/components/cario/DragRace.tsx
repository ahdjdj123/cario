"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeftRight, Flag, X } from "lucide-react";
import { useCario } from "@/lib/cario/store";
import { driverGrade } from "@/lib/cario/driver";
import type { Vehicle } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   DragRaceOverlay — head-to-head racing (Compare view)
   ------------------------------------------------------------
   A self-contained overlay that stages two of the compared cars
   on a 402 m strip:

   1. SETUP    — mode picker (STANDING / ROLL), lane cards,
                 pairing picker + LAUNCH
   2. COUNTDOWN— monochrome christmas tree (3 lights → GO)
   3. RACING   — RAF-driven telemetry, distance strip w/ ticks,
                 checkered finish, live speed readouts
   4. RESULT   — winner banner, margin (s + m), trap speeds,
                 best-of-3 series scoring. REMATCH keeps the
                 series alive; first to 2 wins takes it. Wins are
                 recorded to the store (dragWins → milestone).

   Physics: each car's official 0–100 km/h time and top speed fit
   a drag-friendly model  a(v) = a0 · (1 − v/vmax)  where
   a0 = (vmax/t100)·ln(vmax/(vmax−100/3.6)). Standing starts give
   RWD cars a brief reduced-grip launch window; ROLL races start
   both cars at 60 km/h fully loaded up (no launch penalty).
   Each run is pre-simulated by a pure function; the RAF loop only
   consumes the samples — no physics inside the render loop.
   ============================================================ */

const RACE_DISTANCE_M = 402;
const ROLL_START_KMH = 60;
const RACES_TO_WIN = 2; // standard series: best of 3
const E_RACES_TO_WIN = 3; // endurance series: best of 5
const KMH_TO_MS = 1 / 3.6;

type RaceMode = "standing" | "roll" | "hot-seat" | "endurance";

const racesToWinFor = (m: RaceMode) => (m === "endurance" ? E_RACES_TO_WIN : RACES_TO_WIN);
const maxRacesFor = (m: RaceMode) => racesToWinFor(m) * 2 - 1;

/* --- Reaction game (standing + hot-seat + endurance starts) --------
   STANDING — lane A is the player lane: SPACE / tap on GO. Pressing
   before the green is a red-light DQ. Never pressing hands the
   launch to the AI pilot. Lane B is always driven by the AI.
   ENDURANCE — a solo standing race stretched into a best-of-5 series
   with tyre wear: the losing lane thrashes its tyres twice as hard,
   launch grip and acceleration fall off as the meeting progresses.
   HOT-SEAT — two humans: P1 drives lane A (SPACE / tap top half),
   P2 drives lane B (ENTER / tap bottom half). Same red-light rule
   per lane; an unpressed lane hands its launch to the AI pilot.
   ROLL — no reaction phase, both cars arrive at speed loaded up. */
const AI_PILOT_REACTION_S = 0.45;
const AI_OPPONENT_REACTION_S: [number, number] = [0.28, 0.42];
const PERFECT_REACTION_S = 0.2;

interface CarModel {
  a0: number;
  vmax: number;
  awd: boolean;
}

function buildModel(car: Vehicle): CarModel {
  const vmax = car.spec.topSpeed * KMH_TO_MS;
  const v100 = 100 * KMH_TO_MS;
  const t100 = Math.max(car.spec.acceleration, 1.2);
  // t100 = (vmax/a0)·ln(vmax/(vmax−v100))  →  solve for a0
  const a0 = (vmax / t100) * Math.log(vmax / (vmax - v100));
  const dt = (car.spec.drivetrain ?? "").toUpperCase();
  const awd = /AWD|4WD|4MATIC|QUATTRO|XDRIVE|E-FOUR/.test(dt);
  return { a0, vmax, awd };
}

interface RunSample {
  t: number;
  s: number;
  v: number;
}

interface RunResult {
  samples: RunSample[];
  finishTime: number;
  trapSpeed: number;
}

/** Pre-simulate a full quarter-mile run at fixed dt. `wear` (0..1) is
 *  tyre wear (endurance series): it softens the standing-start launch
 *  window and trims acceleration for that lane as the meeting goes on. */
function simulateRun(model: CarModel, mode: RaceMode, dt = 0.02, wear = 0): RunResult {
  const v0 = mode === "roll" ? ROLL_START_KMH * KMH_TO_MS : 0;
  const standingStart = mode === "standing" || mode === "endurance";
  const samples: RunSample[] = [{ t: 0, s: 0, v: v0 }];
  let t = 0;
  let s = 0;
  let v = v0;
  while (t < 60) {
    const prevT = t;
    const prevS = s;
    let a = model.a0 * (1 - v / model.vmax);
    // Launch window: from a standing start RWD cars briefly trade
    // acceleration for grip. A rolling car is already loaded up.
    // Tyre wear stretches the slip: the launch factor degrades and
    // the whole run pulls a little weaker (worn slicks = less bite).
    if (standingStart && t < 0.55 && !model.awd) a *= 0.93 - wear * 0.08;
    if (standingStart && wear > 0) a *= 1 - wear * 0.05;
    v += a * dt;
    if (v > model.vmax) v = model.vmax;
    s += v * dt;
    t += dt;
    if (s >= RACE_DISTANCE_M) {
      // Interpolate the exact finish point within this step
      const overshoot = s - RACE_DISTANCE_M;
      const frac = 1 - overshoot / Math.max(v, 0.001);
      const tFin = prevT + dt * frac;
      samples.push({ t: tFin, s: RACE_DISTANCE_M, v });
      return { samples, finishTime: tFin, trapSpeed: v / KMH_TO_MS };
    }
    samples.push({ t, s, v });
  }
  // Safety net (should never trigger with real data)
  return { samples, finishTime: t, trapSpeed: v / KMH_TO_MS };
}

/** Sample state at an arbitrary time (lerp between samples). */
function stateAt(run: RunResult, t: number): RunSample {
  const { samples } = run;
  if (t <= 0) return samples[0];
  if (t >= run.finishTime) return samples[samples.length - 1];
  // Binary search keeps per-frame cost constant (~600 samples)
  let lo = 0;
  let hi = samples.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (samples[mid].t <= t) lo = mid;
    else hi = mid;
  }
  const a = samples[lo];
  const b = samples[hi];
  const f = (t - a.t) / Math.max(b.t - a.t, 1e-6);
  return {
    t,
    s: a.s + (b.s - a.s) * f,
    v: a.v + (b.v - a.v) * f,
  };
}

const fmtTime = (s: number) => `${s.toFixed(2)}s`;

interface RaceOutcome {
  winner: Vehicle | null;
  marginS: number;
  marginM: number;
  finishA: number;
  finishB: number;
  trapA: number;
  trapB: number;
  /** Reaction times in seconds — reaction modes only, null in roll mode */
  reactionA: number | null;
  reactionB: number | null;
  /** Set when the reaction phase ended early: this lane red-lit the tree */
  falseStart?: "A" | "B";
  /** True when a lane never pressed and the AI pilot launched for it */
  assistA?: boolean;
  assistB?: boolean;
}

type Phase = "setup" | "countdown" | "racing" | "result";

export function DragRaceOverlay({
  vehicles,
  open,
  onClose,
}: {
  vehicles: Vehicle[];
  open: boolean;
  onClose: () => void;
}) {
  const reduceMotion = useCario((s) => s.settings.reduceMotion);
  const recordDragRace = useCario((s) => s.recordDragRace);

  const [laneA, setLaneA] = useState(0);
  const [laneB, setLaneB] = useState(1);
  const [mode, setMode] = useState<RaceMode>("standing");
  const [phase, setPhase] = useState<Phase>("setup");
  const [lightStage, setLightStage] = useState(0); // 0..3 (4 = GO)
  const [simTime, setSimTime] = useState(0);
  const [runs, setRuns] = useState<{ a: RunResult; b: RunResult } | null>(null);
  const [outcome, setOutcome] = useState<RaceOutcome | null>(null);
  /** Best-of-3 series: first to RACES_TO_WIN takes the meeting */
  const [series, setSeries] = useState({ a: 0, b: 0 });
  /** Endurance: per-lane tyre wear 0..1 — the losing lane thrashes
   *  its tyres twice as hard, so it degrades twice as fast. */
  const [wear, setWear] = useState({ a: 0, b: 0 });
  /** Per-round outcomes for the endurance round pips */
  const [roundLog, setRoundLog] = useState<Array<"A" | "B">>([]);
  /** Session launch stats (reaction modes): GENUINE presses only —
   *  AI-pilot launches are excluded. A = solo player / P1, B = P2. */
  const [rtStats, setRtStats] = useState({
    bestA: null as number | null,
    sumA: 0,
    countA: 0,
    bestB: null as number | null,
    sumB: 0,
    countB: 0,
    reds: 0,
  });
  /** Reaction game — per-lane press state: "idle" staged at the line,
   *  number = measured reaction (s), "jump" = red light. Standing arms
   *  lane A only; hot-seat arms both lanes. */
  const [playerReactA, setPlayerReactA] = useState<number | "jump" | "idle">("idle");
  const [playerReactB, setPlayerReactB] = useState<number | "jump" | "idle">("idle");
  /** performance.now() at the moment GO fired (reaction clock origin) */
  const goAtRef = useRef<number | null>(null);
  /** Lane A's measured reaction in seconds — null until the first press */
  const reactionARef = useRef<number | null>(null);
  /** Lane B's reaction — standing: randomized AI value; hot-seat: null
   *  until P2 presses; roll: unused. */
  const reactionBRef = useRef<number | null>(0);

  const recordedRef = useRecordGuard();
  /** One endurance-series record per completed best-of-5 meeting */
  const seriesRecordedRef = useRef(false);
  const carA = vehicles[laneA] ?? vehicles[0];
  const carB = vehicles[laneB] ?? vehicles[1] ?? vehicles[0];

  // Reset ONLY on the closed→open transition. A plain [open, vehicles]
  // dependency would re-fire on unrelated parent re-renders and wipe a
  // running race, so guard with a previous-open ref.
  const wasOpenRef = useRef(false);
  useEffect(() => {
    if (open && !wasOpenRef.current) {
      setPhase("setup");
      setLightStage(0);
      setSimTime(0);
      setRuns(null);
      setOutcome(null);
      setMode("standing");
      setSeries({ a: 0, b: 0 });
      setWear({ a: 0, b: 0 });
      setRoundLog([]);
      seriesRecordedRef.current = false;
      setRtStats({ bestA: null, sumA: 0, countA: 0, bestB: null, sumB: 0, countB: 0, reds: 0 });
      recordedRef.current = false;
      setPlayerReactA("idle");
      setPlayerReactB("idle");
      goAtRef.current = null;
      reactionARef.current = null;
      setLaneA(0);
      setLaneB(vehicles.length > 1 ? 1 : 0);
    }
    wasOpenRef.current = open;
  }, [open, vehicles, recordedRef]);

  const abort = useCallback(() => {
    setPhase("setup");
    setLightStage(0);
    setSimTime(0);
    setRuns(null);
  }, []);

  /* --- Esc: abort during countdown/race, close otherwise --- */
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      if (phase === "racing" || phase === "countdown") abort();
      else onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, phase, onClose, abort]);

  /* --- Countdown → GO --- */
  useEffect(() => {
    if (phase !== "countdown") return;
    if (!carA || !carB) return;
    // Every race start (launch AND rematch) gets a fresh record-once
    // guard — reset synchronously at countdown entry so a rematch can
    // never inherit the previous race's "already recorded" state.
    recordedRef.current = false;
    // Fresh reaction inputs for both lanes. Lane B is AI-driven in the
    // solo modes (standing + endurance); in hot-seat both lanes are human.
    reactionARef.current = null;
    setPlayerReactA("idle");
    setPlayerReactB("idle");
    goAtRef.current = null;
    reactionBRef.current =
      mode === "hot-seat"
        ? null
        : AI_OPPONENT_REACTION_S[0] +
          Math.random() * (AI_OPPONENT_REACTION_S[1] - AI_OPPONENT_REACTION_S[0]);
    const steps = reduceMotion ? [0, 220, 440, 660] : [0, 700, 1400, 2100];
    const timers = steps.map((ms, i) =>
      window.setTimeout(() => {
        setLightStage(i + 1);
        if (i === steps.length - 1) {
          // GO — freeze the reaction clock origin, then stage the runs
          goAtRef.current = performance.now();
          setRuns({
            a: simulateRun(buildModel(carA), mode, 0.02, wear.a),
            b: simulateRun(buildModel(carB), mode, 0.02, wear.b),
          });
          setSimTime(0);
          setPhase("racing");
        }
      }, ms)
    );
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [phase, reduceMotion, carA, carB, mode, wear, recordedRef]);

  /* --- Reaction game input (standing + hot-seat) ---------------------
     Countdown: a lane's key/tap = jump start → instant red-light DQ.
     Racing: the lane's first press freezes its reaction time.
     STANDING: lane A only (SPACE / any tap). Lane B is AI.
     HOT-SEAT: P1 = SPACE / tap top half, P2 = ENTER / tap bottom half.
     Button clicks (close etc.) never count as launches.            */
  useEffect(() => {
    if (!open || mode === "roll") return;
    if (phase !== "countdown" && phase !== "racing") return;
    const hotSeat = mode === "hot-seat";
    const maxRaces = maxRacesFor(mode);

    const lanePress = (lane: "A" | "B") => {
      if (phase === "countdown") {
        // FALSE START — red light the pressing lane, award the race to
        // the opponent, count it in the series + milestones.
        const winner = lane === "A" ? carB : carA;
        if (lane === "A") {
          reactionARef.current = null;
          setPlayerReactA("jump");
        } else {
          reactionBRef.current = null;
          setPlayerReactB("jump");
        }
        setOutcome({
          winner: winner ?? null,
          marginS: 0,
          marginM: 0,
          finishA: 0,
          finishB: 0,
          trapA: 0,
          trapB: 0,
          reactionA: null,
          reactionB: null,
          falseStart: lane,
        });
        const aWon = lane === "B";
        setSeries((prev) => ({
          a: prev.a + (aWon ? 1 : 0),
          b: prev.b + (aWon ? 0 : 1),
        }));
        setRoundLog((prev) => (prev.length < maxRaces ? [...prev, aWon ? "A" : "B"] : prev));
        // A jumped launch abuses the clutch and tyres: +20% wear for the
        // offender; the awarded winner still does a burnout (+8%).
        setWear((prev) => ({
          a: Math.min(1, prev.a + (lane === "A" ? 0.2 : 0.08)),
          b: Math.min(1, prev.b + (lane === "A" ? 0.08 : 0.2)),
        }));
        setRtStats((prev) => ({ ...prev, reds: prev.reds + 1 }));
        setPhase("result");
        if (!recordedRef.current) {
          recordedRef.current = true;
          // Solo: the player can only red-light lane A, so the AI takes
          // the race — no dragWins credit (meta.redLight keeps the DQ).
          recordDragRace(
            hotSeat ? (winner?.id ?? null) : null,
            hotSeat ? { hotSeat: true } : { redLight: true }
          );
        }
        return;
      }
      // Racing — the lane's first press after GO freezes its reaction
      if (goAtRef.current === null) return;
      if (lane === "A") {
        if (reactionARef.current === null) {
          const r = Math.max((performance.now() - goAtRef.current) / 1000, 0.05);
          reactionARef.current = r;
          setPlayerReactA(r);
        }
      } else if (hotSeat && reactionBRef.current === null) {
        const r = Math.max((performance.now() - goAtRef.current) / 1000, 0.05);
        reactionBRef.current = r;
        setPlayerReactB(r);
      }
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === "Space" || e.key === " ") {
        e.preventDefault();
        lanePress("A");
      } else if (hotSeat && (e.code === "Enter" || e.key === "Enter")) {
        e.preventDefault();
        lanePress("B");
      }
    };
    const onPointer = (e: PointerEvent) => {
      const el = e.target as HTMLElement | null;
      // Real buttons stay buttons (close etc.). Guard the method —
      // non-Element targets (document/window) have no closest().
      if (el && typeof el.closest === "function" && el.closest("button")) return;
      if (hotSeat) {
        // Lane A owns the top half of the viewport, lane B the bottom
        lanePress(e.clientY < window.innerHeight / 2 ? "A" : "B");
      } else {
        lanePress("A");
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onPointer);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointerdown", onPointer);
    };
  }, [open, phase, mode, carA, carB, recordDragRace, recordedRef]);

  /* --- Racing loop: advance sim clock, consume samples ---
     Reaction modes offset each lane's sample clock by its reaction
     time: a car that hasn't reacted yet simply sits at s = 0 on the
     line. Roll starts have no reaction phase (offset 0). */
  useEffect(() => {
    if (phase !== "racing" || !runs) return;
    const reactionMode = mode !== "roll";
    // Live reaction lookups — a driver may press mid-race; an unpressed
    // lane is handed to the AI pilot.
    const reactA = () =>
      reactionMode ? (reactionARef.current ?? AI_PILOT_REACTION_S) : 0;
    const reactB = () =>
      reactionMode ? (reactionBRef.current ?? AI_PILOT_REACTION_S) : 0;
    const effA = () => runs.a.finishTime + reactA();
    const effB = () => runs.b.finishTime + reactB();
    const totalFinish = () => Math.max(effA(), effB());

    let last = performance.now();
    let t = 0;
    let frame = 0;
    let raf = 0;

    const finish = () => {
      const rA = reactA();
      const rB = reactB();
      const finishA = runs.a.finishTime + rA;
      const finishB = runs.b.finishTime + rB;
      const diff = finishA - finishB;
      const deadHeat = Math.abs(diff) < 0.05;
      const winner = deadHeat ? null : diff < 0 ? carA : carB;
      const winnerRun = diff <= 0 ? runs.a : runs.b;
      const loserRun = diff <= 0 ? runs.b : runs.a;
      const marginS = deadHeat ? 0 : Math.abs(diff);
      // Gap in metres: how far short of the line the loser is at the
      // winner's finish moment. Each lane runs on its own reaction
      // clock, so the loser's sample time at that wall-clock moment is
      // winnerEffFinish − rLoser (may still be staged at s = 0).
      const rWinner = diff <= 0 ? rA : rB;
      const rLoser = diff <= 0 ? rB : rA;
      const marginM = deadHeat
        ? 0
        : RACE_DISTANCE_M -
          stateAt(loserRun, winnerRun.finishTime + rWinner - rLoser).s;

      setSimTime(totalFinish());
      setOutcome({
        winner,
        marginS,
        marginM,
        finishA,
        finishB,
        trapA: runs.a.trapSpeed,
        trapB: runs.b.trapSpeed,
        reactionA: reactionMode ? rA : null,
        reactionB: reactionMode ? rB : null,
        assistA: reactionMode && reactionARef.current === null,
        assistB: reactionMode && reactionBRef.current === null,
      });
      // Series bookkeeping — functional update so the racing effect
      // never needs the live series in its dependency list.
      const aWon = winner ? winner.id === carA?.id : false;
      const maxRaces = maxRacesFor(mode);
      setSeries((prev) => ({
        a: prev.a + (aWon ? 1 : 0),
        b: prev.b + (aWon ? 0 : 1),
      }));
      if (winner) {
        setRoundLog((prev) => (prev.length < maxRaces ? [...prev, aWon ? "A" : "B"] : prev));
      }
      // Tyre wear — endurance only: winner +8% (clean launch), loser
      // +16% (thrashed tyres), dead heat +12% each.
      if (mode === "endurance") {
        setWear((prev) => ({
          a: Math.min(1, prev.a + (deadHeat ? 0.12 : aWon ? 0.08 : 0.16)),
          b: Math.min(1, prev.b + (deadHeat ? 0.12 : aWon ? 0.16 : 0.08)),
        }));
      }
      // Session launch stats — only genuine presses count per driver
      // (an AI-pilot launch hands the clock to the 0.45 s pilot).
      const pA = reactionMode ? reactionARef.current : null;
      const pB = mode === "hot-seat" ? reactionBRef.current : null;
      setRtStats((prev) => ({
        bestA:
          pA !== null
            ? prev.bestA === null
              ? pA
              : Math.min(prev.bestA, pA)
            : prev.bestA,
        sumA: pA !== null ? prev.sumA + pA : prev.sumA,
        countA: pA !== null ? prev.countA + 1 : prev.countA,
        bestB:
          pB !== null
            ? prev.bestB === null
              ? pB
              : Math.min(prev.bestB, pB)
            : prev.bestB,
        sumB: pB !== null ? prev.sumB + pB : prev.sumB,
        countB: pB !== null ? prev.countB + 1 : prev.countB,
        reds: prev.reds,
      }));
      setPhase("result");
      if (!recordedRef.current) {
        recordedRef.current = true;
        // Career bookkeeping — solo standing/endurance races feed the
        // driver's R/T grade; hot-seat duels count separately (no solo
        // credit). dragWins only counts the PLAYER's lane: in every
        // solo mode that is lane A, so an AI-lane win records no win.
        const playerWon = aWon;
        if (mode === "standing" || mode === "endurance") {
          recordDragRace(playerWon && winner ? winner.id : null, {
            playerRt: reactionARef.current,
          });
        } else if (mode === "hot-seat") {
          recordDragRace(winner?.id ?? null, { hotSeat: true });
        } else {
          recordDragRace(playerWon && winner ? winner.id : null);
        }
      }
    };

    const step = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      t += dt;
      if (t >= totalFinish()) {
        finish();
        return;
      }
      // Throttle React updates to every other frame (~30fps) — plenty
      // for telemetry, keeps the overlay light.
      if (frame++ % 2 === 0) setSimTime(t);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [phase, runs, carA, carB, mode, recordDragRace, recordedRef]);

  const liveA = runs
    ? stateAt(runs.a, simTime - (mode !== "roll" ? (reactionARef.current ?? AI_PILOT_REACTION_S) : 0))
    : null;
  const liveB = runs
    ? stateAt(runs.b, simTime - (mode !== "roll" ? (reactionBRef.current ?? AI_PILOT_REACTION_S) : 0))
    : null;

  const racesToWin = racesToWinFor(mode);
  const maxRaces = maxRacesFor(mode);
  const seriesDone = series.a >= racesToWin || series.b >= racesToWin;
  const raceNo = Math.min(series.a + series.b + 1, maxRaces);

  /* Career (persisted) — primitive selectors only, so the snapshot
     caching stays intact. */
  const careerRaces = useCario((s) => s.dragRacesRun);
  const careerBest = useCario((s) => s.bestReaction);
  const careerReds = useCario((s) => s.redLights);
  const careerDuels = useCario((s) => s.hotSeatRaces);
  const careerSeries = useCario((s) => s.enduranceSeries);
  const careerSeriesWins = useCario((s) => s.enduranceWins);

  /* Endurance career — one record per completed best-of-5 series. */
  const recordEnduranceSeries = useCario((s) => s.recordEnduranceSeries);
  useEffect(() => {
    if (mode !== "endurance" || phase !== "result") return;
    if (seriesRecordedRef.current) return;
    if (series.a >= E_RACES_TO_WIN || series.b >= E_RACES_TO_WIN) {
      seriesRecordedRef.current = true;
      recordEnduranceSeries(series.a >= E_RACES_TO_WIN);
    }
  }, [mode, phase, series, recordEnduranceSeries]);

  /** Result-footer reaction caption for a lane — reaction modes only. */
  const reactionCaption = (lane: "A" | "B"): { text: string; dq?: boolean } | null => {
    if (mode === "roll" || !outcome) return null;
    if (outcome.falseStart === lane) return { text: "R/T · red light", dq: true };
    const rt = lane === "A" ? outcome.reactionA : outcome.reactionB;
    const assist = lane === "A" ? outcome.assistA : outcome.assistB;
    const parts = [`R/T ${formatReaction(rt)}`];
    if (rt !== null && rt < PERFECT_REACTION_S) parts.push("perfect");
    if (assist) parts.push("ai pilot");
    else if (mode === "hot-seat") parts.push(lane === "A" ? "p1" : "p2");
    else if (lane === "B") parts.push("ai");
    return { text: parts.join(" · ") };
  };

  if (vehicles.length < 2) return null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35 }}
          data-cario-overlay="true"
          className="fixed inset-0 z-[60] overflow-y-auto bg-[#050608]/95 backdrop-blur-xl"
          role="dialog"
          aria-modal="true"
          aria-label="Drag race"
        >
          <div className="mx-auto flex min-h-full w-full max-w-4xl flex-col justify-center px-5 py-8 sm:px-8">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Flag className="h-4 w-4 text-cario-soft-gray" />
                <div className="flex flex-col">
                  <span className="font-display text-sm font-medium uppercase tracking-wider-2 text-cario-white">
                    Drag Race
                  </span>
                  <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                    {mode === "standing"
                      ? `Quarter mile · ${RACE_DISTANCE_M} m · standing start`
                      : mode === "hot-seat"
                      ? `Quarter mile · ${RACE_DISTANCE_M} m · hot seat · 2 drivers`
                      : mode === "endurance"
                      ? `Quarter mile · ${RACE_DISTANCE_M} m · endurance · best of ${maxRaces}`
                      : `Quarter mile · ${RACE_DISTANCE_M} m · rolling start ${ROLL_START_KMH} km/h`}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                aria-label="Close drag race"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Series scoreboard — best of 3 */}
            <div
              className="mt-5 flex flex-col items-center gap-1.5"
              aria-label={`Series score ${series.a} to ${series.b}`}
            >
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-2">
                  {carA && (
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ background: carA.colors[0].hex, opacity: 0.85 }}
                      aria-hidden
                    />
                  )}
                  <span
                    className={cn(
                      "font-display text-xl font-light tabular-nums tracking-tight-2",
                      series.a >= racesToWin ? "text-cario-white" : "text-cario-light-gray"
                    )}
                  >
                    {series.a}
                  </span>
                </span>
                <span className="h-4 w-px bg-white/10" aria-hidden />
                <span className="flex items-center gap-2">
                  <span
                    className={cn(
                      "font-display text-xl font-light tabular-nums tracking-tight-2",
                      series.b >= racesToWin ? "text-cario-white" : "text-cario-light-gray"
                    )}
                  >
                    {series.b}
                  </span>
                  {carB && (
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ background: carB.colors[0].hex, opacity: 0.85 }}
                      aria-hidden
                    />
                  )}
                </span>
              </div>
              <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                {seriesDone
                  ? "Series decided"
                  : `Best of ${maxRaces} · race ${raceNo} of ${maxRaces}`}
              </span>
            </div>

            {/* Endurance round markers — one pip per completed round,
                filled with the winning lane's colour; the remaining
                slots stay as faint outlines. */}
            {mode === "endurance" && roundLog.length > 0 && (
              <div
                className="mt-2 flex items-center justify-center gap-1.5"
                aria-label={`Endurance rounds played: ${roundLog.length} of ${maxRaces}`}
              >
                {Array.from({ length: maxRaces }, (_, i) => {
                  const roundWinner = roundLog[i];
                  return (
                    <span
                      key={i}
                      title={
                        roundWinner
                          ? `Round ${i + 1} — ${roundWinner === "A" ? carA?.model : carB?.model}`
                          : `Round ${i + 1}`
                      }
                      className={cn(
                        "h-1.5 w-4 rounded-full transition-colors duration-500",
                        roundWinner ? "" : "border border-white/10 bg-transparent"
                      )}
                      style={
                        roundWinner
                          ? {
                              background:
                                roundWinner === "A"
                                  ? carA?.colors[0].hex ?? "#fff"
                                  : carB?.colors[0].hex ?? "#fff",
                              opacity: 0.9,
                            }
                          : undefined
                      }
                    />
                  );
                })}
              </div>
            )}

            {/* Start lights */}
            <div className="mt-6 flex items-center justify-center gap-3" aria-hidden>
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className={cn(
                    "cario-start-light",
                    lightStage > i && lightStage <= 3 && "lit",
                    lightStage > 3 && "go"
                  )}
                />
              ))}
              <AnimatePresence>
                {lightStage > 3 && phase === "racing" && (
                  <motion.span
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className="ml-2 font-display text-lg font-light tracking-mega text-cario-white"
                  >
                    GO
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
            {/* Reaction hint — reaction modes arm the human lanes */}
            {mode !== "roll" &&
              (phase === "countdown" ||
                (phase === "racing" &&
                  (mode !== "hot-seat"
                    ? playerReactA === "idle"
                    : playerReactA === "idle" || playerReactB === "idle"))) && (
              <div className="mt-2 flex justify-center">
                {mode === "hot-seat" ? (
                  <span
                    className={cn(
                      "animate-cario-pulse-soft flex items-center gap-2 rounded-full border border-white/10 px-3 py-1 font-mono text-[8px] uppercase tracking-label",
                      phase === "countdown" ? "text-cario-soft-gray/70" : "border-white/25 text-cario-white"
                    )}
                    role={phase === "racing" ? "status" : undefined}
                  >
                    {phase === "countdown" ? (
                      <>
                        <span>p1 <Keycap>space</Keycap> top</span>
                        <span className="text-cario-soft-gray/40">·</span>
                        <span>p2 <Keycap>enter</Keycap> bottom</span>
                      </>
                    ) : (
                      "React!"
                    )}
                  </span>
                ) : (
                  <span
                    className={cn(
                      "animate-cario-pulse-soft rounded-full border border-white/10 px-3 py-1 font-mono text-[8px] uppercase tracking-label",
                      phase === "countdown"
                        ? "text-cario-soft-gray/70"
                        : "border-white/25 text-cario-white"
                    )}
                    role={phase === "racing" ? "status" : undefined}
                  >
                    {phase === "countdown" ? "Stage ready — space / tap on go" : "React!"}
                  </span>
                )}
              </div>
            )}

            {/* Lanes */}
            <div className="mt-6 flex flex-col gap-3">
              <RaceLane
                label="Lane A"
                car={carA}
                live={liveA}
                phase={phase}
                outcome={outcome}
                isWinnerSide={outcome ? outcome.winner?.id === carA?.id : false}
                reaction={reactionCaption("A")}
                keyHint={mode === "hot-seat" && phase !== "result" ? "SPACE" : undefined}
                wear={mode === "endurance" ? wear.a : undefined}
              />
              {/* Hot-seat tap-zone divider */}
              {mode === "hot-seat" && (phase === "countdown" || phase === "racing") && (
                <div className="flex items-center gap-2" aria-hidden>
                  <span className="h-px flex-1 bg-white/8" />
                  <span className="font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/40">
                    tap zones · top p1 · bottom p2
                  </span>
                  <span className="h-px flex-1 bg-white/8" />
                </div>
              )}
              <RaceLane
                label="Lane B"
                car={carB}
                live={liveB}
                phase={phase}
                outcome={outcome}
                isWinnerSide={outcome ? outcome.winner?.id === carB?.id : false}
                reaction={reactionCaption("B")}
                keyHint={mode === "hot-seat" && phase !== "result" ? "ENTER" : undefined}
                wear={mode === "endurance" ? wear.b : undefined}
              />
            </div>

            {/* Result banner */}
            <AnimatePresence>
              {phase === "result" && outcome && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  className="mt-6 flex flex-col items-center gap-4 text-center"
                >
                  {outcome.falseStart ? (
                    <>
                      <span className="font-mono text-[9px] uppercase tracking-mega text-cario-soft-gray">
                        Race {raceNo - 1} · false start
                      </span>
                      <span className="font-display text-2xl font-light tracking-tight-2 text-cario-white sm:text-3xl">
                        Red light
                      </span>
                      <span className="cario-hazard-line h-1.5 w-28" aria-hidden />
                      <span className="font-mono text-[10px] uppercase tracking-label text-cario-light-gray">
                        Lane {outcome.falseStart} jumped the tree
                        {outcome.winner
                          ? ` — ${outcome.winner.brand} ${outcome.winner.model} takes it`
                          : ""}
                      </span>
                    </>
                  ) : seriesDone && outcome.winner ? (
                    <>
                      {/* Meeting winner takes the best-of-3 series */}
                      <span className="font-mono text-[9px] uppercase tracking-mega text-cario-soft-gray">
                        Series {Math.max(series.a, series.b)}–{Math.min(series.a, series.b)}
                      </span>
                      <span className="font-display text-2xl font-light tracking-tight-2 text-cario-white sm:text-3xl">
                        {outcome.winner.brand} {outcome.winner.model}
                      </span>
                      <span className="cario-hazard-line h-1.5 w-28" aria-hidden />
                      <span className="font-mono text-[10px] uppercase tracking-label text-cario-light-gray">
                        Takes the meeting
                      </span>
                    </>
                  ) : outcome.winner ? (
                    <>
                      <span className="font-mono text-[9px] uppercase tracking-mega text-cario-soft-gray">
                        Race {raceNo - 1} · Winner
                      </span>
                      <span className="font-display text-2xl font-light tracking-tight-2 text-cario-white sm:text-3xl">
                        {outcome.winner.brand} {outcome.winner.model}
                      </span>
                      <span className="font-mono text-[10px] uppercase tracking-label text-cario-light-gray">
                        Takes it by {outcome.marginS.toFixed(2)}s
                        {outcome.marginM >= 1
                          ? ` · ${outcome.marginM.toFixed(0)} m`
                          : ""}
                      </span>
                    </>
                  ) : (
                    <span className="font-display text-2xl font-light tracking-tight-2 text-cario-white">
                      Dead heat
                    </span>
                  )}
                  <div className="mt-1 flex items-center gap-3">
                    {seriesDone ? (
                      <button
                        type="button"
                        onClick={() => {
                          setSeries({ a: 0, b: 0 });
                          setOutcome(null);
                          setLightStage(0);
                          setWear({ a: 0, b: 0 });
                          setRoundLog([]);
                          seriesRecordedRef.current = false;
                          setPhase("setup");
                        }}
                        className="cario-btn-premium rounded-full border border-white/25 bg-white/10 px-6 py-2.5 font-mono text-[10px] uppercase tracking-label text-cario-white transition-all hover:border-white/40 hover:bg-white/15"
                      >
                        New series
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setLightStage(0);
                          setPhase("countdown");
                        }}
                        className="cario-btn-premium rounded-full border border-white/25 bg-white/10 px-6 py-2.5 font-mono text-[10px] uppercase tracking-label text-cario-white transition-all hover:border-white/40 hover:bg-white/15"
                      >
                        Race {raceNo}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onClose}
                      className="rounded-full border border-white/10 px-6 py-2.5 font-mono text-[10px] uppercase tracking-label text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-light-gray"
                    >
                      Close
                    </button>
                  </div>
                  {/* Session launch stats — per driver, genuine presses only */}
                  {mode !== "roll" && (rtStats.countA > 0 || rtStats.countB > 0 || rtStats.reds > 0) && (
                    <div className="mt-1 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 border-t border-white/6 pt-3 font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                      {mode === "hot-seat" ? (
                        <>
                          <span>
                            p1 r/t <span className="text-cario-white">{formatReaction(rtStats.bestA)}</span>
                            {rtStats.countA > 1 && (
                              <span className="text-cario-soft-gray/45"> · avg {formatReaction(rtStats.sumA / rtStats.countA)}</span>
                            )}
                          </span>
                          <span className="h-2.5 w-px bg-white/10" />
                          <span>
                            p2 r/t <span className="text-cario-white">{formatReaction(rtStats.bestB)}</span>
                            {rtStats.countB > 1 && (
                              <span className="text-cario-soft-gray/45"> · avg {formatReaction(rtStats.sumB / rtStats.countB)}</span>
                            )}
                          </span>
                        </>
                      ) : (
                        <>
                          <span>
                            best r/t <span className="text-cario-white">{formatReaction(rtStats.bestA)}</span>
                          </span>
                          {rtStats.countA > 1 && (
                            <span>
                              avg r/t <span className="text-cario-light-gray">{formatReaction(rtStats.sumA / rtStats.countA)}</span>
                            </span>
                          )}
                        </>
                      )}
                      {rtStats.reds > 0 && (
                        <>
                          <span className="h-2.5 w-px bg-white/10" />
                          <span className="text-[#C25B5B]">
                            {rtStats.reds} red light{rtStats.reds > 1 ? "s" : ""}
                          </span>
                        </>
                      )}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Setup controls */}
            {phase === "setup" && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-6 flex flex-col items-center gap-4"
              >
                {/* Start mode */}
                <div
                  role="group"
                  aria-label="Start mode"
                  className="flex flex-wrap justify-center rounded-md border border-white/8 bg-white/[0.02] p-0.5"
                >
                  {(
                    [
                      { value: "standing", label: "Standing", hint: "0 km/h" },
                      { value: "roll", label: "Roll", hint: `${ROLL_START_KMH} km/h` },
                      { value: "hot-seat", label: "Hot Seat", hint: "2 drivers" },
                      { value: "endurance", label: "Endurance", hint: "best of 5" },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.value}
                      type="button"
                      onClick={() => setMode(m.value)}
                      aria-pressed={mode === m.value}
                      className={cn(
                        "flex items-center gap-2 rounded-[5px] px-4 py-1.5 transition-colors",
                        mode === m.value
                          ? "bg-white/10 text-cario-white"
                          : "text-cario-soft-gray hover:text-cario-light-gray"
                      )}
                    >
                      <span className="font-mono text-[10px] uppercase tracking-label">{m.label}</span>
                      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                        {m.hint}
                      </span>
                    </button>
                  ))}
                </div>
                {vehicles.length > 2 && (
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                      Pairing
                    </span>
                    {vehicles.map((v, i) => {
                      const picked = i === laneA || i === laneB;
                      return (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => {
                            if (picked) return;
                            // Clicking an unpicked car fields it in Lane B
                            setLaneB(i);
                          }}
                          className={cn(
                            "flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] transition-all active:scale-95",
                            picked
                              ? "border-white/30 bg-white/10 text-cario-white"
                              : "border-white/8 text-cario-soft-gray hover:border-white/20 hover:text-cario-light-gray"
                          )}
                        >
                          <span
                            className="h-1.5 w-1.5 rounded-full"
                            style={{ background: v.colors[0].hex, opacity: 0.85 }}
                          />
                          {v.model}
                        </button>
                      );
                    })}
                    <button
                      type="button"
                      onClick={() => {
                        const a = laneA;
                        setLaneA(laneB);
                        setLaneB(a);
                      }}
                      className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/25 hover:text-cario-white"
                      aria-label="Swap lanes"
                      title="Swap lanes"
                    >
                      <ArrowLeftRight className="h-3 w-3" />
                    </button>
                  </div>
                )}
                {/* Career line — persisted driver record (primitive selectors) */}
                {careerRaces > 0 && (
                  <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                    <span className="flex items-center gap-1.5">
                      <span className="cario-grade text-[9px]">{driverGrade(careerBest).grade}</span>
                      <span>
                        career · {careerRaces} race{careerRaces === 1 ? "" : "s"}
                        {careerBest !== null ? ` · best r/t ${careerBest.toFixed(3)} s` : ""}
                        {careerReds > 0 ? ` · ${careerReds} red` : ""}
                        {careerDuels > 0 ? ` · ${careerDuels} duel${careerDuels === 1 ? "" : "s"}` : ""}
                        {careerSeries > 0
                          ? ` · ${careerSeries} endurance series · ${careerSeriesWins} won`
                          : ""}
                      </span>
                    </span>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setLightStage(0);
                    setPhase("countdown");
                  }}
                  className="cario-btn-premium rounded-full border border-white/25 bg-white/10 px-8 py-3 font-mono text-[11px] uppercase tracking-label text-cario-white transition-all hover:border-white/40 hover:bg-white/15"
                >
                  Launch Race
                </button>
                <span className="flex max-w-md flex-wrap items-center justify-center gap-1.5 px-4 text-center font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                  {mode === "standing" ? (
                    <span>
                      Space / tap on go · early press = red light · no press = ai pilot {AI_PILOT_REACTION_S.toFixed(2)} s · first to {RACES_TO_WIN} takes the series
                    </span>
                  ) : mode === "hot-seat" ? (
                    <span>
                      p1 <Keycap>space</Keycap> / top tap · p2 <Keycap>enter</Keycap> / bottom tap · early press = red light · first to {RACES_TO_WIN} takes the series
                    </span>
                  ) : mode === "endurance" ? (
                    <span>
                      Best of {maxRaces} against the clock · every round wears the tyres — the losing lane thrashes them twice as hard · worn rubber dulls the launch · first to {E_RACES_TO_WIN} takes the meeting
                    </span>
                  ) : (
                    <span>
                      Rolling start — no reaction phase · first to {RACES_TO_WIN} wins takes the series · wins count toward milestones
                    </span>
                  )}
                </span>
              </motion.div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* Tiny helper so the record-once guard survives re-renders */
function useRecordGuard() {
  const ref = useRef(false);
  return ref;
}

/* Keyboard keycap chip — space / enter hints in hot-seat mode */
function Keycap({ children }: { children: ReactNode }) {
  return <span className="cario-key ml-0.5">{children}</span>;
}

/* Reaction display — roll mode passes null, so keep it em-dash safe */
function formatReaction(r: number | null): string {
  return r === null ? "—" : `${r.toFixed(3)} s`;
}

/* --- One racing lane --- */
function RaceLane({
  label,
  car,
  live,
  phase,
  outcome,
  isWinnerSide,
  reaction,
  keyHint,
  wear,
}: {
  label: string;
  car?: Vehicle;
  live: { s: number; v: number } | null;
  phase: Phase;
  outcome: RaceOutcome | null;
  isWinnerSide: boolean;
  /** Reaction-time caption for the result footer (reaction modes) */
  reaction: { text: string; dq?: boolean } | null;
  /** Hot-seat: this lane's key, shown as a keycap chip in the header */
  keyHint?: string;
  /** Endurance: this lane's tyre wear 0..1 — degrades the launch */
  wear?: number;
}) {
  if (!car) return null;
  const progress = live ? Math.min(live.s / RACE_DISTANCE_M, 1) : 0;
  const speedKmh = live ? live.v / KMH_TO_MS : 0;
  const running = phase === "racing";
  const finished =
    phase === "result" && outcome
      ? label === "Lane A"
        ? outcome.finishA
        : outcome.finishB
      : null;
  const trapSpeed =
    phase === "result" && outcome
      ? label === "Lane A"
        ? outcome.trapA
        : outcome.trapB
      : null;

  return (
    <div
      className={cn(
        "rounded-lg border p-3 transition-colors duration-500 sm:p-4",
        isWinnerSide
          ? "border-white/25 bg-white/[0.05]"
          : "border-white/8 bg-white/[0.015]"
      )}
    >
      {/* Lane header */}
      <div className="mb-2.5 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span
            className="h-2 w-2 shrink-0 rounded-full"
            style={{ background: car.colors[0].hex, opacity: 0.85 }}
          />
          <div className="flex min-w-0 flex-col">
            <span className="truncate font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
              {car.model}
            </span>
            <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
              {label} · {car.brand} · {car.spec.horsepower} HP ·{" "}
              {car.spec.drivetrain ?? "—"}
            </span>
          </div>
        </div>
        <div className="flex shrink-0 items-baseline gap-3">
          {keyHint && (
            <span className="flex items-center gap-1.5 self-center">
              <Keycap>{keyHint}</Keycap>
            </span>
          )}
          {running && live && (
            <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
              {speedKmh.toFixed(0)}
              <span className="ml-1 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                km/h
              </span>
            </span>
          )}
          {finished !== null && (
            <span className="font-display text-base font-light tabular-nums text-cario-white">
              {fmtTime(finished)}
              {trapSpeed !== null && (
                <span className="ml-1.5 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                  trap {trapSpeed.toFixed(0)}
                </span>
              )}
            </span>
          )}
          {phase === "setup" && (
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50">
              0–100 {car.spec.acceleration}s
            </span>
          )}
          {wear !== undefined && (
            <span className="flex items-center gap-1.5" title={`Tyre wear ${Math.round(wear * 100)}%`}>
              <span className="relative h-1 w-8 overflow-hidden rounded-full bg-white/10">
                <span
                  className="absolute inset-y-0 left-0 rounded-full transition-[width] duration-700"
                  style={{
                    width: `${Math.max(4, wear * 100)}%`,
                    background:
                      wear < 0.34 ? "#8FA98F" : wear < 0.67 ? "#C9A25B" : "#C25B5B",
                  }}
                />
              </span>
              <span
                className={cn(
                  "font-mono text-[9px] uppercase tracking-label",
                  wear < 0.34
                    ? "text-cario-soft-gray/60"
                    : wear < 0.67
                    ? "text-[#C9A25B]"
                    : "text-[#C25B5B]"
                )}
              >
                tyre {Math.round(wear * 100)}%
              </span>
            </span>
          )}
        </div>
      </div>

      {/* Track strip */}
      <div className="relative h-9 overflow-hidden rounded-md border border-white/8 bg-black/40">
        {/* Distance ticks */}
        {[0, 100, 200, 300].map((m) => (
          <span
            key={m}
            aria-hidden
            className="absolute inset-y-0 w-px bg-white/6"
            style={{ left: `${(m / RACE_DISTANCE_M) * 100}%` }}
          />
        ))}
        <span
          aria-hidden
          className="absolute bottom-0.5 left-1 font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/30"
        >
          0 m
        </span>
        <span
          aria-hidden
          className="absolute bottom-0.5 left-[47%] font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/30"
        >
          200
        </span>

        {/* Progress fill + car marker */}
        <div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-white/[0.02] to-white/[0.10]"
          style={{ width: `${progress * 100}%` }}
        />
        <div
          className="absolute top-1/2 h-5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-sm"
          style={{
            left: `${progress * 100}%`,
            background: car.colors[0].hex,
            boxShadow: running ? `0 0 12px ${car.colors[0].hex}66` : "none",
            opacity: live ? 1 : 0.35,
          }}
        />

        {/* Checkered finish */}
        <div className="cario-checker absolute inset-y-0 right-0 w-2.5" />
      </div>

      {/* Result footer */}
      {phase === "result" && outcome && (
        <div className="mt-2 flex items-center justify-between gap-3 font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
          <span>
            0–100 {car.spec.acceleration}s · {car.spec.topSpeed} km/h
          </span>
          <span
            className={cn(
              "flex items-center gap-2",
              reaction?.dq && "text-cario-white/80"
            )}
          >
            {reaction && (
              <span className={reaction.dq ? "text-cario-white/80" : undefined}>
                {reaction.text}
              </span>
            )}
            <span className={isWinnerSide ? "text-cario-white/80" : undefined}>
              {isWinnerSide
                ? outcome.winner
                  ? "Winner"
                  : "Dead heat"
                : outcome.falseStart
                ? "—"
                : outcome.winner
                ? `+${Math.abs(
                    (label === "Lane A"
                      ? outcome.finishA - outcome.finishB
                      : outcome.finishB - outcome.finishA)
                  ).toFixed(2)}s`
                : "—"}
            </span>
          </span>
        </div>
      )}
    </div>
  );
}
