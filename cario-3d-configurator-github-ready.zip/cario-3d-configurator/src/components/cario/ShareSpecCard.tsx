"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Share2, Download, X, Copy, Check } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";
import { useCario } from "@/lib/cario/store";

/* ============================================================
   ShareSpecCard — downloadable spec sheet
   ------------------------------------------------------------
   Generates a premium monochrome spec card for a vehicle as an
   SVG string, then lets the user download it as a .svg file or
   copy the spec summary to clipboard.

   The card includes: brand/model, generation/year, tagline,
   key specs (power, 0-100, top speed, weight, engine,
   drivetrain), and the CARIO wordmark.
   ============================================================ */

export function ShareSpecCard({ vehicle }: { vehicle: Vehicle }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const pushToast = useCario((s) => s.pushToast);

  // Close on Escape — the overlay sentinel keeps the global handler
  // from navigating the view behind the open modal.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open]);

  const specLines = [
    { label: "Power", value: `${vehicle.spec.horsepower} HP` },
    { label: "0–100", value: `${vehicle.spec.acceleration} s` },
    { label: "Top Speed", value: `${vehicle.spec.topSpeed} km/h` },
    ...(vehicle.spec.weight ? [{ label: "Weight", value: `${vehicle.spec.weight} kg` }] : []),
    ...(vehicle.spec.engine ? [{ label: "Engine", value: vehicle.spec.engine }] : []),
    ...(vehicle.spec.drivetrain ? [{ label: "Drive", value: vehicle.spec.drivetrain }] : []),
  ];

  const handleDownload = () => {
    const svg = generateSvg(vehicle, specLines);
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cario-${vehicle.id}-spec.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = async () => {
    const text = formatSpecText(vehicle, specLines);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      pushToast("Spec sheet copied · deep link included", "copy");
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // clipboard not available
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white"
        aria-label="Share spec card"
        title="Share spec card"
      >
        <Share2 className="h-3.5 w-3.5" />
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
              data-cario-overlay="true"
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="fixed left-1/2 top-1/2 z-50 w-[400px] max-w-[88vw] -translate-x-1/2 -translate-y-1/2 cario-surface-strong rounded-lg"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
                <div className="flex items-center gap-2">
                  <Share2 className="h-4 w-4 text-cario-soft-gray" />
                  <span className="font-display text-sm font-medium tracking-wider-2 uppercase text-cario-white">
                    Spec Card
                  </span>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                  aria-label="Close"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Preview card */}
              <div className="px-5 py-5">
                <div className="rounded-lg border border-white/10 bg-black/40 p-5">
                  {/* Brand mark */}
                  <div className="flex items-center justify-between">
                    <span className="font-display text-xs font-light tracking-mega text-cario-white" style={{ textIndent: "0.42em" }}>
                      CARIO
                    </span>
                    <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                      {vehicle.brand} · {vehicle.generation} · {vehicle.year}
                    </span>
                  </div>
                  {/* Model name */}
                  <h3 className="mt-3 font-display text-2xl font-light tracking-tight-2 text-cario-white">
                    {vehicle.model}
                  </h3>
                  <p className="mt-1 text-[11px] italic text-cario-soft-gray">
                    {vehicle.tagline}
                  </p>
                  {/* Specs grid */}
                  <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 border-t border-white/8 pt-4">
                    {specLines.map((s) => (
                      <div key={s.label} className="flex flex-col gap-0.5">
                        <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                          {s.label}
                        </span>
                        <span className="font-display text-sm font-light tabular-nums text-cario-light-gray">
                          {s.value}
                        </span>
                      </div>
                    ))}
                  </div>
                  {/* Footer */}
                  <div className="mt-4 flex items-center justify-between border-t border-white/8 pt-3">
                    <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                      CARIO Spec Card
                    </span>
                    <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                      {new Date().getFullYear()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 border-t border-white/8 px-5 py-4">
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex flex-1 items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-4 py-2.5 text-cario-white transition-all hover:border-white/30 hover:bg-white/[0.08]"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span className="font-display text-[11px] font-medium uppercase tracking-wider-2">
                    Download SVG
                  </span>
                </button>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="flex items-center justify-center gap-2 rounded-full border border-white/10 px-4 py-2.5 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white"
                  title="Copies the spec sheet plus a /?car deep link"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-cario-white" /> : <Copy className="h-3.5 w-3.5" />}
                  <span className="font-display text-[11px] font-medium uppercase tracking-wider-2">
                    {copied ? "Copied" : "Copy"}
                  </span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* --- Generate an SVG spec card string --- */
function generateSvg(vehicle: Vehicle, specs: { label: string; value: string }[]): string {
  const w = 600;
  const h = 400;
  const specY = 180;
  const specGap = 50;
  const colX = [60, 320];

  const specItems = specs.map((s, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = colX[col];
    const y = specY + row * specGap;
    return `
      <text x="${x}" y="${y}" font-family="monospace" font-size="10" fill="#858990" letter-spacing="1.5">${s.label.toUpperCase()}</text>
      <text x="${x}" y="${y + 18}" font-family="sans-serif" font-size="18" font-weight="300" fill="#C9CBD0">${s.value}</text>
    `;
  }).join("");

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
  <rect width="${w}" height="${h}" fill="#08090B"/>
  <rect x="40" y="40" width="${w - 80}" height="${h - 80}" fill="none" stroke="#1A1C1F" stroke-width="1" rx="8"/>
  <text x="60" y="80" font-family="sans-serif" font-size="14" font-weight="300" fill="#F3F3F1" letter-spacing="5" text-indent="5">CARIO</text>
  <text x="${w - 60}" y="80" text-anchor="end" font-family="monospace" font-size="10" fill="#858990" letter-spacing="1.5">${vehicle.brand.toUpperCase()} · ${vehicle.generation} · ${vehicle.year}</text>
  <text x="60" y="120" font-family="sans-serif" font-size="32" font-weight="300" fill="#F3F3F1">${vehicle.model}</text>
  <text x="60" y="142" font-family="serif" font-size="13" font-style="italic" fill="#858990">${vehicle.tagline}</text>
  <line x1="60" y1="165" x2="${w - 60}" y2="165" stroke="#1A1C1F" stroke-width="1"/>
  ${specItems}
  <line x1="60" y1="${h - 60}" x2="${w - 60}" y2="${h - 60}" stroke="#1A1C1F" stroke-width="1"/>
  <text x="60" y="${h - 45}" font-family="monospace" font-size="9" fill="#3A3D42" letter-spacing="1.5">CARIO SPEC CARD</text>
  <text x="${w - 60}" y="${h - 45}" text-anchor="end" font-family="monospace" font-size="9" fill="#3A3D42" letter-spacing="1.5">${new Date().getFullYear()}</text>
</svg>`;
}

/* --- Format spec text for clipboard (includes a deep link) --- */
function formatSpecText(vehicle: Vehicle, specs: { label: string; value: string }[]): string {
  const link = typeof window !== "undefined"
    ? `${window.location.origin}${window.location.pathname}?car=${vehicle.id}`
    : "";
  const lines = [
    `CARIO — ${vehicle.brand} ${vehicle.model}`,
    `${vehicle.generation} · ${vehicle.year}`,
    `"${vehicle.tagline}"`,
    "",
    ...specs.map((s) => `${s.label}: ${s.value}`),
    "",
    link ? `Explore: ${link}` : "",
    "— Shared via CARIO",
  ];
  return lines.filter((l) => l !== "").join("\n");
}
