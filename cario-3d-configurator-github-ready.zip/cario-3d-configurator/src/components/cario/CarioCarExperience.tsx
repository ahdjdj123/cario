"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Heart } from "lucide-react";
import { CarViewer3D } from "@/components/cario/three/CarViewer3D";
import { InteriorScene, EngineScene } from "@/components/cario/three/Showroom";
import { ColorStudio } from "@/components/cario/ColorStudio";
import { WheelStudio } from "@/components/cario/WheelStudio";
import { AtmosphereStudio } from "@/components/cario/AtmosphereStudio";
import { SoundStudio } from "@/components/cario/SoundStudio";
import { TrackStudio } from "@/components/cario/TrackStudio";
import { ShareSpecCard } from "@/components/cario/ShareSpecCard";
import { SpecRadarChart } from "@/components/cario/SpecRadarChart";
import { PhotoStudio } from "@/components/cario/PhotoStudio";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn } from "@/components/cario/ui-parts/PrimaryActions";
import { VehicleTag } from "@/components/cario/ui-parts/VehicleMetadata";
import { useCario, useActiveColor, useActiveRim, type CarioCameraMode } from "@/lib/cario/store";
import { getVehicle } from "@/lib/vehicles";
import { getAtmosphere } from "@/lib/vehicles/atmosphere";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioCarExperience — the main immersive vehicle page
   ------------------------------------------------------------
   The selected vehicle dominates the viewport. A compact vertical
   control group on the right switches between EXTERIOR, INTERIOR,
   ENGINE, COLOR. Reserved modules (ATMOSPHERE, SOUND, TRACK) show
   a subtle "COMING SOON" state. Technical metadata anchored
   bottom-left.
   ============================================================ */

interface ControlDef {
  id: CarioCameraMode | "color" | "wheels" | "atmosphere" | "sound" | "track";
  index: string;
  label: string;
  soon?: boolean;
}

const CONTROLS: ControlDef[] = [
  { id: "exterior", index: "01", label: "Exterior" },
  { id: "interior", index: "02", label: "Interior" },
  { id: "engine", index: "03", label: "Engine" },
  { id: "color", index: "04", label: "Color" },
  { id: "wheels", index: "05", label: "Wheels" },
  { id: "atmosphere", index: "06", label: "Atmosphere" },
  { id: "sound", index: "07", label: "Sound" },
  { id: "track", index: "08", label: "Track" },
];

export function CarioCarExperience() {
  const goBack = useCario((s) => s.goBack);
  const setView = useCario((s) => s.setView);
  const selectedId = useCario((s) => s.selectedVehicleId);
  const cameraMode = useCario((s) => s.cameraMode);
  const setCameraMode = useCario((s) => s.setCameraMode);
  const atmosphereId = useCario((s) => s.atmosphereId);
  const favoriteIds = useCario((s) => s.favoriteIds);
  const toggleFavorite = useCario((s) => s.toggleFavorite);
  const pushToast = useCario((s) => s.pushToast);
  const grain = useCario((s) => s.settings.grain);
  const verbose = useCario((s) => s.settings.verboseSpecs);

  const vehicle = getVehicle(selectedId)!;
  const color = useActiveColor(vehicle);
  const { styleId: rimStyleId, finishId: rimFinishId } = useActiveRim(vehicle);
  const atmosphere = getAtmosphere(atmosphereId);
  const isFavorited = favoriteIds.includes(selectedId);

  const [active, setActive] = useState<CarioCameraMode | "color" | "wheels" | "atmosphere" | "sound" | "track">(
    cameraMode === "interior" || cameraMode === "engine" ? "exterior" : "exterior"
  );
  const studioActive =
    active === "color" || active === "wheels" || active === "atmosphere" || active === "sound" || active === "track";
  const [soon, setSoon] = useState<string | null>(null);

  /** Mobile-only legibility shell for the bottom studio panels */
  const studioShell =
    "max-sm:rounded-2xl max-sm:border max-sm:border-white/5 max-sm:bg-[#050608]/55 max-sm:px-3 max-sm:py-3 max-sm:backdrop-blur-md";

  const handleControl = (c: ControlDef) => {
    if (c.soon) {
      setSoon(c.id);
      window.setTimeout(() => setSoon((s) => (s === c.id ? null : s)), 2600);
      return;
    }
    setSoon(null);
    if (c.id === "color" || c.id === "wheels" || c.id === "atmosphere" || c.id === "sound" || c.id === "track") {
      setActive(c.id);
      setCameraMode("exterior"); // keep exterior 3D behind the studio
    } else {
      setActive(c.id as CarioCameraMode);
      setCameraMode(c.id as CarioCameraMode);
    }
  };

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant={atmosphere.backdrop} grain={grain} />

      {/* 3D viewport — crossfades between scenes */}
      <div className="absolute inset-0">
        <AnimatePresence mode="wait">
          {(active === "exterior" || active === "color" || active === "wheels" || active === "atmosphere" || active === "sound" || active === "track") && (
            <motion.div
              key="exterior"
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <CarViewer3D
                vehicle={vehicle}
                color={color}
                rimStyle={rimStyleId}
                rimFinish={rimFinishId}
                cameraPosition={[3.8, 1.15, 4.2]}
                cameraTarget={[0, 0.62, 0]}
                autoRotate={false}
                enableZoom
                polarRange={[0.3, Math.PI / 2 - 0.04]}
                quality="balanced"
                atmosphere={atmosphere}
              />
            </motion.div>
          )}
          {active === "interior" && (
            <motion.div
              key="interior"
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <InteriorScene vehicle={vehicle} atmosphere={atmosphere} />
            </motion.div>
          )}
          {active === "engine" && (
            <motion.div
              key="engine"
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <EngineScene vehicle={vehicle} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Edge fades — blend the 3D canvas with the UI */}
      <div className="cario-edge-fade-bottom" />
      <div className="cario-edge-fade-top" />

      {/* Top-left: back + vehicle tag */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between px-6 py-6 sm:px-10 sm:py-8">
        <div className="pointer-events-auto flex flex-col gap-4">
          <CornerReturn label="Back to garage" onClick={() => setView("home")} />
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-3">
              <VehicleTag vehicle={vehicle} />
              <button
                type="button"
                onClick={() => {
                  const adding = !useCario.getState().favoriteIds.includes(selectedId);
                  toggleFavorite(selectedId);
                  pushToast(
                    adding
                      ? `${vehicle.model} saved to My Garage`
                      : `${vehicle.model} removed from My Garage`,
                    "heart"
                  );
                }}
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded-full border transition-all",
                  isFavorited
                    ? "border-white/30 bg-white/10 text-cario-white"
                    : "border-white/10 text-cario-soft-gray hover:border-white/20 hover:text-cario-white"
                )}
                aria-label={isFavorited ? "Remove from favorites" : "Add to favorites"}
                title={isFavorited ? "In your garage" : "Add to garage"}
              >
                <Heart className={cn("h-3.5 w-3.5", isFavorited && "fill-current")} />
              </button>
              <ShareSpecCard vehicle={vehicle} />
              <SpecRadarChart vehicle={vehicle} />
              <PhotoStudio vehicle={vehicle} color={color} atmosphere={atmosphere} />
            </div>
            <h1 className="font-display text-2xl font-light tracking-tight-2 text-cario-white sm:text-3xl">
              {vehicle.model}
            </h1>
            <p className="max-w-sm text-[12px] italic text-cario-soft-gray">
              {vehicle.tagline}
            </p>
          </div>
        </div>

        {/* Top-right: current mode badge + atmosphere indicator */}
        <div className="pointer-events-none hidden flex-col items-end gap-1.5 sm:flex">
          <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
            Now viewing
          </span>
          <span className="font-display text-sm font-medium uppercase tracking-wider-2 text-cario-white">
            {CONTROLS.find((c) => c.id === active)?.label}
          </span>
          {/* Atmosphere indicator — shown when atmosphere is active */}
          {active === "atmosphere" && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="mt-1 flex items-center gap-2"
            >
              <span
                className="h-2 w-2 rounded-full"
                style={{ background: atmosphere.keyColor, boxShadow: `0 0 6px ${atmosphere.keyColor}` }}
              />
              <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
                {atmosphere.name} · {atmosphere.hint}
              </span>
            </motion.div>
          )}
        </div>
      </div>

      {/* Right-side vertical control group */}
      <div className="absolute right-4 top-1/2 z-20 -translate-y-1/2 sm:right-8">
        <div className="flex flex-col items-end gap-1">
          {CONTROLS.map((c) => {
            const isActive = !c.soon && c.id === active;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => handleControl(c)}
                className={cn(
                  "group relative flex items-center gap-3 py-2.5 pl-10 pr-3 text-right transition-colors",
                  isActive ? "text-cario-white" : c.soon ? "text-cario-soft-gray/50" : "text-cario-soft-gray hover:text-cario-light-gray"
                )}
              >
                {/* Right edge accent on active */}
                <span
                  className={cn(
                    "absolute right-0 top-1/2 h-6 w-px -translate-y-1/2 bg-cario-white transition-all duration-300",
                    isActive ? "opacity-100" : "opacity-0"
                  )}
                />
                <span className="flex flex-col items-end">
                  <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                    {c.index}
                  </span>
                  <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
                    {c.label}
                  </span>
                  {c.soon && (
                    <span className="mt-0.5 font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                      Coming soon
                    </span>
                  )}
                </span>
                {/* Hover underline */}
                {!c.soon && (
                  <span className="absolute bottom-1 right-0 h-px w-0 bg-cario-white/40 transition-all duration-300 group-hover:w-6" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom-left: metadata. On mobile a center studio panel (color /
          atmosphere / sound / track) needs the full width, so the metadata
          fades out while a studio is open — desktop keeps both. */}
      <div
        className={cn(
          "pointer-events-none absolute bottom-8 left-6 z-20 transition-opacity duration-500 sm:bottom-10 sm:left-10",
          studioActive && "opacity-0 sm:opacity-100"
        )}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.4 }}
            className="flex flex-col gap-4"
          >
            <ModeMeta vehicle={vehicle} mode={active} verbose={verbose} />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom-center: Color Studio / Atmosphere Studio (mode-dependent).
          On mobile the panel gets a legibility shell so the right-hand
          control rail doesn't show through. */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex justify-center pb-8 sm:pb-10">
        <AnimatePresence mode="wait">
          {active === "color" && (
            <motion.div key="color-studio" className={cn("pointer-events-auto", studioShell)} exit={{ opacity: 0, y: 12 }}>
              <ColorStudio vehicle={vehicle} />
            </motion.div>
          )}
          {active === "wheels" && (
            <motion.div key="wheel-studio" className={cn("pointer-events-auto", studioShell)} exit={{ opacity: 0, y: 12 }}>
              <WheelStudio vehicle={vehicle} />
            </motion.div>
          )}
          {active === "atmosphere" && (
            <motion.div key="atmosphere-studio" className={cn("pointer-events-auto", studioShell)} exit={{ opacity: 0, y: 12 }}>
              <AtmosphereStudio />
            </motion.div>
          )}
          {active === "sound" && (
            <motion.div key="sound-studio" className={cn("pointer-events-auto", studioShell)} exit={{ opacity: 0, y: 12 }}>
              <SoundStudio vehicle={vehicle} />
            </motion.div>
          )}
          {active === "track" && (
            <motion.div key="track-studio" className={cn("pointer-events-auto", studioShell)} exit={{ opacity: 0, y: 12 }}>
              <TrackStudio vehicle={vehicle} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Coming soon subtle toast */}
      <AnimatePresence>
        {soon && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.4 }}
            className="absolute bottom-28 left-1/2 z-30 -translate-x-1/2 sm:bottom-32"
          >
            <div className="flex items-center gap-3 rounded-full border border-white/10 bg-black/50 px-5 py-2.5 backdrop-blur-md">
              <span className="h-1.5 w-1.5 animate-cario-pulse-soft rounded-full bg-cario-light-gray" />
              <span className="font-mono text-[10px] uppercase tracking-label text-cario-light-gray">
                {CONTROLS.find((c) => c.id === soon)?.label} — coming soon
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* Mode-specific metadata shown bottom-left */
function ModeMeta({
  vehicle,
  mode,
  verbose,
}: {
  vehicle: ReturnType<typeof getVehicle> & object;
  mode: CarioCameraMode | "color" | "wheels" | "atmosphere" | "sound" | "track";
  verbose: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  if (!vehicle) return null;
  if (mode === "exterior" || mode === "color" || mode === "wheels" || mode === "atmosphere" || mode === "sound" || mode === "track") {
    const items = [
      { label: "Power", value: `${vehicle.spec.horsepower}`, unit: "HP" },
      { label: "0–100", value: `${vehicle.spec.acceleration}`, unit: "s" },
      { label: "Top", value: `${vehicle.spec.topSpeed}`, unit: "km/h" },
    ];
    if (verbose && vehicle.spec.weight) items.push({ label: "Weight", value: `${vehicle.spec.weight}`, unit: "kg" });
    if (verbose && vehicle.spec.drivetrain) items.push({ label: "Drive", value: vehicle.spec.drivetrain, unit: "" });

    // Computed advanced metrics
    const advanced: { label: string; value: string; unit: string }[] = [];
    if (vehicle.spec.weight) {
      const ptw = (vehicle.spec.horsepower / vehicle.spec.weight * 1000).toFixed(0);
      advanced.push({ label: "Power-to-weight", value: ptw, unit: "HP/t" });
    }
    if (vehicle.spec.engine) {
      const cylMatch = vehicle.spec.engine.match(/(\d+(?:\.\d+)?)L/i);
      if (cylMatch) {
        const displacement = parseFloat(cylMatch[1]);
        const specificOutput = (vehicle.spec.horsepower / displacement).toFixed(0);
        advanced.push({ label: "Specific output", value: specificOutput, unit: "HP/L" });
      }
    }
    advanced.push({ label: "Power/weight ratio", value: (vehicle.spec.horsepower / (vehicle.spec.weight ?? 1500)).toFixed(2), unit: "HP/kg" });
    if (vehicle.spec.topSpeed && vehicle.spec.acceleration) {
      // Rough 1/4 mile estimate: 0-100 time * ~4.5 factor
      const quarterMile = (vehicle.spec.acceleration * 4.5).toFixed(1);
      advanced.push({ label: "Est. 1/4 mile", value: quarterMile, unit: "s" });
    }

    return (
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
            {mode === "atmosphere"
              ? "Atmosphere · Environment"
              : mode === "wheels"
              ? "Exterior · Wheel Atelier"
              : mode === "sound"
              ? `Sound · ${vehicle.spec.engine ?? "Powertrain"}`
              : mode === "track"
              ? "Track · Telemetry"
              : `Exterior · ${vehicle.spec.engine ?? "Powertrain"}`}
          </span>
          {mode === "atmosphere" && (
            <p className="max-w-xs text-[12px] italic leading-relaxed text-cario-soft-gray">
              {vehicle.history}
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-3">
          {items.map((it) => (
            <div key={it.label} className="flex flex-col gap-0.5">
              <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
                {it.label}
              </span>
              <span className="flex items-baseline gap-1">
                <span className="font-display text-lg font-light tabular-nums text-cario-white">
                  {it.value}
                </span>
                {it.unit && (
                  <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                    {it.unit}
                  </span>
                )}
              </span>
            </div>
          ))}
        </div>

        {/* Expandable advanced metrics */}
        <button
          type="button"
          onClick={() => setExpanded((e) => !e)}
          className="flex w-fit items-center gap-1.5 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60 transition-colors hover:text-cario-light-gray"
        >
          <span>{expanded ? "Hide" : "Show"} advanced metrics</span>
          <span className={cn("transition-transform", expanded && "rotate-180")}>▾</span>
        </button>
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden"
            >
              <div className="flex flex-wrap gap-x-6 gap-y-3 border-l border-white/10 pl-4">
                {advanced.map((it) => (
                  <div key={it.label} className="flex flex-col gap-0.5">
                    <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                      {it.label}
                    </span>
                    <span className="flex items-baseline gap-1">
                      <span className="font-display text-sm font-light tabular-nums text-cario-light-gray">
                        {it.value}
                      </span>
                      {it.unit && (
                        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                          {it.unit}
                        </span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Generation timeline — compact horizontal */}
        {vehicle.generationTimeline.length > 0 && (
          <div className="mt-2 flex flex-col gap-2">
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
              Generation Timeline
            </span>
            <div className="flex flex-col gap-1.5">
              {vehicle.generationTimeline.map((g, i) => (
                <div key={g.code} className="flex items-center gap-3">
                  <span className="font-mono text-[10px] tabular-nums text-cario-light-gray">
                    {g.code}
                  </span>
                  <span className="h-px w-3 bg-cario-soft-gray/30" />
                  <span className="font-mono text-[9px] text-cario-soft-gray">
                    {g.years}
                  </span>
                  <span className="h-px flex-1 bg-cario-soft-gray/10" />
                  <span className="max-w-[12rem] truncate text-[10px] text-cario-soft-gray/70">
                    {g.note}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }
  if (mode === "interior") {
    return (
      <div className="flex max-w-xs flex-col gap-2">
        <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
          Interior · Cockpit
        </span>
        <p className="text-[13px] leading-relaxed text-cario-light-gray">
          A basic interior cutaway for the prototype. Ambient lighting, infotainment, and
          detailed materials will arrive with the Level-2 interior asset.
        </p>
      </div>
    );
  }
  return (
    <div className="flex max-w-xs flex-col gap-2">
      <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
        Engine · {vehicle.spec.engine ?? "Powertrain"}
      </span>
      <p className="text-[13px] leading-relaxed text-cario-light-gray">
        A basic engine cutaway — the mechanical heart of the {vehicle.model}. Component-level
        detail arrives with the Level-2 engine asset.
      </p>
    </div>
  );
}
