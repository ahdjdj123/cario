"use client";

import { useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { useCario } from "@/lib/cario/store";
import { useKeyboardShortcuts } from "@/lib/cario/useKeyboardShortcuts";
import { getVehicle } from "@/lib/vehicles";
import { getAtmosphere } from "@/lib/vehicles/atmosphere";
import { CarioIntro } from "./CarioIntro";
import { CarioHome } from "./CarioHome";
import { CarioExplore } from "./CarioExplore";
import { CarioRandom } from "./CarioRandom";
import { CarioIdentify } from "./CarioIdentify";
import { CarioCarExperience } from "./CarioCarExperience";
import { CarioCompare } from "./CarioCompare";
import { CarioFavorites } from "./CarioFavorites";
import { CarioStats } from "./CarioStats";
import { CarioAchievements } from "./CarioAchievements";
import { AchievementWatcher } from "./AchievementWatcher";
import { ShortcutsHelp } from "./ShortcutsHelp";
import { SettingsTrigger } from "./Settings";
import { CarioToasts } from "./CarioToasts";

/* ============================================================
   CarioShell — the single application shell
   ------------------------------------------------------------
   The whole experience lives on one route. The shell switches
   between views using the Zustand store, with smooth crossfade
   transitions via AnimatePresence. A small Settings icon sits in
   the top-right corner on every screen except the intro.

   The shell uses a definite `h-screen` so every view's
   `h-full`/`inset-0` resolves to the full viewport — this is
   required for the 3D canvas (R3F ResizeObserver) and the
   bottom-anchored controls to position correctly.

   Global keyboard shortcuts (Esc/back, 1-4 for home actions)
   are registered here.
   ============================================================ */

export function CarioShell() {
  const view = useCario((s) => s.view);
  const selectedId = useCario((s) => s.selectedVehicleId);
  // Atmosphere key colour for the breadcrumb dot — only subscribed while
  // the experience view is showing, so mood switches never re-render
  // the shell on other screens.
  const atmosphereKey = useCario((s) =>
    s.view === "experience" ? getAtmosphere(s.atmosphereId).keyColor : null
  );
  useKeyboardShortcuts();

  /* Deep links: /?car=<vehicle-id> opens that car's experience directly
     (used by shared spec cards). The URL is then kept in sync with the
     selected car so refresh/back-forward works with the single route. */
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const carId = params.get("car");
    let toastUnsub: (() => void) | undefined;
    if (carId && getVehicle(carId)) {
      useCario.getState().selectVehicleDeepLink(carId);
    } else if (carId) {
      // A shared link can point at a vehicle that no longer exists (renamed
      // id, typo, old build). Explain the fallback instead of failing silently.
      // The toast layer only renders once the intro is gone, so if the intro
      // is still playing, defer the toast until the first non-intro view.
      let shown = false;
      const showToast = () => {
        if (shown) return;
        shown = true;
        toastUnsub?.();
        toastUnsub = undefined;
        useCario
          .getState()
          .pushToast("Link pointed to an unknown car — showing the garage", "info");
      };
      if (useCario.getState().view !== "intro") {
        showToast();
      } else {
        toastUnsub = useCario.subscribe((s) => {
          if (s.view !== "intro") showToast();
        });
      }
    }
    const syncUrl = (id: string) => {
      const url = new URL(window.location.href);
      url.searchParams.set("car", id);
      window.history.replaceState(null, "", `${url.pathname}?${url.searchParams.toString()}`);
    };
    syncUrl(useCario.getState().selectedVehicleId);
    const urlUnsub = useCario.subscribe((s) => syncUrl(s.selectedVehicleId));
    return () => {
      urlUnsub();
      toastUnsub?.();
    };
  }, []);

  // Breadcrumb label for the current view
  const viewLabels: Record<string, string> = {
    home: "Garage",
    explore: "Explore",
    random: "Random",
    identify: "Identify",
    experience: "Experience",
    compare: "Compare",
    favorites: "My Garage",
    stats: "Collection",
    achievements: "Milestones",
  };
  const breadcrumb = view !== "intro" ? viewLabels[view] ?? view : "";

  return (
    <main className="cario-grain relative h-screen w-full overflow-hidden bg-[#08090B]">
      <AnimatePresence mode="wait">
        {view === "intro" && <CarioIntro key="intro" />}
        {view === "home" && <CarioHome key="home" />}
        {view === "explore" && <CarioExplore key="explore" />}
        {view === "random" && <CarioRandom key="random" />}
        {view === "identify" && <CarioIdentify key="identify" />}
        {view === "experience" && <CarioCarExperience key="experience" />}
        {view === "compare" && <CarioCompare key="compare" />}
        {view === "favorites" && <CarioFavorites key="favorites" />}
        {view === "stats" && <CarioStats key="stats" />}
        {view === "achievements" && <CarioAchievements key="achievements" />}
      </AnimatePresence>

      {/* Milestone unlock detector (toast delivery for new achievements) */}
      <AchievementWatcher />

      {/* Breadcrumb — top-center, very subtle. A faint backdrop pill keeps
          the label legible when scrollable content passes beneath it. */}
      {view !== "intro" && view !== "home" && (
        <div className="pointer-events-none absolute left-1/2 top-4 z-40 -translate-x-1/2 sm:top-6">
          <div className="flex items-center gap-2 rounded-full border border-white/5 bg-[#050608]/55 px-4 py-1.5 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/40 backdrop-blur-md">
            <span>CARIO</span>
            <span className="h-3 w-px bg-cario-soft-gray/20" />
            <span className="text-cario-soft-gray/70">{breadcrumb}</span>
            {view === "experience" && selectedId && (
              <>
                <span className="h-3 w-px bg-cario-soft-gray/20" />
                <span className="flex items-center gap-1.5">
                  {atmosphereKey && (
                    <span
                      aria-hidden
                      className="h-1.5 w-1.5 rounded-full"
                      style={{
                        background: atmosphereKey,
                        boxShadow: `0 0 6px ${atmosphereKey}`,
                      }}
                    />
                  )}
                  <span className="text-cario-light-gray/60">
                    {selectedId.split("-").slice(0, 2).join(" ")}
                  </span>
                </span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Settings — small secondary icon, top-right */}
      {view !== "intro" && (
        <div className="pointer-events-auto absolute right-4 top-4 z-50 sm:right-6 sm:top-6">
          <SettingsTrigger />
        </div>
      )}

      {/* Keyboard hint — bottom-right, very subtle */}
      {view !== "intro" && (
        <div className="pointer-events-none absolute bottom-3 right-4 z-30 hidden sm:block">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/30">
            Esc · back
            {view === "home" && " · 1-5 navigate"}
            {" · ? help"}
          </span>
        </div>
      )}

      {/* Keyboard shortcuts help overlay (triggered by ?) */}
      {view !== "intro" && <ShortcutsHelp />}

      {/* Global transient feedback (garage saves, personal bests, copies) */}
      {view !== "intro" && <CarioToasts />}
    </main>
  );
}

