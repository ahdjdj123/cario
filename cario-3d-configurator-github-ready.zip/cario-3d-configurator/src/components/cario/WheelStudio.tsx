"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Camera, X } from "lucide-react";
import { useActiveRim, useCario } from "@/lib/cario/store";
import { RIM_FINISHES, RIM_STYLES } from "@/lib/vehicles/rims";
import type { RimFinish, RimStyle } from "@/lib/vehicles/rims";
import type { Vehicle } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   WheelStudio — compact rim style + finish selector
   ------------------------------------------------------------
   The second customization dimension (next to paint). Style
   chips are CSS-drawn rim previews whose spokes re-tint to the
   currently selected finish, so the row always previews the
   combination you are about to fit. Selecting updates the 3D
   wheels instantly via the store's activeRimStyleId /
   activeRimFinishId (per vehicle).

   The HERO SHOT button opens a large preview modal: the fitted
   combination rendered at 176 px with a brake disc + caliper
   visible through the spoke gaps, slowly rotating like a
   showroom display turntable.
   ============================================================ */

export function WheelStudio({ vehicle }: { vehicle: Vehicle }) {
  const { styleId, finishId } = useActiveRim(vehicle);
  const setRimStyle = useCario((s) => s.setRimStyle);
  const setRimFinish = useCario((s) => s.setRimFinish);
  const reduceMotion = useCario((s) => s.settings.reduceMotion);
  const [heroOpen, setHeroOpen] = useState(false);

  const style = RIM_STYLES.find((s) => s.id === styleId) ?? RIM_STYLES[0];
  const finish = RIM_FINISHES.find((f) => f.id === finishId) ?? RIM_FINISHES[0];

  /* Esc closes the hero shot — capture phase + stopPropagation so
     the shell's shortcut handler (which yields on data-cario-overlay
     scrims) and any other listeners stay out of the way. */
  useEffect(() => {
    if (!heroOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      e.preventDefault();
      e.stopPropagation();
      setHeroOpen(false);
    };
    window.addEventListener("keydown", handler, true);
    return () => window.removeEventListener("keydown", handler, true);
  }, [heroOpen]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-3"
    >
      {/* Micro-label */}
      <span className="font-mono text-[8px] uppercase tracking-mega text-cario-soft-gray/50">
        Wheel Atelier
      </span>

      {/* Style chips — previewed in the active finish */}
      <div className="flex items-center gap-2.5">
        {RIM_STYLES.map((s) => (
          <StyleChip
            key={s.id}
            style={s}
            finish={finish}
            active={s.id === style.id}
            onClick={() => setRimStyle(vehicle.id, s.id)}
          />
        ))}
      </div>

      {/* Finish dots */}
      <div className="mt-0.5 flex items-center gap-3">
        {RIM_FINISHES.map((f) => (
          <FinishDot
            key={f.id}
            finish={f}
            active={f.id === finish.id}
            onClick={() => setRimFinish(vehicle.id, f.id)}
          />
        ))}
      </div>

      {/* Active selection names */}
      <div className="flex flex-col items-center gap-0.5">
        <span className="font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
          {style.name}
        </span>
        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
          {finish.name} · forged wheels
        </span>
      </div>

      {/* Hero shot trigger — large preview of the fitted combination */}
      <button
        type="button"
        onClick={() => setHeroOpen(true)}
        className="cario-btn-premium mt-0.5 flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.04] px-3.5 py-1.5 font-mono text-[8px] uppercase tracking-label text-cario-light-gray transition-all hover:border-white/30 hover:bg-white/[0.08] hover:text-cario-white active:scale-95"
        aria-haspopup="dialog"
      >
        <Camera className="h-3 w-3" aria-hidden />
        Hero Shot
      </button>

      {/* Hero shot modal */}
      <AnimatePresence>
        {heroOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            data-cario-overlay="true"
            role="dialog"
            aria-modal="true"
            aria-label={`Hero shot — ${style.name} wheels in ${finish.name}`}
            onClick={() => setHeroOpen(false)}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-[#050608]/92 p-5 backdrop-blur-xl"
          >
            <motion.div
              initial={{ opacity: 0, y: 18, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.97 }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-sm overflow-hidden rounded-xl border border-white/10 bg-white/[0.02] px-6 pb-6 pt-7 shadow-[0_30px_80px_rgba(0,0,0,0.55)]"
            >
              {/* Close */}
              <button
                type="button"
                onClick={() => setHeroOpen(false)}
                aria-label="Close hero shot"
                className="absolute right-3.5 top-3.5 flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/25 hover:text-cario-white"
              >
                <X className="h-3.5 w-3.5" />
              </button>

              {/* Micro-label */}
              <div className="text-center">
                <span className="font-mono text-[8px] uppercase tracking-mega text-cario-soft-gray/50">
                  Wheel Atelier · Hero Shot
                </span>
              </div>

              {/* The wheel — spotlight halo behind, brake disc + caliper
                  visible through the spoke gaps, turntable rotation */}
              <div className="relative mx-auto mt-6 flex h-48 w-48 items-center justify-center">
                <span
                  aria-hidden
                  className="absolute inset-[-28px] rounded-full"
                  style={{
                    background:
                      "radial-gradient(circle, rgba(255,255,255,0.07) 0%, transparent 62%)",
                  }}
                />
                <HeroWheel style={style} finish={finish} spinning={!reduceMotion} />
              </div>

              {/* Spec captions */}
              <div className="mt-6 flex flex-col items-center gap-1 text-center">
                <span className="font-display text-xl font-light tracking-tight-2 text-cario-white">
                  {style.name}
                </span>
                <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
                  {finish.name} · forged wheels
                </span>
                <p className="mt-1.5 max-w-[34ch] font-mono text-[9px] uppercase leading-relaxed tracking-label text-cario-soft-gray/50">
                  {style.hint}
                </p>
              </div>

              <div className="mt-5 flex items-center gap-3" aria-hidden>
                <span className="h-px flex-1 bg-white/8" />
                <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                  fitted · {vehicle.brand} {vehicle.model}
                </span>
                <span className="h-px flex-1 bg-white/8" />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* Large hero preview — same CSS recipe as the chips, scaled up:
   tire carcass, rim lip, spoke face, hub, plus a static brake disc
   and caliper that show through the transparent spoke gaps while
   the wheel slowly turns like a showroom display. */
function HeroWheel({
  style,
  finish,
  spinning,
}: {
  style: RimStyle;
  finish: RimFinish;
  spinning: boolean;
}) {
  return (
    <div className="relative h-44 w-44" aria-hidden>
      {/* Brake disc — visible through the spoke gaps */}
      <span className="absolute inset-[30px] rounded-full bg-[#101114] shadow-[inset_0_0_12px_rgba(0,0,0,0.85)]" />
      {/* Drilled-disc cross pattern */}
      <span
        className="absolute inset-[30px] rounded-full opacity-60"
        style={{
          background:
            "repeating-conic-gradient(from 0deg, rgba(255,255,255,0.05) 0deg 6deg, transparent 6deg 30deg)",
        }}
      />
      {/* Caliper — parked at the two o'clock position, never rotates */}
      <span
        className="absolute left-[62%] top-[9%] h-5 w-7 rounded-[3px] shadow-[0_1px_4px_rgba(0,0,0,0.6)]"
        style={{
          background:
            "linear-gradient(160deg, #B27A38 0%, #9A6B2F 45%, #6E4A20 100%)",
          transform: "rotate(24deg)",
        }}
      />

      {/* Rotating wheel group */}
      <motion.div
        className="absolute inset-0"
        animate={spinning ? { rotate: 360 } : undefined}
        transition={spinning ? { repeat: Infinity, duration: 18, ease: "linear" } : undefined}
      >
        {/* Tire carcass */}
        <span className="absolute inset-0 rounded-full bg-[#0A0B0D] shadow-[inset_0_0_10px_rgba(255,255,255,0.07),0_10px_30px_rgba(0,0,0,0.6)]" />
        {/* Tire sidewall micro-serration */}
        <span
          className="absolute inset-[3px] rounded-full opacity-35"
          style={{
            background:
              "repeating-conic-gradient(from 0deg, rgba(255,255,255,0.09) 0deg 2deg, transparent 2deg 12deg)",
          }}
        />
        {/* Rim lip */}
        <span
          className="absolute inset-[10px] rounded-full border"
          style={{ borderColor: `${finish.hex}55` }}
        />
        {/* Spoke face — tinted by the finish */}
        <span
          className="absolute inset-[13px] rounded-full"
          style={{ background: styleFaceLayers(style, finish.hex) }}
        />
        {/* Center hub + bolt hint */}
        <span
          className="absolute inset-0 m-auto h-3 w-3 rounded-full border border-black/40"
          style={{ background: finish.hex }}
        />
      </motion.div>

      {/* Static sheen — light stays fixed while the wheel turns */}
      <span
        className="pointer-events-none absolute inset-0 rounded-full opacity-45"
        style={{
          background:
            "linear-gradient(135deg, rgba(255,255,255,0.20) 0%, transparent 44%)",
        }}
      />
    </div>
  );
}

/* CSS-drawn rim preview — spoke pattern per style, tinted by finish */
function styleFaceLayers(style: RimStyle, hex: string): string {
  const spoke = hex;
  switch (style.id) {
    case "turbine":
      // 10 Y-spokes (wider arms) + rim lip
      return [
        `radial-gradient(circle, transparent 0 62%, ${spoke} 62% 70%, transparent 70%)`,
        `repeating-conic-gradient(from 0deg, ${spoke} 0deg 13deg, transparent 13deg 36deg)`,
      ].join(", ");
    case "multi":
      // 5 twin pairs — two slim blades per 72° period
      return [
        `radial-gradient(circle, transparent 0 62%, ${spoke} 62% 70%, transparent 70%)`,
        `repeating-conic-gradient(from 6deg, ${spoke} 0deg 6deg, transparent 6deg 30deg, ${spoke} 30deg 36deg, transparent 36deg 72deg)`,
      ].join(", ");
    case "mesh":
      // 12-spoke lattice + two cross bands
      return [
        `radial-gradient(circle, transparent 0 46%, ${spoke} 46% 51%, transparent 51% 58%, ${spoke} 58% 63%, transparent 63% 70%)`,
        `repeating-conic-gradient(from 0deg, ${spoke} 0deg 10deg, transparent 10deg 30deg)`,
      ].join(", ");
    case "aero":
      // Sealed disc + 6 dark cooling slots
      return [
        `repeating-conic-gradient(from 12deg, transparent 0deg 26deg, rgba(5,6,8,0.75) 26deg 34deg, transparent 34deg 60deg)`,
        `radial-gradient(circle, ${spoke} 0 58%, ${spoke} 58% 70%, ${spoke} 70%)`,
      ].join(", ");
    case "splitter":
      // 5 wide architectural spokes
      return [
        `radial-gradient(circle, transparent 0 60%, ${spoke} 60% 70%, transparent 70%)`,
        `repeating-conic-gradient(from 0deg, ${spoke} 0deg 24deg, transparent 24deg 72deg)`,
      ].join(", ");
  }
}

function StyleChip({
  style,
  finish,
  active,
  onClick,
}: {
  style: RimStyle;
  finish: RimFinish;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={`${style.name} — ${style.hint}`}
      aria-label={`${style.name}: ${style.hint}`}
      aria-pressed={active}
      className={cn(
        "group relative h-10 w-10 rounded-full transition-transform duration-300 hover:scale-105",
        active && "scale-110"
      )}
    >
      {/* Active ring */}
      <span
        className={cn(
          "absolute -inset-1.5 rounded-full border transition-opacity duration-300",
          active ? "border-white/40 opacity-100" : "border-transparent opacity-0"
        )}
      />
      {/* Tire carcass */}
      <span className="absolute inset-0 rounded-full bg-[#0A0B0D] shadow-[inset_0_0_4px_rgba(255,255,255,0.06)]" />
      {/* Rim face — spokes tinted by the active finish */}
      <span
        className="absolute inset-[4px] rounded-full transition-[background] duration-300"
        style={{ background: styleFaceLayers(style, finish.hex) }}
      />
      {/* Center hub */}
      <span
        className="absolute inset-0 m-auto h-1.5 w-1.5 rounded-full"
        style={{ background: finish.hex }}
      />
      {/* Sheen */}
      <span
        className="pointer-events-none absolute inset-0 rounded-full opacity-50"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.22) 0%, transparent 42%)",
        }}
      />
    </button>
  );
}

function FinishDot({
  finish,
  active,
  onClick,
}: {
  finish: RimFinish;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={finish.name}
      aria-label={finish.name}
      aria-pressed={active}
      className={cn(
        "group relative h-6 w-6 rounded-full transition-transform duration-300 hover:scale-110",
        active && "scale-110"
      )}
    >
      <span
        className={cn(
          "absolute -inset-1 rounded-full border transition-opacity duration-300",
          active ? "border-white/40 opacity-100" : "border-transparent opacity-0"
        )}
      />
      <span
        className="block h-full w-full rounded-full border border-white/10 shadow-inner"
        style={{
          background: `radial-gradient(circle at 30% 25%, ${lighten(finish.hex, 0.22)} 0%, ${finish.hex} 55%, ${darken(finish.hex, 0.3)} 100%)`,
        }}
      />
      <span
        className="pointer-events-none absolute inset-0 rounded-full opacity-60"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.28) 0%, transparent 40%)",
        }}
      />
    </button>
  );
}

function lighten(hex: string, amt: number) {
  return mix(hex, "#ffffff", amt);
}
function darken(hex: string, amt: number) {
  return mix(hex, "#000000", amt);
}
function mix(a: string, b: string, t: number) {
  const pa = parse(a);
  const pb = parse(b);
  const r = Math.round(pa[0] + (pb[0] - pa[0]) * t);
  const g = Math.round(pa[1] + (pb[1] - pa[1]) * t);
  const bl = Math.round(pa[2] + (pb[2] - pa[2]) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}
function parse(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [
    parseInt(h.substring(0, 2), 16),
    parseInt(h.substring(2, 4), 16),
    parseInt(h.substring(4, 6), 16),
  ];
}
