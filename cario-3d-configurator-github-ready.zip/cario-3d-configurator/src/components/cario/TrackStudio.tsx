"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";
import { VEHICLES } from "@/lib/vehicles";
import { useCario } from "@/lib/cario/store";
import {
  CIRCUITS,
  compilePath,
  curvatureAt,
  getCircuit,
  pointAt,
  type Circuit,
  type CompiledPath,
} from "@/lib/cario/circuits";
import { cn } from "@/lib/utils";

/* ============================================================
   TrackStudio — track-day telemetry over real-inspired layouts
   ------------------------------------------------------------
   A stylized top-down telemetry view with four selectable
   circuits (CARIO Loop, Monza, Suzuka — including its famous
   figure-eight crossover — and the Nürburgring). The car dot
   follows each circuit's true outline using arc-length
   parameterization and slows through tight corners based on
   local curvature.

   Lap timing uses the car's performance specs, and personal
   bests are persisted per car per circuit in the store.
   ============================================================ */

export function TrackStudio({ vehicle }: { vehicle: Vehicle }) {
  const [circuitId, setCircuitId] = useState(CIRCUITS[0].id);
  const circuit = getCircuit(circuitId);
  const compiled = useMemo(() => compilePath(circuit.path), [circuit]);

  const [playing, setPlaying] = useState(false);
  const [lap, setLap] = useState(1);
  const [speed, setSpeed] = useState(0);
  const [currentLapTime, setCurrentLapTime] = useState(0);
  const [sessionBest, setSessionBest] = useState<number | null>(null);
  const [simSpeed, setSimSpeed] = useState<1 | 4 | 8>(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);
  const progressRef = useRef(0); // 0..1 around the track
  const playingRef = useRef(playing);
  const sessionBestRef = useRef<number | null>(null);
  /** Simulated session clock in ms — advances by dt × simSpeed while playing */
  const simTimeRef = useRef(0);
  /** Sim clock reading at the start of the current lap */
  const lapStartSimRef = useRef(0);
  /** Mirrors simSpeed for the animation loop */
  const simSpeedRef = useRef<1 | 4 | 8>(simSpeed);

  const recordBestLap = useCario((s) => s.recordBestLap);
  const pushToast = useCario((s) => s.pushToast);
  const clearBestLaps = useCario((s) => s.clearBestLaps);
  /** Two-step confirm for the leaderboard reset */
  const [confirmReset, setConfirmReset] = useState(false);
  const confirmTimerRef = useRef<number | null>(null);
  const handleResetRecords = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      if (confirmTimerRef.current) window.clearTimeout(confirmTimerRef.current);
      confirmTimerRef.current = window.setTimeout(() => setConfirmReset(false), 3000);
      return;
    }
    if (confirmTimerRef.current) window.clearTimeout(confirmTimerRef.current);
    setConfirmReset(false);
    clearBestLaps();
    setSessionBest(null);
    sessionBestRef.current = null;
    pushToast("Racing records cleared", "timer");
  };
  const pbKey = `${vehicle.id}:${circuit.id}`;
  const pb = useCario((s) => s.bestLaps[pbKey]);
  // Whole bestLaps record — identity is stable unless a PB changes, so
  // this only re-renders the board when a lap is actually recorded.
  const bestLaps = useCario((s) => s.bestLaps);

  // Leaderboard rows: this car's PB + the course record (fastest PB set
  // by ANY car) per circuit. Rows are clickable → switch circuit.
  const board = useMemo(() => {
    return CIRCUITS.map((c) => {
      const carPb = bestLaps[`${vehicle.id}:${c.id}`];
      let rec: { time: number; model: string } | null = null;
      for (const [key, time] of Object.entries(bestLaps)) {
        const sep = key.lastIndexOf(":");
        if (key.slice(sep + 1) !== c.id) continue;
        if (rec === null || time < rec.time) {
          const vid = key.slice(0, sep);
          rec = {
            time,
            model: VEHICLES.find((v) => v.id === vid)?.model ?? vid,
          };
        }
      }
      return { circuit: c, carPb, rec };
    });
  }, [bestLaps, vehicle.id]);
  const pbsHeld = board.filter((r) => r.carPb !== undefined).length;

  // Keep refs in sync with state (in effects, not during render)
  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);
  useEffect(() => {
    simSpeedRef.current = simSpeed;
  }, [simSpeed]);

  // Estimated lap time for the current car + circuit
  const estimatedLapTime = useMemo(
    () => estimateLapTime(vehicle, circuit),
    [vehicle, circuit]
  );

  // Switching circuits resets session timing (event-handler reset — no effect needed)
  const selectCircuit = (id: string) => {
    setCircuitId(id);
    setLap(1);
    setSpeed(0);
    setCurrentLapTime(0);
    sessionBestRef.current = null;
    setSessionBest(null);
    progressRef.current = 0;
    simTimeRef.current = 0;
    lapStartSimRef.current = 0;
  };

  // Animation loop
  useEffect(() => {
    let last = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;

      if (playingRef.current) {
        // Sim clock advances faster than real time when speed is compressed
        const simDt = dt * simSpeedRef.current;
        simTimeRef.current += simDt * 1000;

        // Advance progress around the track
        const lapFraction = simDt / estimatedLapTime;
        progressRef.current += lapFraction;
        if (progressRef.current >= 1) {
          // Lap completed — the lap time is in simulated seconds, so
          // personal bests stay comparable across sim speeds
          const lapTime = simTimeRef.current - lapStartSimRef.current;
          if (sessionBestRef.current === null || lapTime < sessionBestRef.current) {
            sessionBestRef.current = lapTime;
            setSessionBest(lapTime);
          }
          const prevPb = useCario.getState().bestLaps[pbKey];
          recordBestLap(pbKey, lapTime);
          if (prevPb === undefined || lapTime < prevPb) {
            pushToast(`New personal best · ${formatTime(lapTime)}`, "timer");
          }
          setLap((l) => l + 1);
          progressRef.current = progressRef.current - 1;
          lapStartSimRef.current = simTimeRef.current;
          setCurrentLapTime(0);
        } else {
          setCurrentLapTime(simTimeRef.current - lapStartSimRef.current);
        }
        // Speed varies with local curvature — slow in tight corners
        const tight = curvatureAt(circuit.path, compiled, progressRef.current, 0.02);
        const speedFactor = 1 - tight * 0.55;
        setSpeed(vehicle.spec.topSpeed * speedFactor);
      } else {
        setSpeed(0);
      }

      drawTrack(canvasRef.current, progressRef.current, circuit, compiled);
      animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [circuit, compiled, estimatedLapTime, vehicle, recordBestLap, pushToast, pbKey]);

  const handlePlay = () => {
    if (!playing) {
      // Start the clock from the current sim position (0 unless resuming)
      lapStartSimRef.current = simTimeRef.current;
      setCurrentLapTime(simTimeRef.current - lapStartSimRef.current);
    }
    setPlaying((p) => !p);
  };

  const handleReset = () => {
    setPlaying(false);
    setLap(1);
    setSpeed(0);
    setCurrentLapTime(0);
    sessionBestRef.current = null;
    setSessionBest(null);
    progressRef.current = 0;
    simTimeRef.current = 0;
    lapStartSimRef.current = 0;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-4"
    >
      {/* Circuit + sim-speed selectors */}
      <div className="flex flex-col items-center gap-1.5">
        <div className="flex items-center gap-1.5">
          {CIRCUITS.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => selectCircuit(c.id)}
              className={cn(
                "rounded-full border px-3 py-1.5 font-mono text-[9px] uppercase tracking-label transition-all duration-300 active:scale-[0.96]",
                c.id === circuitId
                  ? "border-white/30 bg-white/10 text-cario-white"
                  : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
              )}
              title={`${c.country} · ${c.lengthKm} km`}
            >
              {c.name}
            </button>
          ))}
        </div>
        {/* Time compression — lap clocks run in sim time, so personal
            bests stay comparable across speeds */}
        <div className="flex items-center gap-2">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
            Sim
          </span>
          {([1, 4, 8] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSimSpeed(s)}
              aria-pressed={simSpeed === s}
              className={cn(
                "rounded-full border px-2.5 py-0.5 font-mono text-[9px] tabular-nums transition-all duration-300 active:scale-[0.96]",
                simSpeed === s
                  ? "border-white/30 bg-white/10 text-cario-white"
                  : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
              )}
              title={`Run ${s}× faster — lap times are unaffected (sim time)`}
            >
              {s}×
            </button>
          ))}
        </div>
      </div>

      {/* Track canvas */}
      <div className="relative w-[320px] max-w-[80vw]">
        <canvas
          ref={canvasRef}
          width={320}
          height={160}
          className="w-full rounded-md border border-white/8 bg-black/40"
        />
        {/* Lap counter overlay */}
        <div className="absolute left-3 top-2 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Lap
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {lap}
          </span>
        </div>
        {/* Speed overlay */}
        <div className="absolute right-3 top-2 flex flex-col items-end gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Speed
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {Math.round(speed)}
            <span className="ml-0.5 font-mono text-[8px] text-cario-soft-gray">km/h</span>
          </span>
        </div>
        {/* Current lap time */}
        <div className="absolute bottom-2 left-3 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            Time
          </span>
          <span className="font-display text-xs font-light tabular-nums text-cario-light-gray">
            {formatTime(currentLapTime)}
          </span>
        </div>
        {/* Best lap — persisted personal best for this car + circuit */}
        <div className="absolute bottom-2 right-3 flex flex-col items-end gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            {pb !== undefined ? "Personal best" : "Best"}
          </span>
          <span className="font-display text-xs font-light tabular-nums text-cario-light-gray">
            {formatTime(pb ?? sessionBest ?? 0)}
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={handlePlay}
          className="group flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-cario-white backdrop-blur-md transition-all hover:border-white/30 hover:bg-white/[0.08] active:scale-95"
        >
          {playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
            {playing ? "Pause" : "Start lap"}
          </span>
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white active:scale-95"
          aria-label="Reset"
          title="Reset telemetry (personal best is kept)"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>

      {/* Circuit info */}
      <div className="flex flex-wrap items-center justify-center gap-3 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        <span>
          {circuit.name} · {circuit.country}
        </span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>{circuit.lengthKm} km</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>Est. {estimatedLapTime.toFixed(1)}s</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>Sim time · {simSpeed}×</span>
      </div>

      {/* Leaderboard — this car's PBs across all circuits + course records */}
      <div className="w-[320px] max-w-[80vw] overflow-hidden rounded-md border border-white/8 bg-white/[0.015]">
        <div className="flex items-center justify-between border-b border-white/6 px-3 py-2">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/70">
            Leaderboard
          </span>
          <span className="flex items-center gap-2">
            <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
              {pbsHeld} / {CIRCUITS.length} PBs held
            </span>
            {pbsHeld > 0 && (
              <button
                type="button"
                onClick={handleResetRecords}
                className={cn(
                  "rounded-full border px-2 py-0.5 font-mono text-[7px] uppercase tracking-label transition-colors",
                  confirmReset
                    ? "border-[#C25B5B]/60 text-[#D98484]"
                    : "border-white/10 text-cario-soft-gray/60 hover:border-white/25 hover:text-cario-light-gray"
                )}
                aria-label={confirmReset ? "Confirm clearing all racing records" : "Clear all racing records"}
              >
                {confirmReset ? "Confirm?" : "Reset"}
              </button>
            )}
          </span>
        </div>
        <div>
          {board.map(({ circuit: c, carPb, rec }) => {
            const active = c.id === circuitId;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => selectCircuit(c.id)}
                aria-pressed={active}
                title={`${c.country} · ${c.lengthKm} km · est. ${estimateLapTime(vehicle, c).toFixed(1)}s`}
                className={cn(
                  "flex w-full items-center justify-between gap-2 border-b border-white/5 px-3 py-2 text-left transition-colors last:border-b-0",
                  active ? "bg-white/[0.06]" : "hover:bg-white/[0.03]"
                )}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <span
                    className={cn(
                      "h-1 w-1 shrink-0 rounded-full transition-colors",
                      active ? "bg-cario-white" : "bg-cario-soft-gray/30"
                    )}
                    aria-hidden
                  />
                  <span
                    className={cn(
                      "truncate font-mono text-[9px] uppercase tracking-label",
                      active ? "text-cario-white" : "text-cario-light-gray/80"
                    )}
                  >
                    {c.name}
                  </span>
                </span>
                <span className="flex shrink-0 items-baseline gap-3">
                  <span className="flex flex-col items-end">
                    <span className="font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/40">
                      You
                    </span>
                    <span
                      className={cn(
                        "font-display text-[11px] font-light tabular-nums",
                        carPb !== undefined ? "text-cario-white" : "text-cario-soft-gray/40"
                      )}
                    >
                      {carPb !== undefined ? formatTime(carPb) : "—"}
                    </span>
                  </span>
                  <span className="flex flex-col items-end">
                    <span className="font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/40">
                      Record
                    </span>
                    <span
                      className={cn(
                        "font-display text-[11px] font-light tabular-nums",
                        rec ? "text-cario-light-gray" : "text-cario-soft-gray/40"
                      )}
                      title={rec ? `Course record · ${rec.model}` : "No record set yet"}
                    >
                      {rec ? formatTime(rec.time) : "—"}
                    </span>
                    {rec && (
                      <span className="max-w-[110px] truncate font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/45">
                        {rec.model}
                      </span>
                    )}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
        {pbsHeld > 0 && (
          <div className="border-t border-white/6 px-3 py-1.5 font-mono text-[7px] uppercase tracking-label text-cario-soft-gray/35">
            Course records · fastest personal best per circuit · any car
          </div>
        )}
      </div>
    </motion.div>
  );
}

/* --- Draw the circuit outline + car dot ----------------------------- */

function drawTrack(
  canvas: HTMLCanvasElement | null,
  progress: number,
  circuit: Circuit,
  compiled: CompiledPath
) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  // Fit the normalized path into the canvas with padding, preserving
  // the layout's aspect ratio (normalized space is square).
  const pad = 14;
  const scale = Math.min(w - pad * 2, h - pad * 2);
  const ox = (w - scale) / 2;
  const oy = (h - scale) / 2;
  const toPx = (p: [number, number]): [number, number] => [
    ox + p[0] * scale,
    oy + p[1] * scale,
  ];

  // Track outline (dark ribbon)
  ctx.strokeStyle = "rgba(243, 243, 241, 0.09)";
  ctx.lineWidth = 12;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  circuit.path.forEach((p, i) => {
    const [x, y] = toPx(p);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.closePath();
  ctx.stroke();

  // Dashed center line
  ctx.strokeStyle = "rgba(243, 243, 241, 0.13)";
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 5]);
  ctx.stroke();
  ctx.setLineDash([]);

  // Start/finish line — drawn across the track at parameter 0
  const [sx, sy] = toPx(pointAt(circuit.path, compiled, 0));
  const [nx, ny] = toPx(pointAt(circuit.path, compiled, 0.012));
  const ang = Math.atan2(ny - sy, nx - sx) + Math.PI / 2;
  ctx.strokeStyle = "rgba(243, 243, 241, 0.55)";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(sx + Math.cos(ang) * 8, sy + Math.sin(ang) * 8);
  ctx.lineTo(sx - Math.cos(ang) * 8, sy - Math.sin(ang) * 8);
  ctx.stroke();

  // Car position + trail
  const [carX, carY] = toPx(pointAt(circuit.path, compiled, progress));

  const trailSteps = 28;
  for (let i = 0; i < trailSteps; i++) {
    const p = progress - (i / trailSteps) * 0.06;
    const [tx, ty] = toPx(pointAt(circuit.path, compiled, p));
    const alpha = (1 - i / trailSteps) * 0.4;
    ctx.fillStyle = `rgba(243, 243, 241, ${alpha})`;
    ctx.beginPath();
    ctx.arc(tx, ty, 1.8, 0, Math.PI * 2);
    ctx.fill();
  }

  // Car dot — bright with glow
  const grad = ctx.createRadialGradient(carX, carY, 0, carX, carY, 11);
  grad.addColorStop(0, "rgba(243, 243, 241, 0.9)");
  grad.addColorStop(0.4, "rgba(243, 243, 241, 0.3)");
  grad.addColorStop(1, "rgba(243, 243, 241, 0)");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(carX, carY, 11, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#F3F3F1";
  ctx.beginPath();
  ctx.arc(carX, carY, 3.2, 0, Math.PI * 2);
  ctx.fill();
}

/* --- Estimate a lap time from the car's specs + circuit ------------- */
function estimateLapTime(vehicle: Vehicle, circuit: Circuit): number {
  // Heuristic: faster cars (higher power, lower 0-100) get shorter laps.
  // The circuit length + difficulty scale the result, so the
  // Nordschleife takes ~4x a Monza lap.
  const powerFactor = vehicle.spec.horsepower / 100;
  const accelFactor = vehicle.spec.acceleration * 3;
  const base = 95 - powerFactor + accelFactor;
  const loopLap = Math.max(55, Math.min(120, base));
  return Math.max(30, Math.min(300, loopLap * (circuit.lengthKm / 5.2) * circuit.difficulty));
}

/* --- Format milliseconds as M:SS.mmm -------------------------------- */
function formatTime(ms: number): string {
  if (ms <= 0) return "0:00.000";
  const totalSec = ms / 1000;
  const min = Math.floor(totalSec / 60);
  const sec = Math.floor(totalSec % 60);
  const milli = Math.floor((totalSec % 1) * 1000);
  return `${min}:${String(sec).padStart(2, "0")}.${String(milli).padStart(3, "0")}`;
}
