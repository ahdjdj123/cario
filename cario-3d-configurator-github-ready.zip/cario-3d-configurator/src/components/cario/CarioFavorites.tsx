"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Heart, ArrowRight } from "lucide-react";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn, ViewHeader } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import { getVehicle } from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioFavorites — the user's personal garage
   ------------------------------------------------------------
   Shows all vehicles the user has bookmarked as a clean
   monochrome list. Each entry shows the car name, brand/year,
   key specs, and an "Enter" button. Empty state guides the
   user to Explore to start favoriting cars.
   ============================================================ */

export function CarioFavorites() {
  const goBack = useCario((s) => s.goBack);
  const setView = useCario((s) => s.setView);
  const favoriteIds = useCario((s) => s.favoriteIds);
  const selectVehicle = useCario((s) => s.selectVehicle);
  const toggleFavorite = useCario((s) => s.toggleFavorite);
  const pushToast = useCario((s) => s.pushToast);
  const grain = useCario((s) => s.settings.grain);

  const favorites = favoriteIds
    .map((id) => getVehicle(id))
    .filter((v): v is NonNullable<typeof v> => !!v);

  const removeFavorite = (id: string, model: string) => {
    toggleFavorite(id);
    pushToast(`${model} removed from My Garage`, "heart");
  };

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" grain={grain} />

      <div className="cario-scroll absolute inset-0 overflow-y-auto">
        <div className="mx-auto min-h-full max-w-4xl px-6 py-8 sm:px-10 sm:py-10">
          {/* Header */}
          <div className="flex flex-col gap-5">
            <div className="pointer-events-auto">
              <CornerReturn label="Back" onClick={() => goBack()} />
            </div>
            <ViewHeader
              eyebrow="CARIO / 06"
              title="My Garage"
              subtitle="Your bookmarked machines."
            />
          </div>

          {/* Favorites list or empty state */}
          {favorites.length > 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="mt-8 flex flex-col gap-2"
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                  {favorites.length} {favorites.length === 1 ? "car" : "cars"} saved
                </span>
              </div>
              {favorites.map((v, i) => (
                <FavoriteRow
                  key={v.id}
                  vehicle={v}
                  index={i}
                  onEnter={() => selectVehicle(v.id)}
                  onRemove={() => removeFavorite(v.id, v.model)}
                />
              ))}
            </motion.div>
          ) : (
            <EmptyState onExplore={() => setView("explore")} />
          )}
        </div>
      </div>
    </motion.div>
  );
}

function FavoriteRow({
  vehicle,
  index,
  onEnter,
  onRemove,
}: {
  vehicle: ReturnType<typeof getVehicle> & object;
  index: number;
  onEnter: () => void;
  onRemove: () => void;
}) {
  if (!vehicle) return null;
  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: 0.2 + index * 0.06 }}
      className="group flex items-center gap-4 rounded-lg border border-white/8 bg-white/[0.02] px-5 py-4 transition-all hover:border-white/15 hover:bg-white/[0.04]"
    >
      {/* Index */}
      <span className="font-mono text-[10px] tabular-nums text-cario-soft-gray/50">
        {String(index + 1).padStart(2, "0")}
      </span>

      {/* Car info */}
      <div className="flex flex-1 flex-col gap-1">
        <div className="flex items-baseline gap-2">
          <span className="font-display text-base font-medium tracking-tight-2 text-cario-white">
            {vehicle.model}
          </span>
          <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray">
            {vehicle.brand} · {vehicle.generation} · {vehicle.year}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <SpecChip label="Power" value={`${vehicle.spec.horsepower}`} unit="HP" />
          <SpecChip label="0–100" value={`${vehicle.spec.acceleration}`} unit="s" />
          <SpecChip label="Top" value={`${vehicle.spec.topSpeed}`} unit="km/h" />
        </div>
      </div>

      {/* Tagline */}
      <span className="hidden max-w-[14rem] truncate text-[11px] italic text-cario-soft-gray lg:block">
        {vehicle.tagline}
      </span>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onEnter}
          className="flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-[10px] uppercase tracking-label text-cario-light-gray transition-all hover:border-white/25 hover:text-cario-white"
        >
          Enter
          <ArrowRight className="h-3 w-3" />
        </button>
        <button
          type="button"
          onClick={onRemove}
          className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
          aria-label="Remove from favorites"
        >
          <Heart className="h-3.5 w-3.5 fill-current" />
        </button>
      </div>
    </motion.div>
  );
}

function SpecChip({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="flex items-baseline gap-1">
      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
        {label}
      </span>
      <span className="font-display text-[12px] font-light tabular-nums text-cario-light-gray">
        {value}
      </span>
      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
        {unit}
      </span>
    </div>
  );
}

function EmptyState({ onExplore }: { onExplore: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="mt-16 flex flex-col items-center justify-center gap-5"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/[0.02]">
        <Heart className="h-6 w-6 text-cario-soft-gray" />
      </div>
      <div className="flex flex-col items-center gap-1.5 text-center">
        <span className="font-display text-sm font-medium text-cario-light-gray">
          Your garage is empty
        </span>
        <span className="max-w-xs text-[12px] leading-relaxed text-cario-soft-gray">
          Browse the collection and tap the heart icon on any car to
          save it here for quick access.
        </span>
      </div>
      <button
        type="button"
        onClick={onExplore}
        className="mt-2 flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-cario-white backdrop-blur-md transition-all hover:border-white/30 hover:bg-white/[0.08]"
      >
        <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
          Explore collection
        </span>
        <ArrowRight className="h-3.5 w-3.5" />
      </button>
    </motion.div>
  );
}
