"use client";

import { Component, type ReactNode, Suspense } from "react";
import { Environment } from "@react-three/drei";

/* ============================================================
   CarioEnvironment — self-hosted HDR environment maps
   ------------------------------------------------------------
   drei's `Environment preset="…"` downloads HDR files from the
   pmndrs CDN (raw.githack.com) at runtime. That CDN is not
   reachable in every deployment environment, which would leave
   the 3D scene without reflections (or blank the canvas when
   the fetch rejects). CARIO therefore ships the same 1k HDR
   maps locally in /public/hdri and resolves presets itself.

   A small error boundary guarantees the scene keeps rendering
   with the manual studio lighting even if an HDR fails to load.
   ============================================================ */

const LOCAL_HDRI: Record<string, string> = {
  studio: "/hdri/studio_small_03_1k.hdr",
  city: "/hdri/potsdamer_platz_1k.hdr",
  dawn: "/hdri/kiara_1_dawn_1k.hdr",
  sunset: "/hdri/venice_sunset_1k.hdr",
  night: "/hdri/dikhololo_night_1k.hdr",
  warehouse: "/hdri/empty_warehouse_01_1k.hdr",
};

class EnvErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (this.state.failed) return null;
    return this.props.children;
  }
}

export function CarioEnvironment({
  preset,
}: {
  preset:
    | "studio"
    | "city"
    | "sunset"
    | "dawn"
    | "night"
    | "warehouse"
    | "park"
    | "lobby"
    | "apartment"
    | string;
}) {
  const file = LOCAL_HDRI[preset] ?? LOCAL_HDRI.studio;
  return (
    <EnvErrorBoundary>
      <Suspense fallback={null}>
        <Environment files={file} />
      </Suspense>
    </EnvErrorBoundary>
  );
}
