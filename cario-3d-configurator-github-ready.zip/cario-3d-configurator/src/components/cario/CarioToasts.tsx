"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Heart, Timer, Trophy } from "lucide-react";
import { useCario, type ToastKind } from "@/lib/cario/store";

/* ============================================================
   CarioToasts — transient, monochrome feedback pills
   ------------------------------------------------------------
   Rendered globally by the shell, top-center just below the
   breadcrumb. Each toast auto-dismisses after ~2.8s. Kinds map
   to a small icon: heart (garage), timer (personal best),
   copy (clipboard), info (generic).
   ============================================================ */

const AUTO_DISMISS_MS = 2800;

const KIND_ICON: Record<ToastKind, React.ReactNode> = {
  heart: <Heart className="h-3 w-3 fill-current" />,
  timer: <Timer className="h-3 w-3" />,
  copy: <Copy className="h-3 w-3" />,
  info: <Check className="h-3 w-3" />,
  trophy: <Trophy className="h-3 w-3" />,
};

function ToastPill({ id, message, kind }: { id: number; message: string; kind: ToastKind }) {
  const dismissToast = useCario((s) => s.dismissToast);

  useEffect(() => {
    const t = window.setTimeout(() => dismissToast(id), AUTO_DISMISS_MS);
    return () => window.clearTimeout(t);
  }, [id, dismissToast]);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -14, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10, scale: 0.97 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={
        kind === "trophy"
          ? "pointer-events-auto relative flex items-center gap-2.5 overflow-hidden rounded-full border border-white/30 bg-[#0A0B0D]/90 px-4 py-2 shadow-[0_8px_30px_rgba(0,0,0,0.45),0_0_18px_rgba(255,255,255,0.07)] backdrop-blur-md"
          : "pointer-events-auto relative flex items-center gap-2.5 overflow-hidden rounded-full border border-white/10 bg-[#0A0B0D]/85 px-4 py-2 shadow-[0_8px_30px_rgba(0,0,0,0.45)] backdrop-blur-md"
      }
      role="status"
    >
      <span className={kind === "trophy" ? "text-cario-white" : "text-cario-white/80"}>
        {KIND_ICON[kind]}
      </span>
      <span className="whitespace-nowrap font-mono text-[10px] uppercase tracking-label text-cario-light-gray">
        {message}
      </span>
      {/* Lifetime drain bar — mirrors the 2.8 s auto-dismiss so the
          feedback feels mechanical rather than arbitrary */}
      <span
        aria-hidden
        className="absolute bottom-0 left-3 right-3 h-px origin-left bg-white/25"
        style={{ animation: `cario-toast-drain ${AUTO_DISMISS_MS}ms linear both` }}
      />
    </motion.div>
  );
}

export function CarioToasts() {
  const toasts = useCario((s) => s.toasts);

  return (
    <div
      className="pointer-events-none absolute left-1/2 top-14 z-[70] flex -translate-x-1/2 flex-col items-center gap-1.5 sm:top-16"
      aria-live="polite"
    >
      <AnimatePresence initial={false}>
        {toasts.map((t) => (
          <ToastPill key={t.id} id={t.id} message={t.message} kind={t.kind} />
        ))}
      </AnimatePresence>
    </div>
  );
}
