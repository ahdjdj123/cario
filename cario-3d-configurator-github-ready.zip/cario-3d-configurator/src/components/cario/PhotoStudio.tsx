"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Camera, Download, X, Copy, Check, RefreshCw } from "lucide-react";
import type { Vehicle, VehicleColor } from "@/lib/vehicles/types";
import type { AtmospherePreset } from "@/lib/vehicles/types";
import { useCario } from "@/lib/cario/store";
import { cn } from "@/lib/utils";

/* ============================================================
   PhotoStudio — capture the live 3D scene as a framed poster
   ------------------------------------------------------------
   A camera button in the experience header. On capture it:
   1. grabs the active WebGL canvas (preserveDrawingBuffer is
      enabled on all R3F canvases so toDataURL is reliable),
   2. composes it into a monochrome "gallery poster" on an
      offscreen 1600×1000 canvas (hairline frame, corner
      ticks, CARIO wordmark, car + paint + atmosphere caption,
      spec strip, deep link),
   3. flashes the viewport like a shutter and opens a preview
      modal with Recapture / Download PNG / Copy actions.
   ============================================================ */

export function PhotoStudio({
  vehicle,
  color,
  atmosphere,
}: {
  vehicle: Vehicle;
  color: VehicleColor;
  atmosphere: AtmospherePreset;
}) {
  const [open, setOpen] = useState(false);
  const [flash, setFlash] = useState(false);
  const [posterUrl, setPosterUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pushToast = useCario((s) => s.pushToast);

  const capture = async () => {
    const src = findLiveCanvas();
    if (!src) {
      pushToast("No 3D scene to capture yet", "info");
      return;
    }
    canvasRef.current = src;
    // Shutter blink on the viewport
    setFlash(true);
    window.setTimeout(() => setFlash(false), 520);
    setCopied(false);
    try {
      // Load the brand display/mono faces before composing so the poster
      // renders in the app's own type, not a system fallback.
      const fonts = await loadPosterFonts();
      setPosterUrl(
        composePoster(src, vehicle, color, atmosphere, undefined, fonts).toDataURL(
          "image/png"
        )
      );
    } catch {
      pushToast("Capture failed — try again", "info");
    }
  };

  const handleOpen = () => {
    void capture();
    setOpen(true);
  };

  // Close on Escape — the overlay sentinel keeps the global
  // shortcut handler from navigating the view behind the modal.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open]);

  const handleDownload = () => {
    const url = posterUrl;
    if (!url) return;
    const a = document.createElement("a");
    a.href = url;
    a.download = `cario-${vehicle.id}-${color.id}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    pushToast("Poster saved to downloads", "copy");
  };

  const handleCopy = async () => {
    const src = canvasRef.current;
    if (!src) return;
    try {
      const fonts = await loadPosterFonts();
      const blob = await new Promise<Blob | null>((res) => {
        const img = new Image();
        img.onload = () => {
          // recompose at full quality for the clipboard
          const out = composePoster(src, vehicle, color, atmosphere, img, fonts);
          out.toBlob((b) => res(b), "image/png");
        };
        img.src = posterUrl ?? "";
      });
      if (!blob) throw new Error("no blob");
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      setCopied(true);
      pushToast("Poster copied · deep link included", "copy");
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      pushToast("Copy not supported here — use Download", "info");
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleOpen}
        className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white"
        aria-label="Photo studio — capture the scene"
        title="Photo studio"
      >
        <Camera className="h-3.5 w-3.5" />
      </button>

      {/* Shutter flash over the viewport */}
      <AnimatePresence>
        {flash && (
          <motion.div
            key="flash"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.85 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="cario-flash pointer-events-none fixed inset-0 z-[60] bg-white"
            aria-hidden
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
              data-cario-overlay="true"
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="cario-surface-strong fixed left-1/2 top-1/2 z-50 w-[560px] max-w-[92vw] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg"
              role="dialog"
              aria-label="Photo studio preview"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
                <div className="flex items-center gap-2">
                  <Camera className="h-4 w-4 text-cario-soft-gray" />
                  <span className="font-display text-sm font-medium uppercase tracking-wider-2 text-cario-white">
                    Photo Studio
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                  aria-label="Close photo studio"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Poster preview */}
              <div className="max-h-[52vh] overflow-y-auto cario-scroll px-5 py-5">
                {posterUrl ? (
                  <img
                    src={posterUrl}
                    alt={`${vehicle.brand} ${vehicle.model} poster capture`}
                    className="w-full rounded-md border border-white/10"
                  />
                ) : (
                  <div className="flex h-40 items-center justify-center rounded-md border border-white/10 font-mono text-[10px] uppercase tracking-label text-cario-soft-gray/50">
                    Preparing capture…
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center gap-2 border-t border-white/8 px-4 py-4 max-sm:justify-center sm:px-5">
                <button
                  type="button"
                  onClick={capture}
                  className="flex items-center justify-center gap-2 rounded-full border border-white/10 px-4 py-2.5 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white active:scale-95"
                  title="Grab a fresh frame from the live scene"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span className="whitespace-nowrap font-display text-[11px] font-medium uppercase tracking-wider-2">
                    Recapture
                  </span>
                </button>
                <button
                  type="button"
                  onClick={handleDownload}
                  disabled={!posterUrl}
                  className="flex flex-1 items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-4 py-2.5 text-cario-white transition-all hover:border-white/30 hover:bg-white/[0.08] disabled:opacity-40 active:scale-95"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span className="whitespace-nowrap font-display text-[11px] font-medium uppercase tracking-wider-2">
                    Download PNG
                  </span>
                </button>
                <button
                  type="button"
                  onClick={handleCopy}
                  disabled={!posterUrl}
                  className={cn(
                    "flex items-center justify-center gap-2 rounded-full border px-4 py-2.5 transition-all disabled:opacity-40 active:scale-95",
                    copied
                      ? "border-white/30 bg-white/10 text-cario-white"
                      : "border-white/10 text-cario-soft-gray hover:border-white/20 hover:text-cario-white"
                  )}
                  title="Copies the poster image to the clipboard"
                >
                  {copied ? (
                    <Check className="h-3.5 w-3.5 text-cario-white" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span className="whitespace-nowrap font-display text-[11px] font-medium uppercase tracking-wider-2">
                    {copied ? "Copied" : "Copy"}
                  </span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* --- Find the largest visible canvas (the active 3D scene) --- */
function findLiveCanvas(): HTMLCanvasElement | null {
  const candidates = [...document.querySelectorAll("canvas")]
    .filter((c) => c.width > 200 && c.height > 150)
    .map((c) => ({ c, area: c.width * c.height }))
    .sort((a, b) => b.area - a.area);
  return candidates[0]?.c ?? null;
}

/* --- Resolve the app's real display + mono faces for the poster -------
   next/font serves Inter/JetBrains under scoped family names, so the
   previous canvas text silently fell back to Helvetica. Probe a hidden
   element's computed font-family, then await the weights the poster
   uses. Cached — the fonts only ever load once per session. */
interface PosterFonts {
  display: string;
  mono: string;
}
let posterFontsCache: PosterFonts | null = null;

async function loadPosterFonts(): Promise<PosterFonts> {
  if (posterFontsCache) return posterFontsCache;
  const familyOf = (cls: string): string => {
    const el = document.createElement("span");
    el.className = cls;
    el.setAttribute("aria-hidden", "true");
    el.style.cssText = "position:absolute;opacity:0;pointer-events:none;";
    document.body.appendChild(el);
    const fam = getComputedStyle(el).fontFamily || "";
    el.remove();
    return fam.split(",")[0].trim().replace(/["']/g, "");
  };
  const display = familyOf("font-display") || "Inter";
  const mono = familyOf("font-mono") || "ui-monospace";
  try {
    await Promise.all([
      document.fonts.load(`300 52px "${display}"`),
      document.fonts.load(`500 17px "${display}"`),
      document.fonts.load(`italic 17px "${display}"`),
      document.fonts.load(`12px "${mono}"`),
    ]);
    await document.fonts.ready;
  } catch {
    /* older browsers — the stacks below still degrade gracefully */
  }
  posterFontsCache = {
    display: `"${display}", 'Helvetica Neue', 'Segoe UI', Arial, sans-serif`,
    mono: `"${mono}", 'SF Mono', ui-monospace, Menlo, Consolas, monospace`,
  };
  return posterFontsCache;
}

/* --- Compose the gallery poster on an offscreen canvas --- */
function composePoster(
  src: HTMLCanvasElement,
  vehicle: Vehicle,
  color: VehicleColor,
  atmosphere: AtmospherePreset,
  imageOverride?: HTMLImageElement,
  fonts?: PosterFonts
): HTMLCanvasElement {
  const W = 1600;
  const H = 1000;
  const out = document.createElement("canvas");
  out.width = W;
  out.height = H;
  const ctx = out.getContext("2d");
  if (!ctx) return out;

  const DISPLAY = fonts?.display ?? "'Helvetica Neue', 'Segoe UI', Arial, sans-serif";
  const MONO = fonts?.mono ?? "'SF Mono', ui-monospace, Menlo, Consolas, monospace";
  const spacing = (v: string) => {
    try {
      (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = v;
    } catch {
      /* older browsers */
    }
  };

  // Backdrop
  ctx.fillStyle = "#08090B";
  ctx.fillRect(0, 0, W, H);

  // Outer hairline frame
  ctx.strokeStyle = "rgba(243,243,241,0.10)";
  ctx.lineWidth = 1;
  roundRect(ctx, 40, 40, W - 80, H - 80, 14);
  ctx.stroke();

  // Photo area with cover-crop
  const px = 64;
  const py = 64;
  const pw = W - 128;
  const ph = 660;
  const img = imageOverride ?? null;
  const sw = src.width;
  const sh = src.height;
  if (sw > 0 && sh > 0) {
    const srcAspect = sw / sh;
    const dstAspect = pw / ph;
    let cropW = sw;
    let cropH = sh;
    if (srcAspect > dstAspect) {
      cropW = sh * dstAspect;
    } else {
      cropH = sw / dstAspect;
    }
    const cropX = (sw - cropW) / 2;
    const cropY = (sh - cropH) / 2;
    ctx.save();
    roundRect(ctx, px, py, pw, ph, 6);
    ctx.clip();
    if (img) {
      ctx.drawImage(img, px, py, pw, ph);
    } else {
      ctx.drawImage(src, cropX, cropY, cropW, cropH, px, py, pw, ph);
    }
    // Soft vignette to sit the photo into the poster
    const grad = ctx.createRadialGradient(
      px + pw / 2,
      py + ph / 2,
      Math.min(pw, ph) * 0.42,
      px + pw / 2,
      py + ph / 2,
      Math.max(pw, ph) * 0.72
    );
    grad.addColorStop(0, "rgba(8,9,11,0)");
    grad.addColorStop(1, "rgba(8,9,11,0.36)");
    ctx.fillStyle = grad;
    ctx.fillRect(px, py, pw, ph);
    ctx.restore();
  }

  // Corner ticks on the photo frame
  ctx.strokeStyle = "rgba(243,243,241,0.45)";
  ctx.lineWidth = 2;
  const tick = 16;
  const corners: [number, number, number, number][] = [
    [px, py, 1, 1],
    [px + pw, py, -1, 1],
    [px, py + ph, 1, -1],
    [px + pw, py + ph, -1, -1],
  ];
  for (const [cx, cy, dx, dy] of corners) {
    ctx.beginPath();
    ctx.moveTo(cx + dx * tick, cy);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx, cy + dy * tick);
    ctx.stroke();
  }

  // Header strip
  ctx.textBaseline = "alphabetic";
  spacing("10px");
  ctx.fillStyle = "#F3F3F1";
  ctx.font = `500 17px ${DISPLAY}`;
  ctx.fillText("CARIO", 64, 786);
  spacing("3px");
  ctx.fillStyle = "#858990";
  ctx.font = `12px ${MONO}`;
  ctx.textAlign = "right";
  ctx.fillText(
    `${vehicle.brand.toUpperCase()} · ${vehicle.generation.toUpperCase()} · ${vehicle.year}`,
    W - 64,
    786
  );
  ctx.textAlign = "left";

  // Model name + tagline
  spacing("0px");
  ctx.fillStyle = "#F3F3F1";
  ctx.font = `300 52px ${DISPLAY}`;
  ctx.fillText(vehicle.model, 64, 856);
  ctx.fillStyle = "#858990";
  ctx.font = `italic 17px ${DISPLAY}`;
  ctx.fillText(vehicle.tagline, 64, 886);

  // Paint + atmosphere chips (bottom-left, under tagline)
  const chipY = 922;
  ctx.fillStyle = color.hex;
  ctx.beginPath();
  ctx.arc(74, chipY - 5, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(243,243,241,0.25)";
  ctx.lineWidth = 1;
  ctx.stroke();
  spacing("2px");
  ctx.fillStyle = "#C9CBD0";
  ctx.font = `12px ${MONO}`;
  ctx.fillText(`${color.name.toUpperCase()} · ${color.finish.toUpperCase()}`, 90, chipY);
  ctx.fillStyle = "#3F434A";
  ctx.fillText("·", 90 + ctx.measureText(`${color.name.toUpperCase()} · ${color.finish.toUpperCase()}`).width + 14, chipY);
  ctx.fillStyle = "#858990";
  ctx.fillText(`AMBIENCE ${atmosphere.name.toUpperCase()}`, 90 + ctx.measureText(`${color.name.toUpperCase()} · ${color.finish.toUpperCase()}`).width + 34, chipY);

  // Spec strip (right column)
  const specs: [string, string][] = [
    ["POWER", `${vehicle.spec.horsepower} HP`],
    ["0–100", `${vehicle.spec.acceleration} S`],
    ["TOP", `${vehicle.spec.topSpeed} KM/H`],
  ];
  let sx = W - 64;
  ctx.textAlign = "right";
  for (let i = specs.length - 1; i >= 0; i--) {
    const [label, value] = specs[i];
    spacing("2px");
    ctx.fillStyle = "#3F434A";
    ctx.font = `10px ${MONO}`;
    ctx.fillText(label, sx, 826);
    spacing("0px");
    ctx.fillStyle = "#C9CBD0";
    ctx.font = `300 30px ${DISPLAY}`;
    ctx.fillText(value, sx, 862);
    sx -= 250;
  }
  ctx.textAlign = "left";

  // Footer
  ctx.strokeStyle = "rgba(243,243,241,0.08)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(64, 946);
  ctx.lineTo(W - 64, 946);
  ctx.stroke();
  spacing("3px");
  ctx.fillStyle = "#3F434A";
  ctx.font = `10px ${MONO}`;
  ctx.fillText("CARIO PHOTO STUDIO", 64, 972);
  ctx.textAlign = "right";
  const link = typeof window !== "undefined" ? `${window.location.origin}/?car=${vehicle.id}` : "";
  ctx.fillText(link || String(vehicle.year), W - 64, 972);
  ctx.textAlign = "left";

  return out;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") {
    ctx.roundRect(x, y, w, h, r);
  } else {
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
}
