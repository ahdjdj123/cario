"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CarViewer3D } from "@/components/cario/three/CarViewer3D";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { CornerReturn, ViewHeader } from "@/components/cario/ui-parts/PrimaryActions";
import {
  IDENTIFY_DIFFICULTIES,
  useCario,
  type IdentifyDifficulty,
} from "@/lib/cario/store";
import {
  getVehicle,
  pickIdentifyQuestions,
  type IdentifyQuestion,
} from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioIdentify — car-recognition mini game
   ------------------------------------------------------------
   Title: IDENTIFY · "What are you looking at?"
   A cropped automotive detail of a 3D model. Four compact
   capsule answers. Sophisticated, minimal. No neon, no
   oversized score graphics, no XP. Subtle response on correct.

   Three difficulties (Sprint 10 / Grand Tour 15 / Endurance 20)
   with a per-difficulty persisted best. A start screen picks the
   mode; an end summary reports score, accuracy and the longest
   correct streak.
   ============================================================ */

type Phase = "setup" | "playing" | "finished";

const DIFFICULTY_ORDER: IdentifyDifficulty[] = ["sprint", "grand-tour", "endurance"];

function cropCameraFor(
  vehicleId: string,
  detail: IdentifyQuestion["detail"],
  zoom: number
): { position: [number, number, number]; target: [number, number, number]; fov: number } {
  const v = getVehicle(vehicleId);
  if (!v) return { position: [4, 1.4, 4], target: [0, 0.4, 0], fov: 32 };
  const L = v.raw.length * 4.0;
  const W = v.raw.track * 1.95;
  const Hb = v.raw.height;
  const wheelR = v.raw.wheelRadius;
  const frontAxleX = L / 2 - v.raw.noseRatio * L * 0.62 - 0.3;

  // base distance scales down with zoom
  const z = zoom;

  switch (detail) {
    case "taillight":
      return {
        position: [-L / 2 - 1.4 / z, Hb * 0.7, 1.4 / z],
        target: [-L / 2 + 0.1, Hb * 0.55, 0],
        fov: 22,
      };
    case "headlight":
      return {
        position: [L / 2 + 1.2 / z, Hb * 0.7, 1.6 / z],
        target: [L / 2 - 0.08, Hb * 0.5, W * 0.3],
        fov: 22,
      };
    case "wheel":
      return {
        position: [frontAxleX + 0.3 / z, wheelR + 0.2, W / 2 + 1.3 / z],
        target: [frontAxleX, wheelR, W / 2 - 0.05],
        fov: 22,
      };
    case "grille":
      return {
        position: [L / 2 + 1.4 / z, Hb * 0.6, 0.6 / z],
        target: [L / 2 - 0.05, Hb * 0.45, 0],
        fov: 22,
      };
    case "silhouette":
      return {
        position: [4.5 / (z * 0.8), 1.5, 5.0 / (z * 0.8)],
        target: [0, Hb * 0.5, 0],
        fov: 28,
      };
    case "interior":
    default:
      return {
        position: [3.6 / z, 1.4, 4.2 / z],
        target: [0, Hb * 0.5, 0],
        fov: 28,
      };
  }
}

export function CarioIdentify() {
  const goBack = useCario((s) => s.goBack);
  const setView = useCario((s) => s.setView);
  const recordResult = useCario((s) => s.recordIdentifyResult);
  const setIdentifyDifficulty = useCario((s) => s.setIdentifyDifficulty);
  const difficulty = useCario((s) => s.identifyDifficulty);
  const bestByMode = useCario((s) => s.identifyBestByMode);
  const grain = useCario((s) => s.settings.grain);

  const [phase, setPhase] = useState<Phase>("setup");
  const [rounds, setRounds] = useState(IDENTIFY_DIFFICULTIES[difficulty].rounds);

  const questions = useMemo(
    () => pickIdentifyQuestions(rounds),
    // Re-pick only when a new run starts (rounds changes at start)
    [rounds]
  );
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [locked, setLocked] = useState(false);
  const [isNewBest, setIsNewBest] = useState(false);

  const modeBest = bestByMode[difficulty] ?? 0;

  const startRun = (mode: IdentifyDifficulty) => {
    setIdentifyDifficulty(mode);
    setRounds(IDENTIFY_DIFFICULTIES[mode].rounds);
    setIndex(0);
    setScore(0);
    setStreak(0);
    setBestStreak(0);
    setSelected(null);
    setLocked(false);
    setIsNewBest(false);
    setPhase("playing");
  };

  const q = questions[Math.min(index, questions.length - 1)];
  const vehicle = getVehicle(q.answerVehicleId)!;
  const color = vehicle.colors[0]; // neutral default; color cues are de-emphasized by crop
  const cam = cropCameraFor(q.answerVehicleId, q.detail, q.crop.zoom);

  const pick = (i: number) => {
    if (locked) return;
    setSelected(i);
    setLocked(true);
    const correct = i === q.correctIndex;
    if (correct) {
      setScore((s) => s + 1);
      setStreak((s) => {
        const next = s + 1;
        setBestStreak((b) => Math.max(b, next));
        return next;
      });
    } else {
      setStreak(0);
    }
    window.setTimeout(() => {
      if (index + 1 >= questions.length) {
        const finalScore = score + (correct ? 1 : 0);
        setScore(finalScore);
        recordResult(finalScore, difficulty);
        setIsNewBest(finalScore > modeBest);
        setPhase("finished");
      } else {
        setIndex((x) => x + 1);
        setSelected(null);
        setLocked(false);
      }
    }, 1100);
  };

  const accuracy = Math.round((score / questions.length) * 100);
  const verdict =
    accuracy >= 90
      ? "Exceptional eye."
      : accuracy >= 70
        ? "A trained gaze."
        : accuracy >= 40
          ? "Getting closer."
          : "Keep looking.";

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" grain={grain} />

      {/* Cropped vehicle */}
      <div className="absolute inset-0">
        <CarViewer3D
          vehicle={vehicle}
          color={color}
          cameraPosition={cam.position}
          cameraTarget={cam.target}
          autoRotate={false}
          enableZoom={false}
          polarRange={[0.35, Math.PI / 2 - 0.1]}
          quality="balanced"
          hideLights={q.detail === "silhouette" && phase !== "setup"}
          silhouette={q.detail === "silhouette" && phase !== "setup"}
        />
      </div>

      {/* Top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between px-6 py-6 sm:px-10 sm:py-8">
        <div className="pointer-events-auto flex flex-col gap-4">
          <CornerReturn label="Back" onClick={() => goBack()} />
          <ViewHeader eyebrow="CARIO / 04" title="Identify" subtitle="What are you looking at?" />
        </div>
        {phase === "playing" && (
          <div className="pointer-events-none mr-12 flex flex-col items-end gap-1 sm:mr-14">
            <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray/70">
              Question
            </span>
            <span className="font-display text-2xl font-light tabular-nums text-cario-white">
              {String(index + 1).padStart(2, "0")}
              <span className="text-cario-soft-gray/50"> / {String(questions.length).padStart(2, "0")}</span>
            </span>
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50">
              {IDENTIFY_DIFFICULTIES[difficulty].label} · Score {score} · Best{" "}
              {Math.max(modeBest, score)}
            </span>
          </div>
        )}
      </div>

      {/* Bottom sheet — swaps between setup / answers / summary */}
      <div className="absolute inset-x-0 bottom-0 z-20 flex flex-col items-center gap-4 px-6 pb-8 sm:pb-10">
        <AnimatePresence mode="wait">
          {phase === "setup" && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="flex w-full max-w-xl flex-col gap-3"
            >
              <span className="text-center font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                Choose your discipline
              </span>
              {DIFFICULTY_ORDER.map((mode, i) => {
                const d = IDENTIFY_DIFFICULTIES[mode];
                const best = bestByMode[mode] ?? 0;
                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => startRun(mode)}
                    className={cn(
                      "group flex items-center gap-4 rounded-xl border px-5 py-4 text-left backdrop-blur-md transition-all duration-300 active:scale-[0.985]",
                      "border-white/10 bg-white/[0.03] hover:border-white/25 hover:bg-white/[0.06]"
                    )}
                  >
                    <span className="font-mono text-[9px] tabular-nums text-cario-soft-gray/50">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="flex flex-1 flex-col gap-0.5">
                      <span className="font-display text-sm font-medium uppercase tracking-wider-2 text-cario-white">
                        {d.label}
                      </span>
                      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                        {d.rounds} rounds · {d.hint}
                      </span>
                    </span>
                    <span className="flex flex-col items-end gap-0.5">
                      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                        Best
                      </span>
                      <span className="font-display text-sm font-light tabular-nums text-cario-light-gray">
                        {best > 0 ? `${best}/${d.rounds}` : "—"}
                      </span>
                    </span>
                    <span className="text-cario-soft-gray/40 transition-all duration-300 group-hover:translate-x-1 group-hover:text-cario-white">
                      →
                    </span>
                  </button>
                );
              })}
            </motion.div>
          )}

          {phase === "playing" && (
            <motion.div
              key={`q-${index}`}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              className="flex w-full max-w-3xl flex-col gap-3"
            >
              <span className="text-center font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
                {q.detail}
              </span>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {q.options.map((opt, i) => {
                  const isCorrect = i === q.correctIndex;
                  const isSelected = selected === i;
                  const showState = locked;
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => pick(i)}
                      disabled={locked}
                      className={cn(
                        "group relative flex items-center justify-center gap-2 rounded-full border px-5 py-3 text-center transition-all duration-300 active:scale-[0.97]",
                        "border-white/10 bg-white/[0.03] text-cario-light-gray hover:border-white/20 hover:text-cario-white",
                        showState && isCorrect && "border-white/30 bg-white/10 text-cario-white",
                        showState && isSelected && !isCorrect && "border-white/5 text-cario-soft-gray/40 opacity-50"
                      )}
                    >
                      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50">
                        {String.fromCharCode(65 + i)}
                      </span>
                      <span className="text-[13px] font-medium tracking-tight-2">{opt}</span>
                      {showState && isCorrect && (
                        <motion.span
                          initial={{ scale: 0.5, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full border border-white/30 bg-black/60 text-[8px] text-cario-white"
                        >
                          ✓
                        </motion.span>
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {phase === "finished" && (
            <motion.div
              key="finished"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="flex w-full max-w-md flex-col items-center gap-5"
            >
              <div className="flex items-center gap-3">
                <span className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray">
                  Result
                </span>
                <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50">
                  {IDENTIFY_DIFFICULTIES[difficulty].label}
                </span>
                {isNewBest && (
                  <motion.span
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.35 }}
                    className="rounded-full border border-white/25 bg-white/10 px-2.5 py-0.5 font-mono text-[8px] uppercase tracking-label text-cario-white"
                  >
                    New best
                  </motion.span>
                )}
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-display text-5xl font-extralight tracking-tight-3 text-cario-white tabular-nums">
                  {score}
                </span>
                <span className="font-mono text-sm text-cario-soft-gray">/ {questions.length}</span>
              </div>

              {/* Summary strip — accuracy + longest streak */}
              <div className="flex items-center gap-5 rounded-xl border border-white/8 bg-white/[0.02] px-6 py-3 backdrop-blur-md">
                <div className="flex flex-col items-center gap-0.5">
                  <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                    Accuracy
                  </span>
                  <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
                    {accuracy}%
                  </span>
                </div>
                <span className="h-6 w-px bg-white/10" />
                <div className="flex flex-col items-center gap-0.5">
                  <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                    Best streak
                  </span>
                  <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
                    {bestStreak}
                  </span>
                </div>
                <span className="h-6 w-px bg-white/10" />
                <div className="flex flex-col items-center gap-0.5">
                  <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
                    Mode best
                  </span>
                  <span className="font-display text-base font-light tabular-nums text-cario-light-gray">
                    {Math.max(modeBest, score)}/{questions.length}
                  </span>
                </div>
              </div>

              <span className="text-[12px] italic text-cario-soft-gray">{verdict}</span>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => startRun(difficulty)}
                  className="group flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.04] px-6 py-3 text-cario-white backdrop-blur-md transition-colors hover:border-white/30 hover:bg-white/[0.08] active:scale-[0.97]"
                >
                  <span className="font-display text-[13px] font-medium uppercase tracking-wider-2">
                    Play again
                  </span>
                  <span className="text-cario-soft-gray transition-transform group-hover:rotate-180">↻</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPhase("setup")}
                  className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray transition-colors hover:text-cario-light-gray"
                >
                  Change discipline
                </button>
                <button
                  type="button"
                  onClick={() => setView("home")}
                  className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray transition-colors hover:text-cario-light-gray"
                >
                  Back to garage
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
