"use client";

import { useEffect } from "react";
import { useCario } from "@/lib/cario/store";
import { computeAchievements } from "@/lib/cario/achievements";

/* ============================================================
   AchievementWatcher — global milestone unlock detector
   ------------------------------------------------------------
   Mounted once by the shell. Subscribes to the store and
   diffs the currently-unlocked achievement ids against
   `seenAchievements`:

   - First run (seenAchievements === null): everything already
     unlocked is silently acknowledged (baseline) so users with
     prior progress are not greeted by a toast storm.
   - Afterwards: every NEW unlock fires a single "trophy" toast.

   The watcher never blocks the UI — evaluation is a cheap pure
   pass over 14 definitions.
   ============================================================ */

export function AchievementWatcher() {
  useEffect(() => {
    let baselineDone =
      useCario.getState().seenAchievements !== null;

    const pass = () => {
      try {
        const state = useCario.getState();
        const unlocked = computeAchievements(state)
          .filter((a) => a.unlocked)
          .map((a) => a.def.id);

        // Baseline: silently acknowledge pre-existing progress
        if (!baselineDone) {
          baselineDone = true;
          if (unlocked.length > 0) {
            state.markAchievementsSeen(unlocked);
          }
          return;
        }

        const seen = new Set(state.seenAchievements ?? []);
        const fresh = unlocked.filter((id) => !seen.has(id));
        if (fresh.length === 0) return;

        // Commit FIRST. Zustand listeners fire synchronously inside
        // pushToast's set(), which re-enters this subscriber — the
        // re-entrant pass must observe the updated seen-set, otherwise
        // the fresh-diff never empties and pushToast recurses until the
        // stack overflows (which also aborts the persist write!).
        state.markAchievementsSeen(fresh);

        const byId = new Map(
          computeAchievements(state).map((a) => [a.def.id, a.def])
        );
        for (const id of fresh) {
          const def = byId.get(id);
          if (def) state.pushToast(`Milestone unlocked · ${def.title}`, "trophy");
        }
      } catch {
        // Milestone evaluation must never break store updates or
        // persistence — swallow and retry on the next state change.
      }
    };

    pass();
    return useCario.subscribe(pass);
  }, []);

  return null;
}
