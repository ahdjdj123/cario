"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Volume2, VolumeX, Pause, Play } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";
import { useCario } from "@/lib/cario/store";
import { cn } from "@/lib/utils";

/* ============================================================
   SoundStudio — procedural engine note synthesizer
   ------------------------------------------------------------
   A visual + audible engine-RPM studio that synthesizes the
   car's firing character from its engine configuration
   (cylinder count, layout). The user can rev the engine
   (hold/press REV), and the waveform, cylinder firing and —
   when audio is enabled — a real Web Audio engine note all
   respond in real time.

   Audio is built from detuned saw oscillators whose firing
   frequency tracks the live RPM (rpm/60 × cylinders/2), with
   a sub-octave sine and an RPM-tracked lowpass for the turbo
   intake. Electric powertrains (0 cylinders) get a smooth EV
   whine instead. Audio is OFF (muted) by default and is only
   created on a user gesture, per browser autoplay policy.
   ============================================================ */

export function SoundStudio({ vehicle }: { vehicle: Vehicle }) {
  const [revving, setRevving] = useState(false);
  const [rpm, setRpm] = useState(800); // idle RPM
  const [muted, setMuted] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);
  // Live RPM mirrors state so the canvas + audio loops can read it
  // without re-subscribing on every frame.
  const rpmRef = useRef(rpm);

  // --- Web Audio graph refs ------------------------------------------
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscsRef = useRef<OscillatorNode[]>([]);
  const subOscRef = useRef<OscillatorNode | null>(null);
  const filterRef = useRef<BiquadFilterNode | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);

  // Parse cylinder count from the engine string (e.g. "4.0L Flat-6" → 6)
  const cylCount = parseCylinderCount(vehicle.spec.engine);
  const firingOrder = getFiringOrder(cylCount);
  const isElectric = cylCount === 0;

  // Keep rpmRef in sync with the rpm state (in an effect, not during render)
  useEffect(() => {
    rpmRef.current = rpm;
  }, [rpm]);

  // --- Audio synthesis ------------------------------------------------
  const firingFrequency = (r: number) =>
    isElectric
      ? 120 + (r / 8500) * 720 // EV whine range
      : Math.max(24, (r / 60) * (cylCount / 2)); // firing frequency

  function startEngineAudio() {
    if (audioCtxRef.current) return;
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    audioCtxRef.current = ctx;

    const master = ctx.createGain();
    master.gain.value = 0;
    master.connect(ctx.destination);
    masterGainRef.current = master;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 900;
    filter.Q.value = 0.8;
    filter.connect(master);
    filterRef.current = filter;

    if (isElectric) {
      // EV — smooth whine
      const whine = ctx.createOscillator();
      whine.type = "sine";
      whine.frequency.value = firingFrequency(800);
      const whineGain = ctx.createGain();
      whineGain.gain.value = 0.5;
      whine.connect(whineGain).connect(filter);
      whine.start();
      oscsRef.current = [whine];
    } else {
      // Combustion — detuned saw + square plus a sub-octave sine for body
      const detunes = [0, 9];
      oscsRef.current = detunes.map((cents, i) => {
        const osc = ctx.createOscillator();
        osc.type = i === 0 ? "sawtooth" : "square";
        osc.frequency.value = firingFrequency(800);
        osc.detune.value = cents;
        const g = ctx.createGain();
        g.gain.value = i === 0 ? 0.45 : 0.22;
        osc.connect(g).connect(filter);
        osc.start();
        return osc;
      });
      const sub = ctx.createOscillator();
      sub.type = "sine";
      sub.frequency.value = firingFrequency(800) / 2;
      const subGain = ctx.createGain();
      subGain.gain.value = 0.5;
      sub.connect(subGain).connect(filter);
      sub.start();
      subOscRef.current = sub;
    }
  }

  /** Per-frame audio update — cheap param automation, no allocation. */
  function updateEngineAudio(r: number, revvingNow: boolean) {
    const ctx = audioCtxRef.current;
    const master = masterGainRef.current;
    const filter = filterRef.current;
    if (!ctx || !master || !filter || ctx.state !== "running") return;

    const t = ctx.currentTime;
    const norm = (r - 500) / 8000; // 0..1
    const freq = firingFrequency(r);

    for (const osc of oscsRef.current) {
      osc.frequency.setTargetAtTime(freq, t, 0.03);
    }
    if (subOscRef.current) {
      subOscRef.current.frequency.setTargetAtTime(freq / 2, t, 0.03);
    }
    // Turbo/intake opens with revs; louder + brighter under load.
    // The Settings master volume (0–1) scales the whole engine note.
    const vol = Math.min(Math.max(useCario.getState().settings.masterVolume, 0), 1);
    filter.frequency.setTargetAtTime(500 + norm * 3200, t, 0.05);
    master.gain.setTargetAtTime(
      ((revvingNow ? 0.11 : 0.05) + norm * 0.05) * vol,
      t,
      0.08
    );
  }

  const toggleAudio = () => {
    const next = !muted;
    setMuted(next);
    if (!next) {
      // Audio can only be started inside a user gesture
      startEngineAudio();
      void audioCtxRef.current?.resume();
      updateEngineAudio(rpmRef.current, revving);
    } else {
      void audioCtxRef.current?.suspend();
    }
  };

  // Cleanup — close the context on unmount
  useEffect(() => {
    return () => {
      const ctx = audioCtxRef.current;
      if (ctx) void ctx.close();
      audioCtxRef.current = null;
      oscsRef.current = [];
      subOscRef.current = null;
      filterRef.current = null;
      masterGainRef.current = null;
    };
  }, []);

  // Idle drift + rev response
  useEffect(() => {
    let last = performance.now();
    const tick = () => {
      const now = performance.now();
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      const r = rpmRef.current;
      const target = revving ? 7500 : 800;
      const diff = target - r;
      // smooth approach with slight noise
      const next = Math.max(
        500,
        Math.min(8500, r + diff * dt * (revving ? 2.5 : 1.2) + (Math.random() - 0.5) * 40 * dt)
      );
      rpmRef.current = next;
      setRpm(next);
      updateEngineAudio(next, revving);
      animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [revving]);

  // Draw waveform
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let rafId: number;
    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const r = rpmRef.current;
      const norm = (r - 500) / 8000; // 0..1

      // Background grid
      ctx.strokeStyle = "rgba(243, 243, 241, 0.04)";
      ctx.lineWidth = 1;
      for (let i = 0; i < 8; i++) {
        const y = (h / 8) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Waveform — composite sine waves at frequencies proportional to RPM
      ctx.strokeStyle = "rgba(243, 243, 241, 0.8)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      const cycles = 4 + norm * 12;
      const amp = h * 0.3 * (0.4 + norm * 0.6);
      for (let x = 0; x < w; x++) {
        const t = (x / w) * Math.PI * 2 * cycles;
        // engine-like waveform: fundamental + harmonics + noise
        const y =
          h / 2 +
          Math.sin(t) * amp * 0.6 +
          Math.sin(t * 2) * amp * 0.3 +
          Math.sin(t * cylCount / 2) * amp * 0.2 +
          (Math.random() - 0.5) * amp * 0.15;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // RPM bar on the right
      ctx.fillStyle = "rgba(243, 243, 241, 0.15)";
      ctx.fillRect(w - 6, h - h * norm, 4, h * norm);
      ctx.fillStyle = norm > 0.85 ? "rgba(243, 243, 241, 0.9)" : "rgba(243, 243, 241, 0.4)";
      ctx.fillRect(w - 6, h - h * norm, 2, h * norm);

      rafId = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafId);
  }, [cylCount]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-4"
    >
      {/* Waveform canvas */}
      <div className="relative w-[320px] max-w-[80vw]">
        <canvas
          ref={canvasRef}
          width={320}
          height={80}
          className="w-full rounded-md border border-white/8 bg-black/40"
        />
        {/* RPM readout overlay */}
        <div className="absolute left-3 top-2 flex flex-col gap-0.5">
          <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/60">
            RPM
          </span>
          <span className="font-display text-sm font-light tabular-nums text-cario-white">
            {Math.round(rpm)}
          </span>
        </div>
      </div>

      {/* Cylinder firing visualization */}
      <div className="flex items-center gap-1.5">
        {firingOrder.map((cyl, i) => {
          // Firing intensity based on RPM + phase offset per cylinder
          const phase = (rpm / 60) * 2 + i * (Math.PI * 2 / firingOrder.length);
          const intensity = (Math.sin(phase) + 1) / 2;
          const isFiring = intensity > 0.7;
          return (
            <motion.div
              key={i}
              animate={{
                opacity: isFiring ? 1 : 0.3,
                scale: isFiring ? 1.1 : 0.9,
              }}
              transition={{ duration: 0.05 }}
              className="flex h-6 w-6 items-center justify-center rounded-full border border-white/15"
              style={{
                background: isFiring ? "rgba(243, 243, 241, 0.15)" : "transparent",
                boxShadow: isFiring ? "0 0 8px rgba(243, 243, 241, 0.2)" : "none",
              }}
            >
              <span className="font-mono text-[8px] tabular-nums text-cario-light-gray">
                {cyl + 1}
              </span>
            </motion.div>
          );
        })}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4">
        <button
          type="button"
          onPointerDown={() => setRevving(true)}
          onPointerUp={() => setRevving(false)}
          onPointerLeave={() => setRevving(false)}
          className="group flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-5 py-2.5 text-cario-white backdrop-blur-md transition-all hover:border-white/30 hover:bg-white/[0.08] active:scale-95"
        >
          {revving ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          <span className="font-display text-[12px] font-medium uppercase tracking-wider-2">
            {revving ? "Revving" : "Hold to rev"}
          </span>
        </button>
        <button
          type="button"
          onClick={toggleAudio}
          className={cn(
            "relative flex h-9 w-9 items-center justify-center rounded-full border transition-colors",
            muted
              ? "border-white/10 text-cario-soft-gray hover:border-white/20 hover:text-cario-white"
              : "border-white/30 bg-white/10 text-cario-white"
          )}
          aria-label={muted ? "Enable engine audio" : "Disable engine audio"}
          aria-pressed={!muted}
          title={muted ? "Enable engine audio" : "Engine audio on"}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          {!muted && (
            <motion.span
              layoutId="sound-audio-live"
              className="absolute -bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-cario-white"
            />
          )}
        </button>
      </div>

      {/* Engine info */}
      <div className="flex items-center gap-3 font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
        <span>{vehicle.spec.engine ?? "Powertrain"}</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>{isElectric ? "E-powertrain" : `${cylCount} cylinders`}</span>
        <span className="h-3 w-px bg-cario-soft-gray/20" />
        <span>{muted ? "audio muted" : "audio live"}</span>
      </div>
    </motion.div>
  );
}

/* Parse the cylinder count from an engine string like "4.0L Flat-6",
   "6.5L V12", "3.0L Twin-Turbo I6" or "Dual E-motor". Combustion
   layouts are matched first so hybrids ("4.6L V8 + 2x E-motors")
   report their real cylinder count instead of falling through to
   the electric branch. */
function parseCylinderCount(engine?: string): number {
  if (!engine) return 8;
  const patterns: RegExp[] = [
    /(\d+)\s*cyl/i,
    /\bV(\d+)\b/i,
    /\bW(\d+)\b/i,
    /flat[- ]?(\d+)/i,
    /boxer[- ]?(\d+)/i,
    /straight[- ]?(\d+)/i,
    /\bI(\d+)\b/i,
  ];
  for (const p of patterns) {
    const m = engine.match(p);
    if (m) return parseInt(m[1], 10) || 8;
  }
  // Pure electric — no combustion cylinders
  if (/electric|e-motor|emotor/i.test(engine)) return 0;
  return 8;
}

/* Simple firing order (sequential) for visualization */
function getFiringOrder(count: number): number[] {
  if (count === 0) return [0]; // electric — single "pulse"
  return Array.from({ length: count }, (_, i) => i);
}
