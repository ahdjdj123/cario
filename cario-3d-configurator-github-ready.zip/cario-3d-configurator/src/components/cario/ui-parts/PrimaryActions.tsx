"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { CarioView } from "@/lib/cario/store";

/* ============================================================
   PrimaryActions — the four compact main controls
   ------------------------------------------------------------
   Per the brief: "refined controls floating naturally over the
   environment", NOT giant cards. Each is a minimal index + label
   with a hairline separator and a subtle underline that grows on
   hover. Settings is intentionally excluded — it lives as a
   small secondary icon elsewhere.
   ============================================================ */

export interface PrimaryAction {
  id: string;
  index: string;
  label: string;
  hint?: string;
  onSelect: () => void;
  disabled?: boolean;
}

export function PrimaryActions({
  actions,
  className,
}: {
  actions: PrimaryAction[];
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-stretch justify-center gap-0",
        className
      )}
    >
      {actions.map((a, i) => (
        <ActionButton key={a.id} action={a} first={i === 0} last={i === actions.length - 1} />
      ))}
    </div>
  );
}

function ActionButton({
  action,
  first,
  last,
}: {
  action: PrimaryAction;
  first: boolean;
  last: boolean;
}) {
  return (
    <motion.button
      type="button"
      disabled={action.disabled}
      onClick={action.onSelect}
      whileHover={{ y: -2 }}
      whileTap={{ y: 0 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className={cn(
        "group relative flex min-w-[88px] flex-col items-center gap-1.5 px-3 py-3 text-center sm:min-w-[160px] sm:px-7",
        "text-cario-light-gray transition-colors hover:text-cario-white",
        action.disabled && "cursor-not-allowed opacity-30 hover:text-cario-light-gray",
        !first && "border-l border-white/10",
        last && "sm:border-r"
      )}
    >
      <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70 transition-colors group-hover:text-cario-soft-gray">
        {action.index}
      </span>
      <span className="font-display text-[11px] font-medium tracking-wider-2 uppercase sm:text-sm">
        {action.label}
      </span>
      {action.hint && (
        <span className="hidden text-[9px] uppercase tracking-label text-cario-soft-gray/50 sm:block">
          {action.hint}
        </span>
      )}
      {/* Underline that grows on hover */}
      <span className="absolute -bottom-px left-1/2 h-px w-0 -translate-x-1/2 bg-cario-white transition-all duration-500 group-hover:w-10" />
    </motion.button>
  );
}

/* ============================================================
   ViewHeader — title + subtitle block used on each screen
   ============================================================ */

export function ViewHeader({
  eyebrow,
  title,
  subtitle,
  className,
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  className?: string;
  align?: "left" | "center";
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-2",
        align === "center" && "items-center text-center",
        className
      )}
    >
      {eyebrow && (
        <motion.span
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="font-mono text-[10px] uppercase tracking-label text-cario-soft-gray"
        >
          {eyebrow}
        </motion.span>
      )}
      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.05 }}
        className="font-display text-2xl font-light tracking-tight-2 text-cario-white sm:text-3xl md:text-4xl"
      >
        {title}
      </motion.h1>
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.12 }}
          className="max-w-md text-sm text-cario-soft-gray sm:text-[15px]"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}

/* ============================================================
   CornerReturn — small back control top-left
   ============================================================ */

export function CornerReturn({
  label = "Back",
  onClick,
  to = "home" as CarioView,
}: {
  label?: string;
  onClick: () => void;
  to?: CarioView;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ opacity: 0, x: -6 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="group flex items-center gap-2 text-cario-soft-gray transition-colors hover:text-cario-white"
    >
      <span className="text-cario-soft-gray transition-transform group-hover:-translate-x-0.5">←</span>
      <span className="text-[11px] uppercase tracking-label">{label}</span>
    </motion.button>
  );
}
