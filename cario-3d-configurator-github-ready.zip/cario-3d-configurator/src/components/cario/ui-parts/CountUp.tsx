"use client";

import { useEffect, useRef, useState } from "react";

/* ============================================================
   CountUp — animated numeric reveal for spec figures
   ------------------------------------------------------------
   Eases from 0 (or `from`) up to `value` with a cubic ease-out,
   driven by requestAnimationFrame. Respects the reduce-motion
   accessibility setting (renders the final value immediately).
   ============================================================ */

interface CountUpProps {
  value: number;
  /** Decimal places to render (0 for integers) */
  decimals?: number;
  /** Animation duration in ms */
  duration?: number;
  /** Delay before the count begins, in ms */
  delay?: number;
  /** Start value */
  from?: number;
  className?: string;
  reduceMotion?: boolean;
}

export function CountUp({
  value,
  decimals = 0,
  duration = 1200,
  delay = 0,
  from = 0,
  className,
  reduceMotion = false,
}: CountUpProps) {
  const [display, setDisplay] = useState(from);
  const rafRef = useRef<number | null>(null);

  // Reduced motion renders the final value directly — no state updates.
  const rendered = reduceMotion ? value : display;

  useEffect(() => {
    if (reduceMotion) return;
    let start: number | null = null;
    const tick = (now: number) => {
      if (start === null) start = now + delay;
      const elapsed = now - start;
      if (elapsed < 0) {
        rafRef.current = requestAnimationFrame(tick);
        return;
      }
      const p = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (value - from) * eased);
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [value, from, duration, delay, reduceMotion]);

  return (
    <span className={className} style={{ fontVariantNumeric: "tabular-nums" }}>
      {rendered.toFixed(decimals)}
    </span>
  );
}
