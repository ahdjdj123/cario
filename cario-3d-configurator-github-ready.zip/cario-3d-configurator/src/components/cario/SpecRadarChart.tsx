"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Radar, X } from "lucide-react";
import type { Vehicle } from "@/lib/vehicles/types";
import { VEHICLES } from "@/lib/vehicles";

/* ============================================================
   SpecRadarChart — performance profile visualization
   ------------------------------------------------------------
   A compact SVG radar/pentagon chart showing the car's
   performance profile across 5 normalized dimensions:
   - Power (horsepower)
   - Acceleration (0-100, inverted — lower is better)
   - Top speed
   - Lightness (weight, inverted — lower is better)
   - Efficiency (power-to-weight)

   Triggered by a small radar icon button in the Car Experience.
   Shown as a modal overlay.
   ============================================================ */

const AXES = ["Power", "Accel", "Speed", "Lightness", "Efficiency"] as const;

export function SpecRadarChart({ vehicle }: { vehicle: Vehicle }) {
  const [open, setOpen] = useState(false);

  // Close on Escape — the overlay sentinel keeps the global handler
  // from navigating the view behind the open modal.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open]);

  // Normalize each metric to 0..1 based on the full collection's range
  const values = computeNormalizedValues(vehicle);

  // SVG geometry
  const size = 240;
  const cx = size / 2;
  const cy = size / 2;
  const radius = size * 0.36;
  const n = AXES.length;

  // Pentagon points for the value shape
  const points = AXES.map((_, i) => {
    const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
    const r = radius * values[i];
    return [cx + Math.cos(angle) * r, cy + Math.sin(angle) * r] as const;
  });
  const polygonPoints = points.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");

  // Grid pentagons (at 25%, 50%, 75%, 100%)
  const gridLevels = [0.25, 0.5, 0.75, 1.0];
  const gridPolygons = gridLevels.map((level) => {
    const pts = AXES.map((_, i) => {
      const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
      const r = radius * level;
      return [cx + Math.cos(angle) * r, cy + Math.sin(angle) * r] as const;
    });
    return pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  });

  // Axis label positions (at 100% radius)
  const labelPositions = AXES.map((label, i) => {
    const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
    const r = radius + 20;
    return {
      label,
      x: cx + Math.cos(angle) * r,
      y: cy + Math.sin(angle) * r,
      anchor: Math.abs(Math.cos(angle)) < 0.3 ? "middle" : Math.cos(angle) > 0 ? "start" : "end",
    } as const;
  });

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-all hover:border-white/20 hover:text-cario-white"
        aria-label="Spec radar chart"
        title="Performance profile"
      >
        <Radar className="h-3.5 w-3.5" />
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setOpen(false)}
              data-cario-overlay="true"
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="fixed left-1/2 top-1/2 z-50 w-[360px] max-w-[88vw] -translate-x-1/2 -translate-y-1/2 cario-surface-strong rounded-lg"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
                <div className="flex items-center gap-2">
                  <Radar className="h-4 w-4 text-cario-soft-gray" />
                  <span className="font-display text-sm font-medium tracking-wider-2 uppercase text-cario-white">
                    Performance Profile
                  </span>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-cario-soft-gray transition-colors hover:border-white/20 hover:text-cario-white"
                  aria-label="Close"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Radar chart */}
              <div className="flex flex-col items-center px-5 py-5">
                <svg width={size} height={size} className="overflow-visible">
                  {/* Grid pentagons */}
                  {gridPolygons.map((pts, i) => (
                    <polygon
                      key={i}
                      points={pts}
                      fill="none"
                      stroke="rgba(243,243,241,0.06)"
                      strokeWidth="1"
                    />
                  ))}
                  {/* Axis lines */}
                  {AXES.map((_, i) => {
                    const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
                    const x = cx + Math.cos(angle) * radius;
                    const y = cy + Math.sin(angle) * radius;
                    return (
                      <line
                        key={i}
                        x1={cx}
                        y1={cy}
                        x2={x}
                        y2={y}
                        stroke="rgba(243,243,241,0.08)"
                        strokeWidth="1"
                      />
                    );
                  })}
                  {/* Value polygon */}
                  <motion.polygon
                    points={polygonPoints}
                    fill="rgba(243,243,241,0.08)"
                    stroke="rgba(243,243,241,0.6)"
                    strokeWidth="1.5"
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    style={{ transformOrigin: "center" }}
                  />
                  {/* Value points */}
                  {points.map(([x, y], i) => (
                    <motion.circle
                      key={i}
                      cx={x}
                      cy={y}
                      r="3"
                      fill="#F3F3F1"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 + i * 0.05 }}
                    />
                  ))}
                  {/* Axis labels */}
                  {labelPositions.map((p) => (
                    <text
                      key={p.label}
                      x={p.x}
                      y={p.y}
                      textAnchor={p.anchor}
                      dominantBaseline="middle"
                      fontFamily="monospace"
                      fontSize="9"
                      fill="#858990"
                      letterSpacing="1"
                    >
                      {p.label.toUpperCase()}
                    </text>
                  ))}
                </svg>

                {/* Raw values */}
                <div className="mt-2 grid grid-cols-5 gap-2 w-full">
                  {AXES.map((axis, i) => (
                    <div key={axis} className="flex flex-col items-center gap-0.5">
                      <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/50">
                        {axis}
                      </span>
                      <span className="font-display text-[10px] font-light tabular-nums text-cario-light-gray">
                        {Math.round(values[i] * 100)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="border-t border-white/8 px-5 py-3">
                <span className="font-mono text-[8px] uppercase tracking-label text-cario-soft-gray/40">
                  Normalized against the CARIO collection · 0–100 scale
                </span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* --- Normalize metrics against the full collection --- */
function computeNormalizedValues(vehicle: Vehicle): number[] {
  // Power: 0..1 (max HP in collection = 1)
  const maxPower = Math.max(...VEHICLES.map((v) => v.spec.horsepower));
  const power = vehicle.spec.horsepower / maxPower;

  // Acceleration: inverted (min 0-100 = 1, max = 0)
  const minAccel = Math.min(...VEHICLES.map((v) => v.spec.acceleration));
  const maxAccel = Math.max(...VEHICLES.map((v) => v.spec.acceleration));
  const accel = 1 - (vehicle.spec.acceleration - minAccel) / (maxAccel - minAccel);

  // Top speed: 0..1
  const maxSpeed = Math.max(...VEHICLES.map((v) => v.spec.topSpeed));
  const speed = vehicle.spec.topSpeed / maxSpeed;

  // Lightness: inverted weight (min weight = 1, max = 0)
  const weights = VEHICLES.map((v) => v.spec.weight ?? 2000);
  const minWeight = Math.min(...weights);
  const maxWeight = Math.max(...weights);
  const lightness = 1 - ((vehicle.spec.weight ?? 2000) - minWeight) / (maxWeight - minWeight);

  // Efficiency: power-to-weight ratio normalized
  const ptwRatios = VEHICLES.map((v) =>
    v.spec.weight ? v.spec.horsepower / v.spec.weight : 0
  );
  const maxPtw = Math.max(...ptwRatios);
  const efficiency = (vehicle.spec.weight ? vehicle.spec.horsepower / vehicle.spec.weight : 0) / maxPtw;

  return [
    Math.max(0, Math.min(1, power)),
    Math.max(0, Math.min(1, accel)),
    Math.max(0, Math.min(1, speed)),
    Math.max(0, Math.min(1, lightness)),
    Math.max(0, Math.min(1, efficiency)),
  ];
}
