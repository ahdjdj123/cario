"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { AudioLines } from "lucide-react";
import { ATMOSPHERE_PRESETS } from "@/lib/vehicles/atmosphere";
import type { AtmospherePresetId } from "@/lib/vehicles/types";
import { useCario } from "@/lib/cario/store";
import { createAmbience, type AmbienceHandle } from "@/lib/cario/ambience";
import { cn } from "@/lib/utils";

/* ============================================================
   AtmosphereStudio — environment switcher
   ------------------------------------------------------------
   A compact horizontal row of 5 environment presets (Studio /
   Dawn / Dusk / Night / Rain). Selecting one updates the 3D
   scene's lighting, environment map, floor material, and fog
   in real time via the store's atmosphereId.

   AMBIENCE — optional procedural soundscape that matches the
   active preset (breeze + birds at Dawn, crickets at Dusk,
   rain patter, deep night wind, faint studio air handling).
   Muted by default, created on the user's gesture, and it
   follows preset switches with a soft crossfade.
   ============================================================ */

export function AtmosphereStudio() {
  const atmosphereId = useCario((s) => s.atmosphereId);
  const setAtmosphere = useCario((s) => s.setAtmosphere);
  const masterVolume = useCario((s) => s.settings.masterVolume);

  const [live, setLive] = useState(false);
  const ambienceRef = useRef<AmbienceHandle | null>(null);

  // Keep the soundscape in sync with the selected preset while live
  useEffect(() => {
    ambienceRef.current?.setPreset(atmosphereId);
  }, [atmosphereId, live]);

  // Follow the Settings master volume live (no rebuild needed)
  useEffect(() => {
    ambienceRef.current?.setVolume(masterVolume);
  }, [masterVolume, live]);

  // Dispose the audio context when the studio unmounts
  useEffect(() => {
    return () => {
      ambienceRef.current?.dispose();
      ambienceRef.current = null;
    };
  }, []);

  const toggleAmbience = () => {
    const next = !live;
    setLive(next);
    if (next) {
      // (Re)create on the user gesture — safe per autoplay policy
      ambienceRef.current?.dispose();
      ambienceRef.current = createAmbience(atmosphereId, masterVolume);
      ambienceRef.current?.resume();
    } else {
      ambienceRef.current?.suspend();
    }
  };

  const active = ATMOSPHERE_PRESETS.find((p) => p.id === atmosphereId);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-3"
    >
      {/* Preset chips */}
      <div className="flex items-center gap-2">
        {ATMOSPHERE_PRESETS.map((p) => (
          <PresetChip
            key={p.id}
            preset={p}
            active={p.id === atmosphereId}
            onClick={() => setAtmosphere(p.id as AtmospherePresetId)}
          />
        ))}
      </div>

      {/* Ambience toggle — procedural soundscape for the preset */}
      <button
        type="button"
        onClick={toggleAmbience}
        className={cn(
          "group flex h-8 items-center gap-2.5 rounded-full border px-4 backdrop-blur-md transition-all active:scale-95",
          live
            ? "border-white/30 bg-white/10 text-cario-white"
            : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-white"
        )}
        aria-label={live ? "Disable ambience audio" : "Enable ambience audio"}
        aria-pressed={live}
        title={live ? "Ambience on — switch presets to change the mood" : "Enable ambience audio"}
      >
        <AudioLines className="h-3.5 w-3.5" />
        <span className="font-display text-[11px] font-medium uppercase tracking-wider-2">
          Ambience
        </span>
        {live ? (
          <EqBars />
        ) : (
          <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50">
            off
          </span>
        )}
      </button>

      {/* Active preset name + hint + ambience state */}
      <div className="flex flex-col items-center gap-0.5">
        <span className="font-display text-[13px] font-medium tracking-tight-2 text-cario-white">
          {active?.name ?? "Studio"}
        </span>
        <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
          {active?.hint ?? "Neutral showroom"}
          {live ? ` · ambience live` : ""}
        </span>
      </div>
    </motion.div>
  );
}

/* Four tiny animated level bars — the "sound is live" tell */
function EqBars() {
  return (
    <span className="flex h-3 items-end gap-[2px]" aria-hidden>
      {[0, 1, 2, 3].map((i) => (
        <span
          key={i}
          className="w-[2px] rounded-full bg-cario-white/80 animate-cario-eq"
          style={{ animationDelay: `${i * 0.18}s`, animationDuration: `${0.7 + i * 0.09}s` }}
        />
      ))}
    </span>
  );
}

function PresetChip({
  preset,
  active,
  onClick,
}: {
  preset: { id: string; name: string; keyColor: string; ambient: number };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={preset.name}
      className={cn(
        "group relative flex h-9 items-center gap-2 rounded-full border px-4 transition-all duration-300",
        active
          ? "border-white/30 bg-white/10 text-cario-white"
          : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
      )}
    >
      {/* Swatch — a tiny gradient orb representing the lighting mood */}
      <span
        className="block h-4 w-4 rounded-full border border-white/10"
        style={{
          background: `radial-gradient(circle at 30% 25%, ${preset.keyColor} 0%, ${darken(preset.keyColor, 0.4)} 70%, #050608 100%)`,
          opacity: active ? 1 : 0.7,
        }}
      />
      <span className="text-[10px] uppercase tracking-label">{preset.name}</span>
      {/* Active indicator dot */}
      {active && (
        <motion.span
          layoutId="atmosphere-active"
          className="absolute -bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-cario-white"
        />
      )}
    </button>
  );
}

function darken(hex: string, amt: number) {
  const h = hex.replace("#", "");
  const r = Math.round(parseInt(h.substring(0, 2), 16) * (1 - amt));
  const g = Math.round(parseInt(h.substring(2, 4), 16) * (1 - amt));
  const b = Math.round(parseInt(h.substring(4, 6), 16) * (1 - amt));
  return `rgb(${r}, ${g}, ${b})`;
}
