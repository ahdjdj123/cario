"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { Showroom } from "@/components/cario/three/Showroom";
import { Backdrop } from "@/components/cario/ui-parts/Backdrop";
import { ViewHeader, CornerReturn } from "@/components/cario/ui-parts/PrimaryActions";
import { useCario } from "@/lib/cario/store";
import {
  VEHICLES,
  getVehicle,
  getRimStyle,
  getRimFinish,
  type VehicleColor,
  type VehicleEra,
  type VehicleType,
} from "@/lib/vehicles";
import { cn } from "@/lib/utils";

/* ============================================================
   CarioExplore — the digital showroom
   ------------------------------------------------------------
   Several lightweight 3D vehicles positioned in a large dark
   digital showroom with depth. Minimal filters: BRANDS /
   GENERATIONS / TYPE / ERA + a text search. Clicking a vehicle
   opens its Car Experience.
   ============================================================ */

const BRANDS = Array.from(new Set(VEHICLES.map((v) => v.brand)));
const TYPES: VehicleType[] = ["coupe", "supercar", "hypercar", "gt"];
const ERAS: VehicleEra[] = ["classic", "modern", "contemporary", "future"];
const GENERATIONS = Array.from(new Set(VEHICLES.map((v) => v.generation)));

export function CarioExplore() {
  const goBack = useCario((s) => s.goBack);
  const selectVehicle = useCario((s) => s.selectVehicle);
  const activeColorId = useCario((s) => s.activeColorId);
  const activeRimStyleId = useCario((s) => s.activeRimStyleId);
  const activeRimFinishId = useCario((s) => s.activeRimFinishId);

  const [filter, setFilter] = useState<{
    brand?: string;
    generation?: string;
    type?: VehicleType;
    era?: VehicleEra;
  }>({});

  type SortKey = "default" | "power" | "year" | "name";
  const [sort, setSort] = useState<SortKey>("default");
  const [search, setSearch] = useState("");

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = VEHICLES.filter((v) => {
      if (filter.brand && v.brand !== filter.brand) return false;
      if (filter.generation && v.generation !== filter.generation) return false;
      if (filter.type && v.type !== filter.type) return false;
      if (filter.era && v.era !== filter.era) return false;
      if (q) {
        const haystack = `${v.brand} ${v.model} ${v.generation} ${v.year} ${v.type} ${v.era}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
    const sorted = [...filtered];
    if (sort === "power") sorted.sort((a, b) => b.spec.horsepower - a.spec.horsepower);
    else if (sort === "year") sorted.sort((a, b) => b.year - a.year);
    else if (sort === "name") sorted.sort((a, b) => a.model.localeCompare(b.model));
    return sorted;
  }, [filter, sort, search]);

  const activeColorFor = (v: { id: string }) => {
    const veh = getVehicle(v.id);
    if (!veh) return VEHICLES[0].colors[0];
    const colorId = activeColorId[v.id];
    if (colorId) {
      const c = veh.colors.find((c) => c.id === colorId);
      if (c) return c;
    }
    return veh.colors[0];
  };

  const colorForVehicle = activeColorFor;

  // Wheel Atelier — resolve each car's active rim configuration
  const activeRimFor = (v: { id: string }) => ({
    styleId: getRimStyle(activeRimStyleId[v.id]).id,
    finishId: getRimFinish(activeRimFinishId[v.id]).id,
  });

  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <Backdrop variant="spotlight" />

      {/* Showroom canvas */}
      <div className="absolute inset-0">
        <Showroom
          vehicles={visible}
          activeColorFor={colorForVehicle}
          activeRimFor={activeRimFor}
          onSelect={(id) => selectVehicle(id)}
        />
      </div>

      {/* Top-left: back + title + search (search lives in the left column
          so it never collides with the filter panel or the settings gear) */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-col gap-5 px-6 py-6 sm:px-10 sm:py-8">
        <div className="pointer-events-auto">
          <CornerReturn label="Back" onClick={() => goBack()} />
        </div>
        <ViewHeader
          eyebrow="CARIO / 01"
          title="Explore"
          subtitle="Discover machines, generations and marques."
        />
        {/* Search input */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="pointer-events-auto relative w-56 sm:w-64"
        >
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-cario-soft-gray/50" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search cars…"
            className="w-full rounded-full border border-white/10 bg-black/40 py-2 pl-9 pr-7 text-[12px] text-cario-light-gray backdrop-blur-md transition-colors placeholder:text-cario-soft-gray/40 focus:border-white/25 focus:outline-none"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-cario-soft-gray transition-colors hover:text-cario-white"
              aria-label="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </motion.div>
      </div>

      {/* Top-right: sort + filters in a legible backdrop panel. Positioned
          below the shell's settings gear and capped in width so long chip
          rows wrap inside the column instead of running over the title. */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
        className="absolute right-6 top-[220px] z-10 flex max-w-[92vw] flex-col items-end gap-2.5 rounded-2xl border border-white/5 bg-[#050608]/55 px-4 py-3.5 backdrop-blur-md sm:right-10 sm:top-20 sm:px-5 lg:max-w-[640px]"
      >
        <div className="flex items-center gap-4">
          {/* Sort dropdown */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
              Sort
            </span>
            <SortControl value={sort} onChange={(v) => setSort(v)} />
          </div>
          <span className="h-3 w-px bg-white/10" />
          <span className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/60">
            Filter · {visible.length} of {VEHICLES.length}
          </span>
        </div>
        <FilterRow label="Brands" options={BRANDS} value={filter.brand} onChange={(v) => setFilter((f) => ({ ...f, brand: v }))} />
        <FilterRow
          label="Generations"
          options={GENERATIONS}
          value={filter.generation}
          onChange={(v) => setFilter((f) => ({ ...f, generation: v }))}
        />
        <FilterRow
          label="Type"
          options={TYPES}
          value={filter.type}
          onChange={(v) => setFilter((f) => ({ ...f, type: v as VehicleType }))}
        />
        <FilterRow
          label="Era"
          options={ERAS}
          value={filter.era}
          onChange={(v) => setFilter((f) => ({ ...f, era: v as VehicleEra }))}
        />
      </motion.div>

      {/* Bottom hint */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex justify-center pb-6">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/50"
        >
          Orbit the showroom · Click a vehicle to enter
        </motion.div>
      </div>

      {/* Empty state */}
      {visible.length === 0 && (
        <div className="absolute inset-0 z-10 flex items-center justify-center">
          <button
            onClick={() => { setFilter({}); setSearch(""); }}
            className="flex flex-col items-center gap-2 text-cario-soft-gray transition-colors hover:text-cario-white"
          >
            <span className="font-display text-sm">
              {search ? `No results for "${search}"` : "No vehicles match these filters"}
            </span>
            <span className="font-mono text-[10px] uppercase tracking-label">
              {search ? "Clear search" : "Reset filters"}
            </span>
          </button>
        </div>
      )}
    </motion.div>
  );
}

function FilterRow({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: string[];
  value?: string;
  onChange: (v: string | undefined) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-20 text-right font-mono text-[9px] uppercase tracking-label text-cario-soft-gray/70">
        {label}
      </span>
      <div className="flex flex-wrap justify-end gap-1.5">
        <Chip active={!value} onClick={() => onChange(undefined)}>
          All
        </Chip>
        {options.map((o) => (
          <Chip key={o} active={value === o} onClick={() => onChange(value === o ? undefined : o)}>
            {o}
          </Chip>
        ))}
      </div>
    </div>
  );
}

function Chip({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 py-1 text-[10px] uppercase tracking-label transition-all duration-300 active:scale-[0.94]",
        active
          ? "border-white/25 bg-white/10 text-cario-white"
          : "border-white/8 text-cario-soft-gray hover:border-white/15 hover:text-cario-light-gray"
      )}
    >
      {children}
    </button>
  );
}

function SortControl({
  value,
  onChange,
}: {
  value: "default" | "power" | "year" | "name";
  onChange: (v: "default" | "power" | "year" | "name") => void;
}) {
  const opts: { v: typeof value; label: string }[] = [
    { v: "default", label: "Default" },
    { v: "power", label: "Power" },
    { v: "year", label: "Year" },
    { v: "name", label: "Name" },
  ];
  return (
    <div className="flex rounded-md border border-white/8 bg-white/[0.02] p-0.5">
      {opts.map((o) => (
        <button
          key={o.v}
          type="button"
          onClick={() => onChange(o.v)}
          className={cn(
            "rounded-[5px] px-2 py-1 text-[10px] uppercase tracking-label transition-all duration-300 active:scale-[0.94]",
            value === o.v
              ? "bg-white/10 text-cario-white"
              : "text-cario-soft-gray hover:text-cario-light-gray"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

