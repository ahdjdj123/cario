import { IDENTIFY_QUESTIONS, VEHICLES } from "./vehicles";
import type { IdentifyQuestion, Vehicle } from "./types";

export * from "./types";
export * from "./rims";
export { VEHICLES, IDENTIFY_QUESTIONS };

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

export function getVehicle(id: string | null | undefined): Vehicle | undefined {
  if (!id) return undefined;
  return VEHICLES.find((v) => v.id === id);
}

/** The default hero vehicle shown in the garage on first launch. */
export const HERO_VEHICLE_ID = "porsche-911-gt3rs-992";

export function getHeroVehicle(): Vehicle {
  return getVehicle(HERO_VEHICLE_ID)!;
}

export const BRANDS = Array.from(new Set(VEHICLES.map((v) => v.brand))).sort();
export const GENERATIONS = Array.from(new Set(VEHICLES.map((v) => `${v.brand} · ${v.generation}`))).sort();
export const TYPES = Array.from(new Set(VEHICLES.map((v) => v.type)));
export const ERAS = Array.from(new Set(VEHICLES.map((v) => v.era)));

/** Pick a random vehicle, optionally excluding one id. */
export function randomVehicle(excludeId?: string | null): Vehicle {
  const pool = excludeId ? VEHICLES.filter((v) => v.id !== excludeId) : VEHICLES;
  return pool[Math.floor(Math.random() * pool.length)];
}

/** Pick N random identify questions, shuffled. */
export function pickIdentifyQuestions(n = 10): IdentifyQuestion[] {
  const list = [...IDENTIFY_QUESTIONS];
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list.slice(0, n);
}
