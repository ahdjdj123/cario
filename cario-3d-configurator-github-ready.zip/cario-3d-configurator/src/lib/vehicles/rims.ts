/**
 * CARIO Wheel Atelier — rim styles & finishes
 * ------------------------------------------------------------
 * The second customization dimension of the configurator (next to
 * paint). Styles are procedural spoke layouts rendered by the
 * Level-1 RawCar wheel builder; finishes are rim material
 * recipes. Both are chosen per vehicle in the Wheel Studio and
 * persisted in the store (`activeRimStyleId` / `activeRimFinishId`).
 */

export type RimStyleId =
  | "turbine"   // 10-spoke Y-branch (the signature look, default)
  | "multi"     // 5 twin-spoke pairs
  | "mesh"      // cross-hatched lattice
  | "aero"      // sealed disc with slots
  | "splitter"; // 5 wide architectural spokes

export interface RimStyle {
  id: RimStyleId;
  name: string;
  /** One-line descriptor shown as the chip tooltip */
  hint: string;
}

export const RIM_STYLES: RimStyle[] = [
  { id: "turbine", name: "Turbine", hint: "Ten paired Y-spokes — the signature CARIO forged wheel" },
  { id: "multi", name: "Multi-10", hint: "Five twin-spoke pairs, classic motorsport" },
  { id: "mesh", name: "Mesh", hint: "Cross-hatched lattice, endurance-racer heritage" },
  { id: "aero", name: "Aero Disc", hint: "Sealed disc with cooling slots — low-drag special" },
  { id: "splitter", name: "Splitter", hint: "Five wide architectural spokes" },
];

export type RimFinishId = "silver" | "gunmetal" | "gloss-black" | "bronze";

export interface RimFinish {
  id: RimFinishId;
  name: string;
  /** Base hex for the rim material and UI swatches */
  hex: string;
  metalness: number;
  roughness: number;
}

export const RIM_FINISHES: RimFinish[] = [
  { id: "silver", name: "Brushed Silver", hex: "#C9CBD0", metalness: 0.95, roughness: 0.24 },
  { id: "gunmetal", name: "Gunmetal", hex: "#4A4E55", metalness: 0.9, roughness: 0.3 },
  { id: "gloss-black", name: "Gloss Black", hex: "#0B0C0E", metalness: 0.82, roughness: 0.14 },
  { id: "bronze", name: "Frozen Bronze", hex: "#9A6B2F", metalness: 0.95, roughness: 0.28 },
];

export const DEFAULT_RIM_STYLE: RimStyleId = "turbine";
export const DEFAULT_RIM_FINISH: RimFinishId = "silver";

export function getRimStyle(id: string | undefined): RimStyle {
  return RIM_STYLES.find((s) => s.id === id) ?? RIM_STYLES[0];
}

export function getRimFinish(id: string | undefined): RimFinish {
  return RIM_FINISHES.find((f) => f.id === id) ?? RIM_FINISHES[0];
}
