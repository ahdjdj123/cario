/**
 * CARIO Driver Rating — grade a driver by their best genuine
 * reaction time (solo standing launches, AI pilot excluded).
 * Shared by the drag-race setup career line and the Stats view.
 */
export interface DriverGrade {
  grade: string;
  name: string;
}

export function driverGrade(bestRt: number | null): DriverGrade {
  if (bestRt === null) return { grade: "—", name: "No launches yet" };
  if (bestRt <= 0.25) return { grade: "S", name: "Stage Elite" };
  if (bestRt <= 0.35) return { grade: "A", name: "Pro Tree" };
  if (bestRt <= 0.5) return { grade: "B", name: "Sportsman" };
  return { grade: "C", name: "Rookie" };
}
