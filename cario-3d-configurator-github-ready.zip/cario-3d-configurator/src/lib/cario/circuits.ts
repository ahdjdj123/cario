/**
 * CARIO Circuit Library
 * ------------------------------------------------------------
 * Stylized top-down outlines of four real inspired circuits
 * plus the generic CARIO test loop. Each circuit is a closed
 * polyline in normalized 0..1 space (y down, canvas-style).
 *
 * The TrackStudio draws the outline on a canvas and moves the
 * car dot along the path using arc-length parameterization, so
 * the dot keeps a constant *distance* speed regardless of
 * segment lengths.
 */

export interface Circuit {
  id: string;
  name: string;
  country: string;
  /** Real circuit length in km (used for telemetry flavour) */
  lengthKm: number;
  /** Relative difficulty factor applied to estimated lap time */
  difficulty: number;
  /** Closed polyline, normalized 0..1 */
  path: [number, number][];
}

/* ------------------------------------------------------------------ */
/* Layouts (hand-traced, stylized)                                     */
/* ------------------------------------------------------------------ */

/** Nürburgring Nordschleife — long, stretched loop with the Karussell */
const NURBURGRING: [number, number][] = [
  [0.72, 0.08], [0.78, 0.1], [0.84, 0.14], [0.88, 0.2], [0.9, 0.27],
  [0.87, 0.33], [0.82, 0.36], [0.77, 0.4], [0.74, 0.46], [0.75, 0.52],
  [0.79, 0.57], [0.84, 0.6], [0.88, 0.65], [0.87, 0.71], [0.82, 0.74],
  [0.75, 0.75], [0.68, 0.77], [0.62, 0.81], [0.57, 0.86], [0.5, 0.88],
  [0.43, 0.86], [0.38, 0.82], [0.33, 0.78], [0.27, 0.77], [0.22, 0.79],
  [0.17, 0.76], [0.14, 0.71], [0.15, 0.65], [0.19, 0.61], [0.24, 0.59],
  [0.28, 0.55], [0.29, 0.49], [0.26, 0.44], [0.22, 0.4], [0.18, 0.36],
  [0.2, 0.3], [0.26, 0.27], [0.33, 0.26], [0.39, 0.23], [0.43, 0.19],
  [0.48, 0.15], [0.55, 0.11], [0.62, 0.08], [0.68, 0.07],
];

/** Monza — fast, elongated loop with the Parabolica */
const MONZA: [number, number][] = [
  [0.2, 0.12], [0.35, 0.09], [0.52, 0.08], [0.68, 0.09], [0.8, 0.12],
  [0.85, 0.17], [0.84, 0.24], [0.79, 0.28], [0.72, 0.3], [0.76, 0.36],
  [0.8, 0.42], [0.78, 0.48], [0.72, 0.51], [0.66, 0.5], [0.62, 0.54],
  [0.63, 0.6], [0.68, 0.64], [0.74, 0.66], [0.79, 0.7], [0.78, 0.76],
  [0.71, 0.81], [0.6, 0.85], [0.47, 0.87], [0.34, 0.85], [0.24, 0.8],
  [0.18, 0.74], [0.16, 0.66], [0.18, 0.58], [0.22, 0.5], [0.24, 0.42],
  [0.22, 0.34], [0.19, 0.26], [0.17, 0.19],
];

/** Suzuka — the famous figure-eight (crossover at the center) */
const SUZUKA: [number, number][] = [
  [0.3, 0.12], [0.42, 0.09], [0.55, 0.1], [0.65, 0.14], [0.72, 0.2],
  [0.76, 0.28], [0.74, 0.36], [0.68, 0.41], [0.6, 0.44], [0.55, 0.49],
  [0.56, 0.55], [0.61, 0.59], [0.68, 0.62], [0.73, 0.67], [0.73, 0.74],
  [0.67, 0.8], [0.58, 0.84], [0.48, 0.86], [0.38, 0.84], [0.3, 0.79],
  [0.26, 0.72], [0.28, 0.65], [0.34, 0.6], [0.41, 0.57], [0.46, 0.52],
  [0.45, 0.46], [0.39, 0.42], [0.32, 0.39], [0.27, 0.34], [0.26, 0.27],
  [0.27, 0.19],
];

/** CARIO test loop — the original stylized oval with a chicane */
const CARIO_LOOP: [number, number][] = [
  [0.24, 0.2], [0.4, 0.14], [0.6, 0.12], [0.76, 0.16], [0.84, 0.24],
  [0.86, 0.36], [0.82, 0.5], [0.76, 0.62], [0.68, 0.74], [0.54, 0.82],
  [0.4, 0.84], [0.28, 0.78], [0.2, 0.66], [0.16, 0.52], [0.16, 0.36],
  [0.18, 0.26],
];

export const CIRCUITS: Circuit[] = [
  {
    id: "cario-loop",
    name: "CARIO Loop",
    country: "Test Facility",
    lengthKm: 5.2,
    difficulty: 1,
    path: CARIO_LOOP,
  },
  {
    id: "monza",
    name: "Monza",
    country: "Italy",
    lengthKm: 5.793,
    difficulty: 0.92,
    path: MONZA,
  },
  {
    id: "suzuka",
    name: "Suzuka",
    country: "Japan",
    lengthKm: 5.807,
    difficulty: 1.06,
    path: SUZUKA,
  },
  {
    id: "nurburgring",
    name: "Nürburgring",
    country: "Germany",
    lengthKm: 20.832,
    difficulty: 1.35,
    path: NURBURGRING,
  },
];

export function getCircuit(id: string): Circuit {
  return CIRCUITS.find((c) => c.id === id) ?? CIRCUITS[0];
}

/* ------------------------------------------------------------------ */
/* Geometry — arc-length parameterization over a closed polyline       */
/* ------------------------------------------------------------------ */

export interface CompiledPath {
  /** absolute segment start positions (cumulative length) */
  starts: number[];
  totalLength: number;
}

export function compilePath(path: [number, number][]): CompiledPath {
  const starts: number[] = [0];
  let total = 0;
  for (let i = 0; i < path.length; i++) {
    const a = path[i];
    const b = path[(i + 1) % path.length];
    total += Math.hypot(b[0] - a[0], b[1] - a[1]);
    starts.push(total);
  }
  return { starts, totalLength: total };
}

/** Position at parameter t (0..1) by arc length, in normalized space. */
export function pointAt(
  path: [number, number][],
  compiled: CompiledPath,
  t: number
): [number, number] {
  const target = (((t % 1) + 1) % 1) * compiled.totalLength;
  const { starts } = compiled;
  // binary search for the segment
  let lo = 0;
  let hi = starts.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (starts[mid + 1] <= target) lo = mid + 1;
    else hi = mid;
  }
  const a = path[lo];
  const b = path[(lo + 1) % path.length];
  const segLen = starts[lo + 1] - starts[lo] || 1;
  const f = (target - starts[lo]) / segLen;
  return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f];
}

/** Local tightness 0..1 at parameter t — high values = tighter turn. */
export function curvatureAt(
  path: [number, number][],
  compiled: CompiledPath,
  t: number,
  window: number
): number {
  const a = pointAt(path, compiled, t - window);
  const b = pointAt(path, compiled, t);
  const c = pointAt(path, compiled, t + window);
  const v1x = b[0] - a[0];
  const v1y = b[1] - a[1];
  const v2x = c[0] - b[0];
  const v2y = c[1] - b[1];
  const l1 = Math.hypot(v1x, v1y) || 1e-6;
  const l2 = Math.hypot(v2x, v2y) || 1e-6;
  const dot = (v1x / l1) * (v2x / l2) + (v1y / l1) * (v2y / l2);
  // angle between segments (0 = straight, 1 = hairpin)
  return Math.min(1, Math.max(0, Math.acos(Math.min(1, Math.max(-1, dot))) / Math.PI * 2));
}
