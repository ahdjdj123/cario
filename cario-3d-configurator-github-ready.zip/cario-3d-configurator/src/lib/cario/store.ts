"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  HERO_VEHICLE_ID,
  getVehicle,
  randomVehicle,
  type Vehicle,
} from "@/lib/vehicles";
import { DEFAULT_ATMOSPHERE } from "@/lib/vehicles/atmosphere";
import { DEFAULT_RIM_FINISH, DEFAULT_RIM_STYLE } from "@/lib/vehicles/rims";
import type { AtmospherePresetId } from "@/lib/vehicles/types";
import type { RimFinishId, RimStyleId } from "@/lib/vehicles/rims";

/**
 * CARIO application state.
 * The whole experience lives on a single route. Navigation is modelled
 * as a stack of "views" with smooth transitions orchestrated by the shell.
 */

export type CarioView =
  | "intro"
  | "home"
  | "explore"
  | "random"
  | "identify"
  | "experience"
  | "compare"
  | "favorites"
  | "stats"
  | "achievements";

export type CarioCameraMode =
  | "exterior"
  | "interior"
  | "engine";

export interface CarioSettings {
  /** Visual quality of the 3D scene */
  renderQuality: "performance" | "balanced" | "cinematic";
  /** Whether the cinematic intro plays on launch */
  playIntro: boolean;
  /** Auto-rotate the hero car when idle */
  autoRotate: boolean;
  /** Show the fine grain overlay */
  grain: boolean;
  /** Reduce motion for accessibility */
  reduceMotion: boolean;
  /** Show extra telemetry (weight, drivetrain) */
  verboseSpecs: boolean;
  /** Master audio volume (0–1) — scales the Sound Studio engine note
   *  and the Atmosphere ambience bed together */
  masterVolume: number;
}

/* --- Toasts (transient feedback, not persisted) --- */

export type ToastKind = "heart" | "timer" | "copy" | "info" | "trophy";

export interface CarioToast {
  id: number;
  message: string;
  kind: ToastKind;
}

/* --- Identify mini-game difficulty --- */

export type IdentifyDifficulty = "sprint" | "grand-tour" | "endurance";

export const IDENTIFY_DIFFICULTIES: Record<
  IdentifyDifficulty,
  { label: string; rounds: number; hint: string }
> = {
  sprint: { label: "Sprint", rounds: 10, hint: "Quick fire" },
  "grand-tour": { label: "Grand Tour", rounds: 15, hint: "The longer circuit" },
  endurance: { label: "Endurance", rounds: 20, hint: "Every detail counts" },
};

export interface CarioState {
  /* --- Navigation --- */
  view: CarioView;
  /** Previous view — used for elegant "back" behaviour */
  previousView: CarioView | null;
  /** A short stack so CONTINUE / back behave predictably */
  history: CarioView[];

  /* --- Vehicles --- */
  selectedVehicleId: string;
  /** The last vehicle the user explored, for CONTINUE */
  lastVehicleId: string | null;
  /** Recently viewed vehicle IDs (most recent first, max 6) */
  recentIds: string[];
  /** Currently active paint colour id (per vehicle, keyed by id) */
  activeColorId: Record<string, string>;
  /** Currently active rim style id (per vehicle, keyed by id) — Wheel Atelier */
  activeRimStyleId: Record<string, string>;
  /** Currently active rim finish id (per vehicle, keyed by id) — Wheel Atelier */
  activeRimFinishId: Record<string, string>;
  /** Vehicle IDs selected for side-by-side comparison (max 3) */
  compareIds: string[];
  /** Bookmarked/favorited vehicle IDs (the user's personal garage) */
  favoriteIds: string[];

  /* --- Car Experience sub-state --- */
  cameraMode: CarioCameraMode;
  /** Active atmosphere preset (environment switcher) */
  atmosphereId: AtmospherePresetId;

  /* --- Identify mini-game --- */
  identifyScore: number;
  identifyBestScore: number;
  identifyTotalRuns: number;
  /** Last chosen difficulty (persisted) */
  identifyDifficulty: IdentifyDifficulty;
  /** Best score per difficulty (persisted) */
  identifyBestByMode: Record<IdentifyDifficulty, number>;

  /* --- Track telemetry --- */
  /** Personal best lap time in ms, keyed by `${vehicleId}:${circuitId}` */
  bestLaps: Record<string, number>;

  /* --- Milestones / achievements --- */
  /** Every vehicle the user has entered the experience of (unbounded, ordered) */
  exploredIds: string[];
  /** Unique atmosphere presets the user has switched to */
  atmospheresTried: AtmospherePresetId[];
  /** Achievement ids already toasted/seen. null = baseline not yet taken
   *  (first run after install marks everything currently unlocked silently) */
  seenAchievements: string[] | null;
  /** Head-to-head drag races started (Compare view) */
  dragRacesRun: number;
  /** Head-to-head drag races won by the user's picked lane */
  dragWins: number;
  /* --- Driver career (drag race reaction game) --- */
  /** Best GENUINE reaction time in seconds (solo standing launches; AI pilot excluded) */
  bestReaction: number | null;
  /** Sum/count of genuine solo reaction times — career average */
  reactionSum: number;
  reactionCount: number;
  /** Career red-light DQs (solo standing) */
  redLights: number;
  /** Hot-seat (2-player) duels completed */
  hotSeatRaces: number;
  /** Endurance series (best-of-5) completed */
  enduranceSeries: number;
  /** Endurance series taken by the player */
  enduranceWins: number;

  /* --- Toasts (transient, not persisted) --- */
  toasts: CarioToast[];
  pushToast: (message: string, kind?: ToastKind) => void;
  dismissToast: (id: number) => void;

  /* --- Settings --- */
  settings: CarioSettings;

  /* --- Intro --- */
  introCompleted: boolean;

  /* --- Actions --- */
  setView: (view: CarioView) => void;
  goBack: () => void;
  selectVehicle: (id: string) => void;
  setColor: (vehicleId: string, colorId: string) => void;
  /** Wheel Atelier — set the rim style for a vehicle */
  setRimStyle: (vehicleId: string, styleId: RimStyleId) => void;
  /** Wheel Atelier — set the rim finish for a vehicle */
  setRimFinish: (vehicleId: string, finishId: RimFinishId) => void;
  setCameraMode: (mode: CarioCameraMode) => void;
  setAtmosphere: (id: AtmospherePresetId) => void;
  completeIntro: () => void;
  continueLast: () => void;
  rollRandom: () => Vehicle;
  recordIdentifyResult: (score: number, mode?: IdentifyDifficulty) => void;
  /** Remember the chosen difficulty for the next run */
  setIdentifyDifficulty: (mode: IdentifyDifficulty) => void;
  /** Record a personal best lap (ms) — kept only if it improves the current best */
  recordBestLap: (key: string, ms: number) => void;
  /** Mark achievement ids as seen (silently acknowledged) */
  markAchievementsSeen: (ids: string[]) => void;
  /** Record a completed drag race (winner id; null = dead heat).
   *  meta.playerRt — the solo player's genuine reaction (s) on a standing
   *  launch (null when the AI pilot launched); meta.redLight — the solo
   *  player red-lit; meta.hotSeat — 2-player duel (no solo win credit). */
  recordDragRace: (
    winnerId: string | null,
    meta?: { playerRt?: number | null; redLight?: boolean; hotSeat?: boolean }
  ) => void;
  /** Record a completed endurance series (best-of-5); won = the player
   *  took the meeting (3 rounds or more). */
  recordEnduranceSeries: (won: boolean) => void;
  /** Wipe every personal best / course record (leaderboard reset) */
  clearBestLaps: () => void;
  /** Deep-link entry: like selectVehicle but replaces (not pushes) the
   *  intro view, so Esc/back from the experience lands on the garage. */
  selectVehicleDeepLink: (id: string) => void;
  updateSettings: (patch: Partial<CarioSettings>) => void;
  /** Toggle a vehicle in the comparison set (max 3) */
  toggleCompare: (id: string) => void;
  /** Clear the comparison set */
  clearCompare: () => void;
  /** Toggle a vehicle in the favorites/personal garage */
  toggleFavorite: (id: string) => void;
}

const DEFAULT_SETTINGS: CarioSettings = {
  renderQuality: "balanced",
  playIntro: true,
  autoRotate: true,
  grain: true,
  reduceMotion: false,
  verboseSpecs: false,
  masterVolume: 1,
};

export const useCario = create<CarioState>()(
  persist(
    (set, get) => ({
      view: "intro",
      previousView: null,
      history: [],

      selectedVehicleId: HERO_VEHICLE_ID,
      lastVehicleId: null,
      recentIds: [],
      activeColorId: {},
      activeRimStyleId: {},
      activeRimFinishId: {},
      compareIds: [],
      favoriteIds: [],

      cameraMode: "exterior",
      atmosphereId: DEFAULT_ATMOSPHERE,

      identifyScore: 0,
      identifyBestScore: 0,
      identifyTotalRuns: 0,
      identifyDifficulty: "sprint",
      identifyBestByMode: { sprint: 0, "grand-tour": 0, endurance: 0 },

      bestLaps: {},

      exploredIds: [],
      atmospheresTried: [],
      seenAchievements: null,
      dragRacesRun: 0,
      dragWins: 0,
      bestReaction: null,
      reactionSum: 0,
      reactionCount: 0,
      redLights: 0,
      hotSeatRaces: 0,
      enduranceSeries: 0,
      enduranceWins: 0,

      toasts: [],
      pushToast: (message, kind = "info") =>
        set((s) => {
          const toast: CarioToast = {
            id: Date.now() + Math.floor(Math.random() * 1000),
            message,
            kind,
          };
          // Keep at most 3 stacked toasts
          return { toasts: [...s.toasts, toast].slice(-3) };
        }),
      dismissToast: (id) =>
        set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),

      settings: DEFAULT_SETTINGS,
      introCompleted: false,

      setView: (view) =>
        set((s) => {
          if (view === s.view) return {};
          return {
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
            view,
          };
        }),

      goBack: () =>
        set((s) => {
          const history = [...s.history];
          const prev = history.pop();
          if (!prev) return { view: "home", history, previousView: null };
          return { view: prev, history, previousView: s.view };
        }),

      selectVehicle: (id) =>
        set((s) => {
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [id, ...s.recentIds.filter((x) => x !== id)].slice(0, 6);
          // Track every car ever explored (milestones) — unbounded, ordered
          const exploredIds = s.exploredIds.includes(id)
            ? s.exploredIds
            : [...s.exploredIds, id];
          return {
            selectedVehicleId: id,
            lastVehicleId: id,
            recentIds,
            exploredIds,
            cameraMode: "exterior",
            view: "experience",
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
          };
        }),

      setColor: (vehicleId, colorId) =>
        set((s) => ({
          activeColorId: { ...s.activeColorId, [vehicleId]: colorId },
        })),

      setRimStyle: (vehicleId, styleId) =>
        set((s) => ({
          activeRimStyleId: { ...s.activeRimStyleId, [vehicleId]: styleId },
        })),

      setRimFinish: (vehicleId, finishId) =>
        set((s) => ({
          activeRimFinishId: { ...s.activeRimFinishId, [vehicleId]: finishId },
        })),

      setCameraMode: (mode) => set({ cameraMode: mode }),

      setAtmosphere: (id) =>
        set((s) => ({
          atmosphereId: id,
          atmospheresTried: s.atmospheresTried.includes(id)
            ? s.atmospheresTried
            : [...s.atmospheresTried, id],
        })),

      completeIntro: () =>
        set((s) =>
          // Only navigate if the user is still watching the intro. If they
          // already moved on (e.g. deep-linked into a car, then Esc'd back
          // through the intro), a pending auto-advance timer must NOT
          // teleport them home mid-browse.
          s.view === "intro"
            ? { introCompleted: true, view: "home" }
            : { introCompleted: true }
        ),

      continueLast: () =>
        set((s) => {
          const id = s.lastVehicleId ?? s.selectedVehicleId;
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [id, ...s.recentIds.filter((x) => x !== id)].slice(0, 6);
          const exploredIds = s.exploredIds.includes(id)
            ? s.exploredIds
            : [...s.exploredIds, id];
          return {
            selectedVehicleId: id,
            recentIds,
            exploredIds,
            cameraMode: "exterior",
            view: "experience",
            previousView: s.view,
            history: [...s.history, s.view].slice(-8),
          };
        }),

      rollRandom: () => {
        const v = randomVehicle(get().selectedVehicleId);
        set((s) => {
          // Track recently viewed (most recent first, no duplicates, max 6)
          const recentIds = [v.id, ...s.recentIds.filter((x) => x !== v.id)].slice(0, 6);
          return {
            selectedVehicleId: v.id,
            lastVehicleId: v.id,
            recentIds,
            cameraMode: "exterior",
          };
        });
        return v;
      },

      recordIdentifyResult: (score, mode) =>
        set((s) => ({
          identifyScore: score,
          identifyBestScore: Math.max(s.identifyBestScore, score),
          identifyTotalRuns: s.identifyTotalRuns + 1,
          identifyBestByMode: mode
            ? {
                ...s.identifyBestByMode,
                [mode]: Math.max(s.identifyBestByMode[mode] ?? 0, score),
              }
            : s.identifyBestByMode,
        })),

      setIdentifyDifficulty: (mode) => set({ identifyDifficulty: mode }),

      recordBestLap: (key, ms) =>
        set((s) => {
          const current = s.bestLaps[key];
          if (current !== undefined && current <= ms) return {};
          return { bestLaps: { ...s.bestLaps, [key]: ms } };
        }),

      markAchievementsSeen: (ids) =>
        set((s) => {
          const base = s.seenAchievements ?? [];
          const merged = [...new Set([...base, ...ids])];
          if (merged.length === base.length) return {};
          return { seenAchievements: merged };
        }),

      recordDragRace: (winnerId, meta) =>
        set((s) => {
          const rt = typeof meta?.playerRt === "number" ? meta.playerRt : null;
          return {
            dragRacesRun: s.dragRacesRun + 1,
            // Solo wins only — a hot-seat duel has no solo driver credit
            dragWins: winnerId && !meta?.hotSeat ? s.dragWins + 1 : s.dragWins,
            bestReaction:
              rt !== null
                ? s.bestReaction === null
                  ? rt
                  : Math.min(s.bestReaction, rt)
                : s.bestReaction,
            reactionSum: rt !== null ? s.reactionSum + rt : s.reactionSum,
            reactionCount: rt !== null ? s.reactionCount + 1 : s.reactionCount,
            redLights: meta?.redLight ? s.redLights + 1 : s.redLights,
            hotSeatRaces: meta?.hotSeat ? s.hotSeatRaces + 1 : s.hotSeatRaces,
          };
        }),

      recordEnduranceSeries: (won) =>
        set((s) => ({
          enduranceSeries: s.enduranceSeries + 1,
          enduranceWins: s.enduranceWins + (won ? 1 : 0),
        })),

      clearBestLaps: () => set({ bestLaps: {} }),

      selectVehicleDeepLink: (id) =>
        set((s) => ({
          selectedVehicleId: id,
          lastVehicleId: id,
          recentIds: [id, ...s.recentIds.filter((x) => x !== id)].slice(0, 6),
          exploredIds: s.exploredIds.includes(id)
            ? s.exploredIds
            : [...s.exploredIds, id],
          cameraMode: "exterior",
          view: "experience",
          previousView: null,
          history: [],
        })),

      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),

      toggleCompare: (id) =>
        set((s) => {
          if (s.compareIds.includes(id)) {
            // Remove if already in the set
            return { compareIds: s.compareIds.filter((x) => x !== id) };
          }
          // Add if room (max 3)
          if (s.compareIds.length >= 3) return {};
          return { compareIds: [...s.compareIds, id] };
        }),

      clearCompare: () => set({ compareIds: [] }),

      toggleFavorite: (id) =>
        set((s) => {
          if (s.favoriteIds.includes(id)) {
            return { favoriteIds: s.favoriteIds.filter((x) => x !== id) };
          }
          return { favoriteIds: [...s.favoriteIds, id] };
        }),
    }),
    {
      name: "cario-state-v1",
      // Only persist user-meaningful fields, not the transient view/intro state
      partialize: (s) => ({
        lastVehicleId: s.lastVehicleId,
        recentIds: s.recentIds,
        activeColorId: s.activeColorId,
        activeRimStyleId: s.activeRimStyleId,
        activeRimFinishId: s.activeRimFinishId,
        atmosphereId: s.atmosphereId,
        compareIds: s.compareIds,
        favoriteIds: s.favoriteIds,
        identifyBestScore: s.identifyBestScore,
        identifyTotalRuns: s.identifyTotalRuns,
        identifyDifficulty: s.identifyDifficulty,
        identifyBestByMode: s.identifyBestByMode,
        bestLaps: s.bestLaps,
        exploredIds: s.exploredIds,
        atmospheresTried: s.atmospheresTried,
        seenAchievements: s.seenAchievements,
        dragRacesRun: s.dragRacesRun,
        dragWins: s.dragWins,
        bestReaction: s.bestReaction,
        reactionSum: s.reactionSum,
        reactionCount: s.reactionCount,
        redLights: s.redLights,
        hotSeatRaces: s.hotSeatRaces,
        enduranceSeries: s.enduranceSeries,
        enduranceWins: s.enduranceWins,
        settings: s.settings,
      }),
    }
  )
);

/* --- Convenience selectors / hooks --- */

export function useActiveColor(vehicle: Vehicle) {
  return useCario((s) => {
    const id = s.activeColorId[vehicle.id];
    if (id) {
      const c = vehicle.colors.find((c) => c.id === id);
      if (c) return c;
    }
    return vehicle.colors[0];
  });
}

/** Active Wheel Atelier selection for a vehicle (style + finish).
 *  Returns stable primitives so callers can resolve the catalog
 *  objects without breaking snapshot caching. */
export function useActiveRim(vehicle: Vehicle): {
  styleId: RimStyleId;
  finishId: RimFinishId;
} {
  const styleId = useCario(
    (s) => (s.activeRimStyleId[vehicle.id] as RimStyleId) ?? DEFAULT_RIM_STYLE
  );
  const finishId = useCario(
    (s) => (s.activeRimFinishId[vehicle.id] as RimFinishId) ?? DEFAULT_RIM_FINISH
  );
  return { styleId, finishId };
}

export function useSelectedVehicle(): Vehicle {
  return useCario((s) => getVehicle(s.selectedVehicleId)!);
}

/* QA/debug handle — lets browser automation read the live store
   (drag-race telemetry, milestone state) without UI round-trips. */
if (typeof window !== "undefined") {
  (window as unknown as { __cario?: typeof useCario }).__cario = useCario;
}
