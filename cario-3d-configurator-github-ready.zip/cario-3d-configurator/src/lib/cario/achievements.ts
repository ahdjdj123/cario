import {
  Activity,
  CircleDot,
  Compass,
  Droplet,
  Flag,
  Footprints,
  Gauge,
  Heart,
  Hourglass,
  Layers,
  Lightbulb,
  Map,
  Medal,
  Palette,
  Route,
  SignpostBig,
  Sparkles,
  Swords,
  Timer,
  Trophy,
  type LucideIcon,
} from "lucide-react";
import type { CarioState } from "@/lib/cario/store";
import { VEHICLES } from "@/lib/vehicles";

/* ============================================================
   CARIO Milestones — a lightweight achievement system
   ------------------------------------------------------------
   Achievements are pure derived state: every definition carries
   an evaluate() function that reads the persisted store and
   returns an unlock flag plus a 0..1 progress value. Nothing is
   written back to the store except `seenAchievements` (which
   only governs toast delivery, not unlock state).

   Tiers (monochrome styling):
   - common    → the natural path through the app
   - rare      → sustained engagement
   - legendary → completionist territory
   ============================================================ */

export type AchievementTier = "common" | "rare" | "legendary";

export interface AchievementProgress {
  unlocked: boolean;
  /** 0..1 completion of the goal */
  progress: number;
  /** Human-readable progress, e.g. "3 / 5 cars" */
  label: string;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  tier: AchievementTier;
  icon: LucideIcon;
  evaluate: (s: CarioState) => AchievementProgress;
}

const clamp01 = (n: number) => Math.min(1, Math.max(0, n));
const ratio = (value: number, goal: number) => clamp01(value / goal);

function progressOf(value: number, goal: number, unit: string): AchievementProgress {
  return {
    unlocked: value >= goal,
    progress: ratio(value, goal),
    label: `${Math.min(value, goal)} / ${goal} ${unit}`,
  };
}

/* --- Shared metric helpers --- */

const exploredCount = (s: CarioState) => s.exploredIds.length;
const favoriteCount = (s: CarioState) => s.favoriteIds.length;
const repaintCount = (s: CarioState) => Object.keys(s.activeColorId).length;
const rimmedCount = (s: CarioState) => Object.keys(s.activeRimStyleId ?? {}).length;
/** Cars wearing a FULL custom livery — custom paint AND custom wheels
 *  fitted together in the same vehicle's configuration. */
const fullLiveryCount = (s: CarioState) =>
  Object.keys(s.activeColorId ?? {}).filter(
    (id) => (s.activeRimStyleId ?? {})[id] !== undefined
  ).length;
const bestIdentify = (s: CarioState) =>
  Math.max(0, ...Object.values(s.identifyBestByMode ?? {}));
const pbKeys = (s: CarioState) => Object.keys(s.bestLaps ?? {});
const pbCircuits = (s: CarioState) =>
  new Set(pbKeys(s).map((k) => k.split(":")[1] ?? "")).size;

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: "first-contact",
    title: "First Contact",
    description: "Step into any car's experience for the first time.",
    tier: "common",
    icon: Compass,
    evaluate: (s) => progressOf(exploredCount(s), 1, "car"),
  },
  {
    id: "collection-tour",
    title: "Collection Tour",
    description: `Explore 5 different cars across the ${VEHICLES.length}-car garage.`,
    tier: "common",
    icon: Footprints,
    evaluate: (s) => progressOf(exploredCount(s), 5, "cars"),
  },
  {
    id: "full-circuit",
    title: "Full Circuit",
    description: `Enter the experience of every one of the ${VEHICLES.length} cars.`,
    tier: "legendary",
    icon: Route,
    evaluate: (s) => progressOf(exploredCount(s), VEHICLES.length, "cars"),
  },
  {
    id: "curator",
    title: "Curator",
    description: "Save 3 cars to your personal garage.",
    tier: "common",
    icon: Heart,
    evaluate: (s) => progressOf(favoriteCount(s), 3, "cars"),
  },
  {
    id: "museum-wing",
    title: "Museum Wing",
    description: "Keep 7 cars in your personal garage at once.",
    tier: "rare",
    icon: Medal,
    evaluate: (s) => progressOf(favoriteCount(s), 7, "cars"),
  },
  {
    id: "paint-room",
    title: "Paint Room",
    description: "Repaint 3 different cars in the Colour Studio.",
    tier: "rare",
    icon: Droplet,
    evaluate: (s) => progressOf(repaintCount(s), 3, "cars"),
  },
  {
    id: "paint-collector",
    title: "Paint Collector",
    description: `Repaint 10 different cars — a third of the ${VEHICLES.length}-car collection, each in its own colour.`,
    tier: "legendary",
    icon: Palette,
    evaluate: (s) => progressOf(repaintCount(s), 10, "cars"),
  },
  {
    id: "wheel-whisperer",
    title: "Wheel Whisperer",
    description: "Fit custom wheels on 5 different cars in the Wheel Atelier.",
    tier: "rare",
    icon: CircleDot,
    evaluate: (s) => progressOf(rimmedCount(s), 5, "cars"),
  },
  {
    id: "full-livery",
    title: "Full Livery",
    description:
      "Fit a complete custom look — paint and wheels together — on 5 different cars.",
    tier: "legendary",
    icon: Layers,
    evaluate: (s) => progressOf(fullLiveryCount(s), 5, "cars"),
  },
  {
    id: "storm-chaser",
    title: "Storm Chaser",
    description: "Switch between 3 different atmosphere presets.",
    tier: "common",
    icon: Lightbulb,
    evaluate: (s) => progressOf(s.atmospheresTried.length, 3, "moods"),
  },
  {
    id: "quiz-rookie",
    title: "Quiz Rookie",
    description: "Complete your first Identify run.",
    tier: "common",
    icon: Sparkles,
    evaluate: (s) => progressOf(s.identifyTotalRuns, 1, "run"),
  },
  {
    id: "trivia-scholar",
    title: "Trivia Scholar",
    description: "Score 10 or better in any Identify discipline.",
    tier: "rare",
    icon: Map,
    evaluate: (s) => progressOf(bestIdentify(s), 10, "points"),
  },
  {
    id: "pocket-genius",
    title: "Pocket Genius",
    description: "A perfect 10/10 in the Sprint discipline.",
    tier: "legendary",
    icon: Trophy,
    evaluate: (s) => progressOf(bestIdentify(s) >= 10 ? 1 : 0, 1, "perfect"),
  },
  {
    id: "endurance-driver",
    title: "Endurance Driver",
    description: "Complete 10 Identify runs across any disciplines.",
    tier: "rare",
    icon: Hourglass,
    evaluate: (s) => progressOf(s.identifyTotalRuns, 10, "runs"),
  },
  {
    id: "track-day",
    title: "Track Day",
    description: "Set a personal best on any circuit.",
    tier: "common",
    icon: Timer,
    evaluate: (s) => progressOf(pbKeys(s).length, 1, "lap"),
  },
  {
    id: "lap-artist",
    title: "Lap Artist",
    description: "Hold personal bests on 3 different circuits.",
    tier: "rare",
    icon: Gauge,
    evaluate: (s) => progressOf(pbCircuits(s), 3, "circuits"),
  },
  {
    id: "grid-master",
    title: "Grid Master",
    description: "Hold a personal best on every available circuit.",
    tier: "legendary",
    icon: SignpostBig,
    evaluate: (s) => progressOf(pbCircuits(s), 4, "circuits"),
  },
  {
    id: "winners-circle",
    title: "Winner's Circle",
    description: "Win 3 head-to-head drag races.",
    tier: "rare",
    icon: Flag,
    evaluate: (s) => progressOf(s.dragWins, 3, "wins"),
  },
  {
    id: "duelist",
    title: "Duelist",
    description: "Settle a head-to-head in Hot Seat mode — two drivers, one tree.",
    tier: "common",
    icon: Swords,
    evaluate: (s) => progressOf(s.hotSeatRaces, 1, "duel"),
  },
  {
    id: "marathon",
    title: "Marathon",
    description:
      "Complete 3 Endurance drag series — best-of-5 meetings where every round chews the tyres.",
    tier: "rare",
    icon: Activity,
    evaluate: (s) => progressOf(s.enduranceSeries, 3, "series"),
  },
];

export interface ComputedAchievement {
  def: AchievementDef;
  unlocked: boolean;
  progress: number;
  label: string;
}

/** Evaluate every definition against a store snapshot. */
export function computeAchievements(s: CarioState): ComputedAchievement[] {
  return ACHIEVEMENTS.map((def) => {
    const r = def.evaluate(s);
    return { def, unlocked: r.unlocked, progress: r.progress, label: r.label };
  });
}

/* Memoized wrapper for use as a Zustand selector. The plain version
   allocates a fresh array per call, which breaks useSyncExternalStore's
   snapshot caching ("getSnapshot should be cached" → render loop).
   Keyed on the store-state identity: recomputes only when state changes. */
let memoState: CarioState | null = null;
let memoResult: ComputedAchievement[] = [];
export function computeAchievementsCached(s: CarioState): ComputedAchievement[] {
  if (s !== memoState) {
    memoState = s;
    memoResult = computeAchievements(s);
  }
  return memoResult;
}

export const TIER_LABEL: Record<AchievementTier, string> = {
  common: "Standard",
  rare: "Rare",
  legendary: "Legend",
};
