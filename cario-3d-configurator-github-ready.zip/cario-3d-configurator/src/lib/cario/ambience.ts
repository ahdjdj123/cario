import type { AtmospherePresetId } from "@/lib/vehicles/types";

/* ============================================================
   CARIO Ambience — procedural environment soundscapes
   ------------------------------------------------------------
   Companion audio layer for the Atmosphere Studio. Each
   environment preset gets a matching soundscape synthesized
   entirely from Web Audio primitives (no assets):

   - studio → faint air-handler hum (low, slow breathing)
   - dawn   → gentle breeze + scheduled birdsong chirps
   - dusk   → warm low wind + cricket chirp trains
   - night  → deep wind swells + distant sub rumble
   - rain   → rain patter bed + random droplet ticks + rumble

   Design rules (mirrors SoundStudio):
   - Created only from a user gesture (autoplay policy)
   - Subtle by construction (master kept low)
   - Preset switches crossfade (~0.8 s) instead of clicking
   - suspend()/resume() on toggle, close() on dispose
   ============================================================ */

interface WindLayer {
  src: AudioBufferSourceNode;
  filter: BiquadFilterNode;
  gain: GainNode;
  lfo?: OscillatorNode;
  lfoGain?: GainNode;
}

interface Timers {
  timers: number[];
  stopped: boolean;
}

export interface AmbienceHandle {
  setPreset: (id: AtmospherePresetId) => void;
  /** Scale the master bed (0–1) — wired to the Settings master volume */
  setVolume: (v: number) => void;
  suspend: () => void;
  resume: () => void;
  dispose: () => void;
}

const PRESET_LEVEL: Record<AtmospherePresetId, number> = {
  studio: 0.05,
  dawn: 0.09,
  dusk: 0.09,
  night: 0.08,
  rain: 0.11,
};

export function createAmbience(initial: AtmospherePresetId, initialVolume = 1): AmbienceHandle | null {
  const Ctx =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  const ctx = new Ctx();

  /* Master audio volume from Settings (0–1). Kept in a closure var so
     every (re)build of a scene levels to the current preference. */
  let volume = Math.min(Math.max(initialVolume, 0), 1);

  /* --- shared graph -------------------------------------- */
  const master = ctx.createGain();
  master.gain.value = 0;
  master.connect(ctx.destination);

  // One 2-second looping white-noise buffer shared by all beds
  const noiseBuf = makeNoiseBuffer(ctx);

  let winds: WindLayer[] = [];
  let oscillators: { osc: OscillatorNode; gain: GainNode }[] = [];
  let timers: Timers = { timers: [], stopped: false };
  let current: AtmospherePresetId = initial;

  /* --- layer builders ------------------------------------ */

  function makeWind(opts: {
    type: BiquadFilterType;
    freq: number;
    q?: number;
    gain: number;
    lfoRate?: number;
    lfoDepth?: number;
  }): WindLayer {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = opts.type;
    filter.frequency.value = opts.freq;
    filter.Q.value = opts.q ?? 0.7;

    const gain = ctx.createGain();
    gain.gain.value = 0;
    // fade the bed in over ~1.5 s
    gain.gain.setTargetAtTime(opts.gain, ctx.currentTime, 0.7);

    src.connect(filter).connect(gain).connect(master);
    src.start();

    const layer: WindLayer = { src, filter, gain };
    if (opts.lfoRate && opts.lfoDepth) {
      const lfo = ctx.createOscillator();
      lfo.frequency.value = opts.lfoRate;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = opts.freq * opts.lfoDepth;
      lfo.connect(lfoGain).connect(filter.frequency);
      lfo.start();
      layer.lfo = lfo;
      layer.lfoGain = lfoGain;
    }
    return layer;
  }

  function makeSubHum(freq: number, gainValue: number): void {
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    gain.gain.setTargetAtTime(gainValue, ctx.currentTime, 0.9);
    osc.connect(gain).connect(master);
    osc.start();
    oscillators.push({ osc, gain });
  }

  /** Random short sine ping with a fast decay (droplet / tick). */
  function scheduleDroplets(t: Timers) {
    const loop = () => {
      if (t.stopped) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = 900 + Math.random() * 2600;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.02 + Math.random() * 0.035, now + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.06 + Math.random() * 0.08);
      osc.connect(g).connect(master);
      osc.start(now);
      osc.stop(now + 0.2);
      t.timers.push(window.setTimeout(loop, 25 + Math.random() * 110));
    };
    t.timers.push(window.setTimeout(loop, 60));
  }

  /** Birdsong motif: 2–5 quick pitch-gliding sine notes. */
  function scheduleBirds(t: Timers) {
    const loop = () => {
      if (t.stopped) return;
      const notes = 2 + Math.floor(Math.random() * 4);
      const base = 2300 + Math.random() * 2100;
      for (let i = 0; i < notes; i++) {
        const at = ctx.currentTime + i * (0.09 + Math.random() * 0.08);
        const osc = ctx.createOscillator();
        osc.type = "sine";
        const f = base * (0.92 + Math.random() * 0.16);
        osc.frequency.setValueAtTime(f, at);
        osc.frequency.exponentialRampToValueAtTime(f * (0.7 + Math.random() * 0.5), at + 0.1);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, at);
        g.gain.linearRampToValueAtTime(0.016 + Math.random() * 0.014, at + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, at + 0.11);
        osc.connect(g).connect(master);
        osc.start(at);
        osc.stop(at + 0.16);
      }
      t.timers.push(window.setTimeout(loop, 1400 + Math.random() * 4200));
    };
    t.timers.push(window.setTimeout(loop, 400));
  }

  /** Cricket: bursts of 3–5 ultra-short 4.3 kHz pulses, rhythmic. */
  function scheduleCrickets(t: Timers) {
    const loop = () => {
      if (t.stopped) return;
      const pulses = 3 + Math.floor(Math.random() * 3);
      const at0 = ctx.currentTime;
      const carrier = 4100 + Math.random() * 500;
      for (let i = 0; i < pulses; i++) {
        const at = at0 + i * 0.042;
        const osc = ctx.createOscillator();
        osc.type = "sine";
        osc.frequency.value = carrier;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, at);
        g.gain.linearRampToValueAtTime(0.012, at + 0.006);
        g.gain.exponentialRampToValueAtTime(0.0001, at + 0.03);
        osc.connect(g).connect(master);
        osc.start(at);
        osc.stop(at + 0.05);
      }
      t.timers.push(window.setTimeout(loop, 350 + Math.random() * 900));
    };
    t.timers.push(window.setTimeout(loop, 300));
  }

  /** Sparse deep rumble swell (night / rain undertone). */
  function scheduleRumble(t: Timers) {
    const loop = () => {
      if (t.stopped) return;
      const now = ctx.currentTime;
      const src = ctx.createBufferSource();
      src.buffer = noiseBuf;
      src.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 90;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.05 + Math.random() * 0.05, now + 1.4);
      g.gain.linearRampToValueAtTime(0, now + 3.4);
      src.connect(filter).connect(g).connect(master);
      src.start(now);
      src.stop(now + 3.6);
      t.timers.push(window.setTimeout(loop, 6000 + Math.random() * 9000));
    };
    t.timers.push(window.setTimeout(loop, 1200));
  }

  /* --- preset scenes ------------------------------------- */

  function buildPreset(id: AtmospherePresetId) {
    winds = [];
    oscillators = [];
    timers = { timers: [], stopped: false };

    switch (id) {
      case "studio":
        // Faint air handling: dark noise breathing very slowly
        winds.push(
          makeWind({ type: "lowpass", freq: 240, gain: 0.035, lfoRate: 0.06, lfoDepth: 0.5 })
        );
        makeSubHum(58, 0.006);
        break;
      case "dawn":
        // Light breeze + birdsong
        winds.push(
          makeWind({ type: "bandpass", freq: 620, q: 0.4, gain: 0.02, lfoRate: 0.11, lfoDepth: 0.55 })
        );
        scheduleBirds(timers);
        break;
      case "dusk":
        // Warm low wind + crickets
        winds.push(
          makeWind({ type: "lowpass", freq: 380, gain: 0.028, lfoRate: 0.08, lfoDepth: 0.45 })
        );
        scheduleCrickets(timers);
        break;
      case "night":
        // Deep slow wind swells + distant rumble
        winds.push(
          makeWind({ type: "lowpass", freq: 180, gain: 0.05, lfoRate: 0.045, lfoDepth: 0.7 })
        );
        winds.push(
          makeWind({ type: "bandpass", freq: 900, q: 0.5, gain: 0.008, lfoRate: 0.03, lfoDepth: 0.8 })
        );
        scheduleRumble(timers);
        break;
      case "rain":
        // Broadband patter + droplets + undertone rumble
        winds.push(
          makeWind({ type: "highpass", freq: 900, gain: 0.045, lfoRate: 0.09, lfoDepth: 0.3 })
        );
        winds.push(
          makeWind({ type: "lowpass", freq: 500, gain: 0.03, lfoRate: 0.05, lfoDepth: 0.4 })
        );
        scheduleDroplets(timers);
        scheduleRumble(timers);
        break;
    }
  }

  function teardownScene() {
    timers.stopped = true;
    for (const id of timers.timers) window.clearTimeout(id);
    timers.timers = [];
    const t = ctx.currentTime;
    // fast fade so a switch never clicks
    master.gain.cancelScheduledValues(t);
    master.gain.setTargetAtTime(0, t, 0.18);
  }

  function cleanupNodes() {
    for (const w of winds) {
      try {
        w.src.stop();
      } catch {
        /* already stopped */
      }
      w.lfo?.stop();
    }
    for (const o of oscillators) {
      try {
        o.osc.stop();
      } catch {
        /* already stopped */
      }
    }
    winds = [];
    oscillators = [];
  }

  /* --- boot ----------------------------------------------- */
  buildPreset(initial);
  master.gain.setTargetAtTime(PRESET_LEVEL[current] * volume, ctx.currentTime + 0.1, 0.8);

  return {
    setPreset(id) {
      if (id === current) return;
      current = id;
      teardownScene();
      // swap the scene after the fade, then level back up
      window.setTimeout(() => {
        if (ctx.state === "closed") return;
        cleanupNodes();
        buildPreset(id);
        master.gain.setTargetAtTime(PRESET_LEVEL[id] * volume, ctx.currentTime, 0.6);
      }, 550);
    },
    setVolume(v) {
      volume = Math.min(Math.max(v, 0), 1);
      // Live-update without a rebuild; the ramp avoids clicks
      master.gain.setTargetAtTime(PRESET_LEVEL[current] * volume, ctx.currentTime, 0.15);
    },
    suspend() {
      if (ctx.state === "running") void ctx.suspend();
    },
    resume() {
      if (ctx.state === "suspended") void ctx.resume();
    },
    dispose() {
      teardownScene();
      window.setTimeout(() => {
        cleanupNodes();
        void ctx.close();
      }, 350);
    },
  };
}

/* 2 s of white noise, reused by every noise layer */
function makeNoiseBuffer(ctx: AudioContext): AudioBuffer {
  const len = ctx.sampleRate * 2;
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}
